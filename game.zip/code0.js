gdjs.Title_32ScreenCode = {};
gdjs.Title_32ScreenCode.forEachCount0_2 = 0;

gdjs.Title_32ScreenCode.forEachCount1_2 = 0;

gdjs.Title_32ScreenCode.forEachCount2_2 = 0;

gdjs.Title_32ScreenCode.forEachCount3_2 = 0;

gdjs.Title_32ScreenCode.forEachIndex2 = 0;

gdjs.Title_32ScreenCode.forEachObjects2 = [];

gdjs.Title_32ScreenCode.forEachTotalCount2 = 0;

gdjs.Title_32ScreenCode.GDBall_951Objects1= [];
gdjs.Title_32ScreenCode.GDBall_951Objects2= [];
gdjs.Title_32ScreenCode.GDBall_951Objects3= [];
gdjs.Title_32ScreenCode.GDBall_951Objects4= [];
gdjs.Title_32ScreenCode.GDBall_951Objects5= [];
gdjs.Title_32ScreenCode.GDBall_954Objects1= [];
gdjs.Title_32ScreenCode.GDBall_954Objects2= [];
gdjs.Title_32ScreenCode.GDBall_954Objects3= [];
gdjs.Title_32ScreenCode.GDBall_954Objects4= [];
gdjs.Title_32ScreenCode.GDBall_954Objects5= [];
gdjs.Title_32ScreenCode.GDBall_955Objects1= [];
gdjs.Title_32ScreenCode.GDBall_955Objects2= [];
gdjs.Title_32ScreenCode.GDBall_955Objects3= [];
gdjs.Title_32ScreenCode.GDBall_955Objects4= [];
gdjs.Title_32ScreenCode.GDBall_955Objects5= [];
gdjs.Title_32ScreenCode.GDBall_956Objects1= [];
gdjs.Title_32ScreenCode.GDBall_956Objects2= [];
gdjs.Title_32ScreenCode.GDBall_956Objects3= [];
gdjs.Title_32ScreenCode.GDBall_956Objects4= [];
gdjs.Title_32ScreenCode.GDBall_956Objects5= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects1= [];
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects2= [];
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3= [];
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4= [];
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects5= [];
gdjs.Title_32ScreenCode.GDCloud1Objects1= [];
gdjs.Title_32ScreenCode.GDCloud1Objects2= [];
gdjs.Title_32ScreenCode.GDCloud1Objects3= [];
gdjs.Title_32ScreenCode.GDCloud1Objects4= [];
gdjs.Title_32ScreenCode.GDCloud1Objects5= [];
gdjs.Title_32ScreenCode.GDCloud2Objects1= [];
gdjs.Title_32ScreenCode.GDCloud2Objects2= [];
gdjs.Title_32ScreenCode.GDCloud2Objects3= [];
gdjs.Title_32ScreenCode.GDCloud2Objects4= [];
gdjs.Title_32ScreenCode.GDCloud2Objects5= [];
gdjs.Title_32ScreenCode.GDCloud3Objects1= [];
gdjs.Title_32ScreenCode.GDCloud3Objects2= [];
gdjs.Title_32ScreenCode.GDCloud3Objects3= [];
gdjs.Title_32ScreenCode.GDCloud3Objects4= [];
gdjs.Title_32ScreenCode.GDCloud3Objects5= [];
gdjs.Title_32ScreenCode.GDCloud4Objects1= [];
gdjs.Title_32ScreenCode.GDCloud4Objects2= [];
gdjs.Title_32ScreenCode.GDCloud4Objects3= [];
gdjs.Title_32ScreenCode.GDCloud4Objects4= [];
gdjs.Title_32ScreenCode.GDCloud4Objects5= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects1= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects2= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects3= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects4= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects5= [];
gdjs.Title_32ScreenCode.GDButtonCNObjects1= [];
gdjs.Title_32ScreenCode.GDButtonCNObjects2= [];
gdjs.Title_32ScreenCode.GDButtonCNObjects3= [];
gdjs.Title_32ScreenCode.GDButtonCNObjects4= [];
gdjs.Title_32ScreenCode.GDButtonCNObjects5= [];
gdjs.Title_32ScreenCode.GDMenuObjects1= [];
gdjs.Title_32ScreenCode.GDMenuObjects2= [];
gdjs.Title_32ScreenCode.GDMenuObjects3= [];
gdjs.Title_32ScreenCode.GDMenuObjects4= [];
gdjs.Title_32ScreenCode.GDMenuObjects5= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDClick_95textObjects1= [];
gdjs.Title_32ScreenCode.GDClick_95textObjects2= [];
gdjs.Title_32ScreenCode.GDClick_95textObjects3= [];
gdjs.Title_32ScreenCode.GDClick_95textObjects4= [];
gdjs.Title_32ScreenCode.GDClick_95textObjects5= [];
gdjs.Title_32ScreenCode.GDYarnObjects1= [];
gdjs.Title_32ScreenCode.GDYarnObjects2= [];
gdjs.Title_32ScreenCode.GDYarnObjects3= [];
gdjs.Title_32ScreenCode.GDYarnObjects4= [];
gdjs.Title_32ScreenCode.GDYarnObjects5= [];
gdjs.Title_32ScreenCode.GDBullObjects1= [];
gdjs.Title_32ScreenCode.GDBullObjects2= [];
gdjs.Title_32ScreenCode.GDBullObjects3= [];
gdjs.Title_32ScreenCode.GDBullObjects4= [];
gdjs.Title_32ScreenCode.GDBullObjects5= [];
gdjs.Title_32ScreenCode.GDClick_95text2Objects1= [];
gdjs.Title_32ScreenCode.GDClick_95text2Objects2= [];
gdjs.Title_32ScreenCode.GDClick_95text2Objects3= [];
gdjs.Title_32ScreenCode.GDClick_95text2Objects4= [];
gdjs.Title_32ScreenCode.GDClick_95text2Objects5= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects1= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects2= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects3= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects4= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects5= [];
gdjs.Title_32ScreenCode.GDLeatherShoesObjects1= [];
gdjs.Title_32ScreenCode.GDLeatherShoesObjects2= [];
gdjs.Title_32ScreenCode.GDLeatherShoesObjects3= [];
gdjs.Title_32ScreenCode.GDLeatherShoesObjects4= [];
gdjs.Title_32ScreenCode.GDLeatherShoesObjects5= [];
gdjs.Title_32ScreenCode.GDFurnitureObjects1= [];
gdjs.Title_32ScreenCode.GDFurnitureObjects2= [];
gdjs.Title_32ScreenCode.GDFurnitureObjects3= [];
gdjs.Title_32ScreenCode.GDFurnitureObjects4= [];
gdjs.Title_32ScreenCode.GDFurnitureObjects5= [];
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects1= [];
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects2= [];
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects3= [];
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects4= [];
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects5= [];
gdjs.Title_32ScreenCode.GDtoysObjects1= [];
gdjs.Title_32ScreenCode.GDtoysObjects2= [];
gdjs.Title_32ScreenCode.GDtoysObjects3= [];
gdjs.Title_32ScreenCode.GDtoysObjects4= [];
gdjs.Title_32ScreenCode.GDtoysObjects5= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDChina_95textObjects1= [];
gdjs.Title_32ScreenCode.GDChina_95textObjects2= [];
gdjs.Title_32ScreenCode.GDChina_95textObjects3= [];
gdjs.Title_32ScreenCode.GDChina_95textObjects4= [];
gdjs.Title_32ScreenCode.GDChina_95textObjects5= [];
gdjs.Title_32ScreenCode.GDSection_95text1Objects1= [];
gdjs.Title_32ScreenCode.GDSection_95text1Objects2= [];
gdjs.Title_32ScreenCode.GDSection_95text1Objects3= [];
gdjs.Title_32ScreenCode.GDSection_95text1Objects4= [];
gdjs.Title_32ScreenCode.GDSection_95text1Objects5= [];
gdjs.Title_32ScreenCode.GDSource_95textObjects1= [];
gdjs.Title_32ScreenCode.GDSource_95textObjects2= [];
gdjs.Title_32ScreenCode.GDSource_95textObjects3= [];
gdjs.Title_32ScreenCode.GDSource_95textObjects4= [];
gdjs.Title_32ScreenCode.GDSource_95textObjects5= [];
gdjs.Title_32ScreenCode.GDYear_95textObjects1= [];
gdjs.Title_32ScreenCode.GDYear_95textObjects2= [];
gdjs.Title_32ScreenCode.GDYear_95textObjects3= [];
gdjs.Title_32ScreenCode.GDYear_95textObjects4= [];
gdjs.Title_32ScreenCode.GDYear_95textObjects5= [];
gdjs.Title_32ScreenCode.GDYesObjects1= [];
gdjs.Title_32ScreenCode.GDYesObjects2= [];
gdjs.Title_32ScreenCode.GDYesObjects3= [];
gdjs.Title_32ScreenCode.GDYesObjects4= [];
gdjs.Title_32ScreenCode.GDYesObjects5= [];
gdjs.Title_32ScreenCode.GDYes2Objects1= [];
gdjs.Title_32ScreenCode.GDYes2Objects2= [];
gdjs.Title_32ScreenCode.GDYes2Objects3= [];
gdjs.Title_32ScreenCode.GDYes2Objects4= [];
gdjs.Title_32ScreenCode.GDYes2Objects5= [];
gdjs.Title_32ScreenCode.GDYes3Objects1= [];
gdjs.Title_32ScreenCode.GDYes3Objects2= [];
gdjs.Title_32ScreenCode.GDYes3Objects3= [];
gdjs.Title_32ScreenCode.GDYes3Objects4= [];
gdjs.Title_32ScreenCode.GDYes3Objects5= [];
gdjs.Title_32ScreenCode.GDYes32Objects1= [];
gdjs.Title_32ScreenCode.GDYes32Objects2= [];
gdjs.Title_32ScreenCode.GDYes32Objects3= [];
gdjs.Title_32ScreenCode.GDYes32Objects4= [];
gdjs.Title_32ScreenCode.GDYes32Objects5= [];
gdjs.Title_32ScreenCode.GDYes4Objects1= [];
gdjs.Title_32ScreenCode.GDYes4Objects2= [];
gdjs.Title_32ScreenCode.GDYes4Objects3= [];
gdjs.Title_32ScreenCode.GDYes4Objects4= [];
gdjs.Title_32ScreenCode.GDYes4Objects5= [];
gdjs.Title_32ScreenCode.GDYes5Objects1= [];
gdjs.Title_32ScreenCode.GDYes5Objects2= [];
gdjs.Title_32ScreenCode.GDYes5Objects3= [];
gdjs.Title_32ScreenCode.GDYes5Objects4= [];
gdjs.Title_32ScreenCode.GDYes5Objects5= [];
gdjs.Title_32ScreenCode.GDYes6Objects1= [];
gdjs.Title_32ScreenCode.GDYes6Objects2= [];
gdjs.Title_32ScreenCode.GDYes6Objects3= [];
gdjs.Title_32ScreenCode.GDYes6Objects4= [];
gdjs.Title_32ScreenCode.GDYes6Objects5= [];
gdjs.Title_32ScreenCode.GDYes7Objects1= [];
gdjs.Title_32ScreenCode.GDYes7Objects2= [];
gdjs.Title_32ScreenCode.GDYes7Objects3= [];
gdjs.Title_32ScreenCode.GDYes7Objects4= [];
gdjs.Title_32ScreenCode.GDYes7Objects5= [];
gdjs.Title_32ScreenCode.GDYes8Objects1= [];
gdjs.Title_32ScreenCode.GDYes8Objects2= [];
gdjs.Title_32ScreenCode.GDYes8Objects3= [];
gdjs.Title_32ScreenCode.GDYes8Objects4= [];
gdjs.Title_32ScreenCode.GDYes8Objects5= [];
gdjs.Title_32ScreenCode.GDChinaObjects1= [];
gdjs.Title_32ScreenCode.GDChinaObjects2= [];
gdjs.Title_32ScreenCode.GDChinaObjects3= [];
gdjs.Title_32ScreenCode.GDChinaObjects4= [];
gdjs.Title_32ScreenCode.GDChinaObjects5= [];
gdjs.Title_32ScreenCode.GDNoObjects1= [];
gdjs.Title_32ScreenCode.GDNoObjects2= [];
gdjs.Title_32ScreenCode.GDNoObjects3= [];
gdjs.Title_32ScreenCode.GDNoObjects4= [];
gdjs.Title_32ScreenCode.GDNoObjects5= [];
gdjs.Title_32ScreenCode.GDNo2Objects1= [];
gdjs.Title_32ScreenCode.GDNo2Objects2= [];
gdjs.Title_32ScreenCode.GDNo2Objects3= [];
gdjs.Title_32ScreenCode.GDNo2Objects4= [];
gdjs.Title_32ScreenCode.GDNo2Objects5= [];
gdjs.Title_32ScreenCode.GDNo3Objects1= [];
gdjs.Title_32ScreenCode.GDNo3Objects2= [];
gdjs.Title_32ScreenCode.GDNo3Objects3= [];
gdjs.Title_32ScreenCode.GDNo3Objects4= [];
gdjs.Title_32ScreenCode.GDNo3Objects5= [];
gdjs.Title_32ScreenCode.GDNo4Objects1= [];
gdjs.Title_32ScreenCode.GDNo4Objects2= [];
gdjs.Title_32ScreenCode.GDNo4Objects3= [];
gdjs.Title_32ScreenCode.GDNo4Objects4= [];
gdjs.Title_32ScreenCode.GDNo4Objects5= [];
gdjs.Title_32ScreenCode.GDNo5Objects1= [];
gdjs.Title_32ScreenCode.GDNo5Objects2= [];
gdjs.Title_32ScreenCode.GDNo5Objects3= [];
gdjs.Title_32ScreenCode.GDNo5Objects4= [];
gdjs.Title_32ScreenCode.GDNo5Objects5= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects5= [];

gdjs.Title_32ScreenCode.conditionTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition0IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition1IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition2IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition3IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.conditionTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition0IsTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition1IsTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition2IsTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition3IsTrue_1 = {val:false};


gdjs.Title_32ScreenCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cloud1"), gdjs.Title_32ScreenCode.GDCloud1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud2"), gdjs.Title_32ScreenCode.GDCloud2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud3"), gdjs.Title_32ScreenCode.GDCloud3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud4"), gdjs.Title_32ScreenCode.GDCloud4Objects2);
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud1Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud1Objects2[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud2Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud2Objects2[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud3Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud3Objects2[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud4Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud4Objects2[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud1Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud1Objects2[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud2Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud2Objects2[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud3Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud3Objects2[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud4Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud4Objects2[i].setOpacity(gdjs.randomInRange(128, 196));
}
}}

}


};gdjs.Title_32ScreenCode.eventsList1 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "CurrentLevel", runtimeScene, runtimeScene.getVariables().get("CurrentLevel"));
}}

}


{



}


{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel")) == 0;
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("CurrentLevel").setNumber(1);
}}

}


};gdjs.Title_32ScreenCode.eventsList2 = function(runtimeScene) {

{


{
}

}


{


gdjs.Title_32ScreenCode.eventsList0(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList1(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList3 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cloud1"), gdjs.Title_32ScreenCode.GDCloud1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud2"), gdjs.Title_32ScreenCode.GDCloud2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud3"), gdjs.Title_32ScreenCode.GDCloud3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud4"), gdjs.Title_32ScreenCode.GDCloud4Objects2);
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "SlideCameraOut", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) + (( gdjs.Title_32ScreenCode.GDCloud4Objects2.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDCloud3Objects2.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDCloud2Objects2.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDCloud1Objects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCloud1Objects2[0].getWidth()) :gdjs.Title_32ScreenCode.GDCloud2Objects2[0].getWidth()) :gdjs.Title_32ScreenCode.GDCloud3Objects2[0].getWidth()) :gdjs.Title_32ScreenCode.GDCloud4Objects2[0].getWidth()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 1000, "easeInBack");
}}

}


};gdjs.Title_32ScreenCode.asyncCallback10905268 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "CurrentLevel", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel")));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 1", false);
}}
gdjs.Title_32ScreenCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback10905268(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList6 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList4(runtimeScene);
}


{


{

{ //Subevents
gdjs.Title_32ScreenCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList7 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10903436);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects1);
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\audio\\audio - AlexBouncyMaster.aac", 1, true, 50, 1);
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList8 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "StartGame";
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList9 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList8(runtimeScene);
}


};gdjs.Title_32ScreenCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_954ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_4": [], "Ball_5": [], "Ball_6": []});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects3, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects3, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects3, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects3});
gdjs.Title_32ScreenCode.eventsList10 = function(runtimeScene) {

{


{
gdjs.Title_32ScreenCode.GDBall_951Objects3.length = 0;

gdjs.Title_32ScreenCode.GDBall_954Objects3.length = 0;

gdjs.Title_32ScreenCode.GDBall_955Objects3.length = 0;

gdjs.Title_32ScreenCode.GDBall_956Objects3.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects3Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 32, gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0)), "Balls");
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_951Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_954Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_955Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_956Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_951Objects3[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_954Objects3[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_955Objects3[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_956Objects3[i].getVariables().get("BorderAnimation"), true);
}
}}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects2, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects2, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects2, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects2});
gdjs.Title_32ScreenCode.eventsList11 = function(runtimeScene) {

{


{
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_954Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_955Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_956Objects2.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 32, gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0)), "Balls");
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getVariables().get("BorderAnimation"), true);
}
}}

}


};gdjs.Title_32ScreenCode.eventsList12 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList10(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList11(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList13 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition2IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) != "0";
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) != "StartGame";
}if ( gdjs.Title_32ScreenCode.condition1IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition2IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_954ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) < 50;
}}
}
if (gdjs.Title_32ScreenCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects2);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_951Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_951Objects2[k] = gdjs.Title_32ScreenCode.GDBall_951Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_954Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_954Objects2[k] = gdjs.Title_32ScreenCode.GDBall_954Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_954Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_955Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_955Objects2[k] = gdjs.Title_32ScreenCode.GDBall_955Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_955Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_956Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_956Objects2[k] = gdjs.Title_32ScreenCode.GDBall_956Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_956Objects2.length = k;}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects2 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
}}

}


};gdjs.Title_32ScreenCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_951Objects2, gdjs.Title_32ScreenCode.GDBall_951Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_954Objects2, gdjs.Title_32ScreenCode.GDBall_954Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_955Objects2, gdjs.Title_32ScreenCode.GDBall_955Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_956Objects2, gdjs.Title_32ScreenCode.GDBall_956Objects3);

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects3);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = (Math.abs((( gdjs.Title_32ScreenCode.GDBall_956Objects3.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDBall_955Objects3.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDBall_954Objects3.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDBall_951Objects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDBall_951Objects3[0].getCenterXInScene()) :gdjs.Title_32ScreenCode.GDBall_954Objects3[0].getCenterXInScene()) :gdjs.Title_32ScreenCode.GDBall_955Objects3[0].getCenterXInScene()) :gdjs.Title_32ScreenCode.GDBall_956Objects3[0].getCenterXInScene()) - (( gdjs.Title_32ScreenCode.GDGreyButtonObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDGreyButtonObjects3[0].getCenterXInScene())) > gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 + 64);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects3 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Title_32ScreenCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects1);

gdjs.Title_32ScreenCode.forEachTotalCount2 = 0;
gdjs.Title_32ScreenCode.forEachObjects2.length = 0;
gdjs.Title_32ScreenCode.forEachCount0_2 = gdjs.Title_32ScreenCode.GDBall_951Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount0_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_951Objects1);
gdjs.Title_32ScreenCode.forEachCount1_2 = gdjs.Title_32ScreenCode.GDBall_954Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount1_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_954Objects1);
gdjs.Title_32ScreenCode.forEachCount2_2 = gdjs.Title_32ScreenCode.GDBall_955Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount2_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_955Objects1);
gdjs.Title_32ScreenCode.forEachCount3_2 = gdjs.Title_32ScreenCode.GDBall_956Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount3_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_956Objects1);
for(gdjs.Title_32ScreenCode.forEachIndex2 = 0;gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachTotalCount2;++gdjs.Title_32ScreenCode.forEachIndex2) {
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_954Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_955Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_956Objects2.length = 0;


if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
else if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2+gdjs.Title_32ScreenCode.forEachCount1_2) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
else if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2+gdjs.Title_32ScreenCode.forEachCount1_2+gdjs.Title_32ScreenCode.forEachCount2_2) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
else if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2+gdjs.Title_32ScreenCode.forEachCount1_2+gdjs.Title_32ScreenCode.forEachCount2_2+gdjs.Title_32ScreenCode.forEachCount3_2) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
if (true) {

{ //Subevents: 
gdjs.Title_32ScreenCode.eventsList15(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Title_32ScreenCode.eventsList17 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList13(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList14(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList16(runtimeScene);
}


};gdjs.Title_32ScreenCode.asyncCallback10916084 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getVariables().get("GameState").setString("SlideCupIn");
}}
gdjs.Title_32ScreenCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback10916084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList19 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) + 0), "", 0);
}}

}


{



}


{


{
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "SlideCameraIn", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 1000, "easeOutBack");
}}

}


{



}


{


{

{ //Subevents
gdjs.Title_32ScreenCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList20 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList19(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList21 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList20(runtimeScene);} //End of subevents
}

}


{



}


{


{
{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Balls", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "FrontCups", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Debugging", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Clouds", 0, true, true, false, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "UI", 0, true, true, false, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Title_32ScreenCode.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.eventsList22 = function(runtimeScene) {

{

/* Reuse gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Title_32ScreenCode.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDSubmit_9595TextObjects4Objects, gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDPlay_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDPlay_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4[i].setColor("255;255;255");
}
}}

}


};gdjs.Title_32ScreenCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Title_32ScreenCode.GDMenuObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, runtimeScene, true, true);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects4[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Title_32ScreenCode.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.eventsList24 = function(runtimeScene) {

{

/* Reuse gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Title_32ScreenCode.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDSubmit_9595TextObjects4Objects, gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDPlay_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDPlay_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4[i].setColor("241;91;181");
}
}}

}


};gdjs.Title_32ScreenCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Title_32ScreenCode.GDMenuObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition1IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11173756);
}
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects4[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Title_32ScreenCode.GDMenuObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, runtimeScene, true, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects4[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects3, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects3, "GdevelopGLogoWhite": gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects3});
gdjs.Title_32ScreenCode.eventsList27 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition1IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11175812);
}
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Title_32ScreenCode.GDMenuObjects3);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3 */
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects3 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects3 */
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects3[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.Title_32ScreenCode.eventsList28 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList23(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList25(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList27(runtimeScene);
}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects2});
gdjs.Title_32ScreenCode.eventsList29 = function(runtimeScene) {

{



}


{


gdjs.Title_32ScreenCode.eventsList28(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects2);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("StartGame");
}}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects3Objects = Hashtable.newFrom({"GdevelopGLogoWhite": gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects2Objects = Hashtable.newFrom({"GdevelopGLogoWhite": gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects2});
gdjs.Title_32ScreenCode.asyncCallback11115444 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PauseMenu");
}}
gdjs.Title_32ScreenCode.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11115444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList31 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11114500);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects3Objects, runtimeScene, true, true);
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition1IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11112940);
}
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects2);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGdevelopGLogoWhiteObjects2Objects, runtimeScene, true, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.asyncCallback11117500 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Title_32ScreenCode.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11117500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.asyncCallback11117020 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("GdevelopGLogoWhite"), gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects2);

{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects2[i].getBehavior("Tween").addObjectAngleTween("SpinLogo", 0, "swingFromTo", 1000, false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Title_32ScreenCode.eventsList34 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects1) asyncObjectsList.addObject("GdevelopGLogoWhite", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11117020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList35 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.condition0IsTrue_1.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_1.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_1.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "SpinLogo", 20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if( gdjs.Title_32ScreenCode.condition0IsTrue_1.val ) {
    gdjs.Title_32ScreenCode.conditionTrue_1.val = true;
}
}
{
gdjs.Title_32ScreenCode.condition1IsTrue_1.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if( gdjs.Title_32ScreenCode.condition1IsTrue_1.val ) {
    gdjs.Title_32ScreenCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects1);
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects1[i].getBehavior("Tween").addObjectAngleTween("SpinLogo", 360, "swingFromTo", 1000, false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList36 = function(runtimeScene) {

{



}


{


gdjs.Title_32ScreenCode.eventsList32(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList35(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList37 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList21(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList29(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList36(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList38 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList3(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList9(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList17(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList37(runtimeScene);
}


};

gdjs.Title_32ScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Title_32ScreenCode.GDBall_951Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects5.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects1.length = 0;
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects2.length = 0;
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects3.length = 0;
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects4.length = 0;
gdjs.Title_32ScreenCode.GDGdevelopGLogoWhiteObjects5.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects1.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects2.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects3.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects4.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects5.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects1.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects2.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects3.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects4.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects5.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects1.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects2.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects3.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects4.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects5.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects1.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects2.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects3.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects4.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects5.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects1.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects2.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects3.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects5.length = 0;
gdjs.Title_32ScreenCode.GDButtonCNObjects1.length = 0;
gdjs.Title_32ScreenCode.GDButtonCNObjects2.length = 0;
gdjs.Title_32ScreenCode.GDButtonCNObjects3.length = 0;
gdjs.Title_32ScreenCode.GDButtonCNObjects4.length = 0;
gdjs.Title_32ScreenCode.GDButtonCNObjects5.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects1.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects2.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects3.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects4.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects5.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDClick_95textObjects1.length = 0;
gdjs.Title_32ScreenCode.GDClick_95textObjects2.length = 0;
gdjs.Title_32ScreenCode.GDClick_95textObjects3.length = 0;
gdjs.Title_32ScreenCode.GDClick_95textObjects4.length = 0;
gdjs.Title_32ScreenCode.GDClick_95textObjects5.length = 0;
gdjs.Title_32ScreenCode.GDYarnObjects1.length = 0;
gdjs.Title_32ScreenCode.GDYarnObjects2.length = 0;
gdjs.Title_32ScreenCode.GDYarnObjects3.length = 0;
gdjs.Title_32ScreenCode.GDYarnObjects4.length = 0;
gdjs.Title_32ScreenCode.GDYarnObjects5.length = 0;
gdjs.Title_32ScreenCode.GDBullObjects1.length = 0;
gdjs.Title_32ScreenCode.GDBullObjects2.length = 0;
gdjs.Title_32ScreenCode.GDBullObjects3.length = 0;
gdjs.Title_32ScreenCode.GDBullObjects4.length = 0;
gdjs.Title_32ScreenCode.GDBullObjects5.length = 0;
gdjs.Title_32ScreenCode.GDClick_95text2Objects1.length = 0;
gdjs.Title_32ScreenCode.GDClick_95text2Objects2.length = 0;
gdjs.Title_32ScreenCode.GDClick_95text2Objects3.length = 0;
gdjs.Title_32ScreenCode.GDClick_95text2Objects4.length = 0;
gdjs.Title_32ScreenCode.GDClick_95text2Objects5.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects1.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects2.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects3.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects5.length = 0;
gdjs.Title_32ScreenCode.GDLeatherShoesObjects1.length = 0;
gdjs.Title_32ScreenCode.GDLeatherShoesObjects2.length = 0;
gdjs.Title_32ScreenCode.GDLeatherShoesObjects3.length = 0;
gdjs.Title_32ScreenCode.GDLeatherShoesObjects4.length = 0;
gdjs.Title_32ScreenCode.GDLeatherShoesObjects5.length = 0;
gdjs.Title_32ScreenCode.GDFurnitureObjects1.length = 0;
gdjs.Title_32ScreenCode.GDFurnitureObjects2.length = 0;
gdjs.Title_32ScreenCode.GDFurnitureObjects3.length = 0;
gdjs.Title_32ScreenCode.GDFurnitureObjects4.length = 0;
gdjs.Title_32ScreenCode.GDFurnitureObjects5.length = 0;
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects1.length = 0;
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects2.length = 0;
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects3.length = 0;
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects4.length = 0;
gdjs.Title_32ScreenCode.GDMagnifyingGlassObjects5.length = 0;
gdjs.Title_32ScreenCode.GDtoysObjects1.length = 0;
gdjs.Title_32ScreenCode.GDtoysObjects2.length = 0;
gdjs.Title_32ScreenCode.GDtoysObjects3.length = 0;
gdjs.Title_32ScreenCode.GDtoysObjects4.length = 0;
gdjs.Title_32ScreenCode.GDtoysObjects5.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDChina_95textObjects1.length = 0;
gdjs.Title_32ScreenCode.GDChina_95textObjects2.length = 0;
gdjs.Title_32ScreenCode.GDChina_95textObjects3.length = 0;
gdjs.Title_32ScreenCode.GDChina_95textObjects4.length = 0;
gdjs.Title_32ScreenCode.GDChina_95textObjects5.length = 0;
gdjs.Title_32ScreenCode.GDSection_95text1Objects1.length = 0;
gdjs.Title_32ScreenCode.GDSection_95text1Objects2.length = 0;
gdjs.Title_32ScreenCode.GDSection_95text1Objects3.length = 0;
gdjs.Title_32ScreenCode.GDSection_95text1Objects4.length = 0;
gdjs.Title_32ScreenCode.GDSection_95text1Objects5.length = 0;
gdjs.Title_32ScreenCode.GDSource_95textObjects1.length = 0;
gdjs.Title_32ScreenCode.GDSource_95textObjects2.length = 0;
gdjs.Title_32ScreenCode.GDSource_95textObjects3.length = 0;
gdjs.Title_32ScreenCode.GDSource_95textObjects4.length = 0;
gdjs.Title_32ScreenCode.GDSource_95textObjects5.length = 0;
gdjs.Title_32ScreenCode.GDYear_95textObjects1.length = 0;
gdjs.Title_32ScreenCode.GDYear_95textObjects2.length = 0;
gdjs.Title_32ScreenCode.GDYear_95textObjects3.length = 0;
gdjs.Title_32ScreenCode.GDYear_95textObjects4.length = 0;
gdjs.Title_32ScreenCode.GDYear_95textObjects5.length = 0;
gdjs.Title_32ScreenCode.GDYesObjects1.length = 0;
gdjs.Title_32ScreenCode.GDYesObjects2.length = 0;
gdjs.Title_32ScreenCode.GDYesObjects3.length = 0;
gdjs.Title_32ScreenCode.GDYesObjects4.length = 0;
gdjs.Title_32ScreenCode.GDYesObjects5.length = 0;
gdjs.Title_32ScreenCode.GDYes2Objects1.length = 0;
gdjs.Title_32ScreenCode.GDYes2Objects2.length = 0;
gdjs.Title_32ScreenCode.GDYes2Objects3.length = 0;
gdjs.Title_32ScreenCode.GDYes2Objects4.length = 0;
gdjs.Title_32ScreenCode.GDYes2Objects5.length = 0;
gdjs.Title_32ScreenCode.GDYes3Objects1.length = 0;
gdjs.Title_32ScreenCode.GDYes3Objects2.length = 0;
gdjs.Title_32ScreenCode.GDYes3Objects3.length = 0;
gdjs.Title_32ScreenCode.GDYes3Objects4.length = 0;
gdjs.Title_32ScreenCode.GDYes3Objects5.length = 0;
gdjs.Title_32ScreenCode.GDYes32Objects1.length = 0;
gdjs.Title_32ScreenCode.GDYes32Objects2.length = 0;
gdjs.Title_32ScreenCode.GDYes32Objects3.length = 0;
gdjs.Title_32ScreenCode.GDYes32Objects4.length = 0;
gdjs.Title_32ScreenCode.GDYes32Objects5.length = 0;
gdjs.Title_32ScreenCode.GDYes4Objects1.length = 0;
gdjs.Title_32ScreenCode.GDYes4Objects2.length = 0;
gdjs.Title_32ScreenCode.GDYes4Objects3.length = 0;
gdjs.Title_32ScreenCode.GDYes4Objects4.length = 0;
gdjs.Title_32ScreenCode.GDYes4Objects5.length = 0;
gdjs.Title_32ScreenCode.GDYes5Objects1.length = 0;
gdjs.Title_32ScreenCode.GDYes5Objects2.length = 0;
gdjs.Title_32ScreenCode.GDYes5Objects3.length = 0;
gdjs.Title_32ScreenCode.GDYes5Objects4.length = 0;
gdjs.Title_32ScreenCode.GDYes5Objects5.length = 0;
gdjs.Title_32ScreenCode.GDYes6Objects1.length = 0;
gdjs.Title_32ScreenCode.GDYes6Objects2.length = 0;
gdjs.Title_32ScreenCode.GDYes6Objects3.length = 0;
gdjs.Title_32ScreenCode.GDYes6Objects4.length = 0;
gdjs.Title_32ScreenCode.GDYes6Objects5.length = 0;
gdjs.Title_32ScreenCode.GDYes7Objects1.length = 0;
gdjs.Title_32ScreenCode.GDYes7Objects2.length = 0;
gdjs.Title_32ScreenCode.GDYes7Objects3.length = 0;
gdjs.Title_32ScreenCode.GDYes7Objects4.length = 0;
gdjs.Title_32ScreenCode.GDYes7Objects5.length = 0;
gdjs.Title_32ScreenCode.GDYes8Objects1.length = 0;
gdjs.Title_32ScreenCode.GDYes8Objects2.length = 0;
gdjs.Title_32ScreenCode.GDYes8Objects3.length = 0;
gdjs.Title_32ScreenCode.GDYes8Objects4.length = 0;
gdjs.Title_32ScreenCode.GDYes8Objects5.length = 0;
gdjs.Title_32ScreenCode.GDChinaObjects1.length = 0;
gdjs.Title_32ScreenCode.GDChinaObjects2.length = 0;
gdjs.Title_32ScreenCode.GDChinaObjects3.length = 0;
gdjs.Title_32ScreenCode.GDChinaObjects4.length = 0;
gdjs.Title_32ScreenCode.GDChinaObjects5.length = 0;
gdjs.Title_32ScreenCode.GDNoObjects1.length = 0;
gdjs.Title_32ScreenCode.GDNoObjects2.length = 0;
gdjs.Title_32ScreenCode.GDNoObjects3.length = 0;
gdjs.Title_32ScreenCode.GDNoObjects4.length = 0;
gdjs.Title_32ScreenCode.GDNoObjects5.length = 0;
gdjs.Title_32ScreenCode.GDNo2Objects1.length = 0;
gdjs.Title_32ScreenCode.GDNo2Objects2.length = 0;
gdjs.Title_32ScreenCode.GDNo2Objects3.length = 0;
gdjs.Title_32ScreenCode.GDNo2Objects4.length = 0;
gdjs.Title_32ScreenCode.GDNo2Objects5.length = 0;
gdjs.Title_32ScreenCode.GDNo3Objects1.length = 0;
gdjs.Title_32ScreenCode.GDNo3Objects2.length = 0;
gdjs.Title_32ScreenCode.GDNo3Objects3.length = 0;
gdjs.Title_32ScreenCode.GDNo3Objects4.length = 0;
gdjs.Title_32ScreenCode.GDNo3Objects5.length = 0;
gdjs.Title_32ScreenCode.GDNo4Objects1.length = 0;
gdjs.Title_32ScreenCode.GDNo4Objects2.length = 0;
gdjs.Title_32ScreenCode.GDNo4Objects3.length = 0;
gdjs.Title_32ScreenCode.GDNo4Objects4.length = 0;
gdjs.Title_32ScreenCode.GDNo4Objects5.length = 0;
gdjs.Title_32ScreenCode.GDNo5Objects1.length = 0;
gdjs.Title_32ScreenCode.GDNo5Objects2.length = 0;
gdjs.Title_32ScreenCode.GDNo5Objects3.length = 0;
gdjs.Title_32ScreenCode.GDNo5Objects4.length = 0;
gdjs.Title_32ScreenCode.GDNo5Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects5.length = 0;

gdjs.Title_32ScreenCode.eventsList38(runtimeScene);
return;

}

gdjs['Title_32ScreenCode'] = gdjs.Title_32ScreenCode;
