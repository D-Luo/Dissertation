gdjs.Level_326Code = {};
gdjs.Level_326Code.GDBall_951Objects3_1final = [];

gdjs.Level_326Code.GDBall_954Objects3_1final = [];

gdjs.Level_326Code.GDBall_955Objects3_1final = [];

gdjs.Level_326Code.GDBall_956Objects3_1final = [];

gdjs.Level_326Code.GDBullObjects1_1final = [];

gdjs.Level_326Code.GDLeatherShoesObjects1_1final = [];

gdjs.Level_326Code.GDMenuObjects3_1final = [];

gdjs.Level_326Code.GDOldComputerMonitorObjects1_1final = [];

gdjs.Level_326Code.GDYarnObjects1_1final = [];

gdjs.Level_326Code.GDBall_951Objects1= [];
gdjs.Level_326Code.GDBall_951Objects2= [];
gdjs.Level_326Code.GDBall_951Objects3= [];
gdjs.Level_326Code.GDBall_951Objects4= [];
gdjs.Level_326Code.GDBall_951Objects5= [];
gdjs.Level_326Code.GDBall_951Objects6= [];
gdjs.Level_326Code.GDBall_951Objects7= [];
gdjs.Level_326Code.GDBall_954Objects1= [];
gdjs.Level_326Code.GDBall_954Objects2= [];
gdjs.Level_326Code.GDBall_954Objects3= [];
gdjs.Level_326Code.GDBall_954Objects4= [];
gdjs.Level_326Code.GDBall_954Objects5= [];
gdjs.Level_326Code.GDBall_954Objects6= [];
gdjs.Level_326Code.GDBall_954Objects7= [];
gdjs.Level_326Code.GDBall_955Objects1= [];
gdjs.Level_326Code.GDBall_955Objects2= [];
gdjs.Level_326Code.GDBall_955Objects3= [];
gdjs.Level_326Code.GDBall_955Objects4= [];
gdjs.Level_326Code.GDBall_955Objects5= [];
gdjs.Level_326Code.GDBall_955Objects6= [];
gdjs.Level_326Code.GDBall_955Objects7= [];
gdjs.Level_326Code.GDBall_956Objects1= [];
gdjs.Level_326Code.GDBall_956Objects2= [];
gdjs.Level_326Code.GDBall_956Objects3= [];
gdjs.Level_326Code.GDBall_956Objects4= [];
gdjs.Level_326Code.GDBall_956Objects5= [];
gdjs.Level_326Code.GDBall_956Objects6= [];
gdjs.Level_326Code.GDBall_956Objects7= [];
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects6= [];
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects7= [];
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects1= [];
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects2= [];
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3= [];
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4= [];
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects5= [];
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects6= [];
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects7= [];
gdjs.Level_326Code.GDCloud1Objects1= [];
gdjs.Level_326Code.GDCloud1Objects2= [];
gdjs.Level_326Code.GDCloud1Objects3= [];
gdjs.Level_326Code.GDCloud1Objects4= [];
gdjs.Level_326Code.GDCloud1Objects5= [];
gdjs.Level_326Code.GDCloud1Objects6= [];
gdjs.Level_326Code.GDCloud1Objects7= [];
gdjs.Level_326Code.GDCloud2Objects1= [];
gdjs.Level_326Code.GDCloud2Objects2= [];
gdjs.Level_326Code.GDCloud2Objects3= [];
gdjs.Level_326Code.GDCloud2Objects4= [];
gdjs.Level_326Code.GDCloud2Objects5= [];
gdjs.Level_326Code.GDCloud2Objects6= [];
gdjs.Level_326Code.GDCloud2Objects7= [];
gdjs.Level_326Code.GDCloud3Objects1= [];
gdjs.Level_326Code.GDCloud3Objects2= [];
gdjs.Level_326Code.GDCloud3Objects3= [];
gdjs.Level_326Code.GDCloud3Objects4= [];
gdjs.Level_326Code.GDCloud3Objects5= [];
gdjs.Level_326Code.GDCloud3Objects6= [];
gdjs.Level_326Code.GDCloud3Objects7= [];
gdjs.Level_326Code.GDCloud4Objects1= [];
gdjs.Level_326Code.GDCloud4Objects2= [];
gdjs.Level_326Code.GDCloud4Objects3= [];
gdjs.Level_326Code.GDCloud4Objects4= [];
gdjs.Level_326Code.GDCloud4Objects5= [];
gdjs.Level_326Code.GDCloud4Objects6= [];
gdjs.Level_326Code.GDCloud4Objects7= [];
gdjs.Level_326Code.GDGreyButtonObjects1= [];
gdjs.Level_326Code.GDGreyButtonObjects2= [];
gdjs.Level_326Code.GDGreyButtonObjects3= [];
gdjs.Level_326Code.GDGreyButtonObjects4= [];
gdjs.Level_326Code.GDGreyButtonObjects5= [];
gdjs.Level_326Code.GDGreyButtonObjects6= [];
gdjs.Level_326Code.GDGreyButtonObjects7= [];
gdjs.Level_326Code.GDButtonCNObjects1= [];
gdjs.Level_326Code.GDButtonCNObjects2= [];
gdjs.Level_326Code.GDButtonCNObjects3= [];
gdjs.Level_326Code.GDButtonCNObjects4= [];
gdjs.Level_326Code.GDButtonCNObjects5= [];
gdjs.Level_326Code.GDButtonCNObjects6= [];
gdjs.Level_326Code.GDButtonCNObjects7= [];
gdjs.Level_326Code.GDMenuObjects1= [];
gdjs.Level_326Code.GDMenuObjects2= [];
gdjs.Level_326Code.GDMenuObjects3= [];
gdjs.Level_326Code.GDMenuObjects4= [];
gdjs.Level_326Code.GDMenuObjects5= [];
gdjs.Level_326Code.GDMenuObjects6= [];
gdjs.Level_326Code.GDMenuObjects7= [];
gdjs.Level_326Code.GDGameState_95TextObjects1= [];
gdjs.Level_326Code.GDGameState_95TextObjects2= [];
gdjs.Level_326Code.GDGameState_95TextObjects3= [];
gdjs.Level_326Code.GDGameState_95TextObjects4= [];
gdjs.Level_326Code.GDGameState_95TextObjects5= [];
gdjs.Level_326Code.GDGameState_95TextObjects6= [];
gdjs.Level_326Code.GDGameState_95TextObjects7= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects1= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects2= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects3= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects4= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects5= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects6= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects7= [];
gdjs.Level_326Code.GDClick_95textObjects1= [];
gdjs.Level_326Code.GDClick_95textObjects2= [];
gdjs.Level_326Code.GDClick_95textObjects3= [];
gdjs.Level_326Code.GDClick_95textObjects4= [];
gdjs.Level_326Code.GDClick_95textObjects5= [];
gdjs.Level_326Code.GDClick_95textObjects6= [];
gdjs.Level_326Code.GDClick_95textObjects7= [];
gdjs.Level_326Code.GDYarnObjects1= [];
gdjs.Level_326Code.GDYarnObjects2= [];
gdjs.Level_326Code.GDYarnObjects3= [];
gdjs.Level_326Code.GDYarnObjects4= [];
gdjs.Level_326Code.GDYarnObjects5= [];
gdjs.Level_326Code.GDYarnObjects6= [];
gdjs.Level_326Code.GDYarnObjects7= [];
gdjs.Level_326Code.GDBullObjects1= [];
gdjs.Level_326Code.GDBullObjects2= [];
gdjs.Level_326Code.GDBullObjects3= [];
gdjs.Level_326Code.GDBullObjects4= [];
gdjs.Level_326Code.GDBullObjects5= [];
gdjs.Level_326Code.GDBullObjects6= [];
gdjs.Level_326Code.GDBullObjects7= [];
gdjs.Level_326Code.GDClick_95text2Objects1= [];
gdjs.Level_326Code.GDClick_95text2Objects2= [];
gdjs.Level_326Code.GDClick_95text2Objects3= [];
gdjs.Level_326Code.GDClick_95text2Objects4= [];
gdjs.Level_326Code.GDClick_95text2Objects5= [];
gdjs.Level_326Code.GDClick_95text2Objects6= [];
gdjs.Level_326Code.GDClick_95text2Objects7= [];
gdjs.Level_326Code.GDPlay_95TextObjects1= [];
gdjs.Level_326Code.GDPlay_95TextObjects2= [];
gdjs.Level_326Code.GDPlay_95TextObjects3= [];
gdjs.Level_326Code.GDPlay_95TextObjects4= [];
gdjs.Level_326Code.GDPlay_95TextObjects5= [];
gdjs.Level_326Code.GDPlay_95TextObjects6= [];
gdjs.Level_326Code.GDPlay_95TextObjects7= [];
gdjs.Level_326Code.GDLeaderboardObjects1= [];
gdjs.Level_326Code.GDLeaderboardObjects2= [];
gdjs.Level_326Code.GDLeaderboardObjects3= [];
gdjs.Level_326Code.GDLeaderboardObjects4= [];
gdjs.Level_326Code.GDLeaderboardObjects5= [];
gdjs.Level_326Code.GDLeaderboardObjects6= [];
gdjs.Level_326Code.GDLeaderboardObjects7= [];
gdjs.Level_326Code.GDLeatherShoesObjects1= [];
gdjs.Level_326Code.GDLeatherShoesObjects2= [];
gdjs.Level_326Code.GDLeatherShoesObjects3= [];
gdjs.Level_326Code.GDLeatherShoesObjects4= [];
gdjs.Level_326Code.GDLeatherShoesObjects5= [];
gdjs.Level_326Code.GDLeatherShoesObjects6= [];
gdjs.Level_326Code.GDLeatherShoesObjects7= [];
gdjs.Level_326Code.GDFurnitureObjects1= [];
gdjs.Level_326Code.GDFurnitureObjects2= [];
gdjs.Level_326Code.GDFurnitureObjects3= [];
gdjs.Level_326Code.GDFurnitureObjects4= [];
gdjs.Level_326Code.GDFurnitureObjects5= [];
gdjs.Level_326Code.GDFurnitureObjects6= [];
gdjs.Level_326Code.GDFurnitureObjects7= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects1= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects2= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects3= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects4= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects5= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects6= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects7= [];
gdjs.Level_326Code.GDtoysObjects1= [];
gdjs.Level_326Code.GDtoysObjects2= [];
gdjs.Level_326Code.GDtoysObjects3= [];
gdjs.Level_326Code.GDtoysObjects4= [];
gdjs.Level_326Code.GDtoysObjects5= [];
gdjs.Level_326Code.GDtoysObjects6= [];
gdjs.Level_326Code.GDtoysObjects7= [];
gdjs.Level_326Code.GDMainMenu_95TextObjects1= [];
gdjs.Level_326Code.GDMainMenu_95TextObjects2= [];
gdjs.Level_326Code.GDMainMenu_95TextObjects3= [];
gdjs.Level_326Code.GDMainMenu_95TextObjects4= [];
gdjs.Level_326Code.GDMainMenu_95TextObjects5= [];
gdjs.Level_326Code.GDMainMenu_95TextObjects6= [];
gdjs.Level_326Code.GDMainMenu_95TextObjects7= [];
gdjs.Level_326Code.GDResetProgress_95TextObjects1= [];
gdjs.Level_326Code.GDResetProgress_95TextObjects2= [];
gdjs.Level_326Code.GDResetProgress_95TextObjects3= [];
gdjs.Level_326Code.GDResetProgress_95TextObjects4= [];
gdjs.Level_326Code.GDResetProgress_95TextObjects5= [];
gdjs.Level_326Code.GDResetProgress_95TextObjects6= [];
gdjs.Level_326Code.GDResetProgress_95TextObjects7= [];
gdjs.Level_326Code.GDStartOver_95TextObjects1= [];
gdjs.Level_326Code.GDStartOver_95TextObjects2= [];
gdjs.Level_326Code.GDStartOver_95TextObjects3= [];
gdjs.Level_326Code.GDStartOver_95TextObjects4= [];
gdjs.Level_326Code.GDStartOver_95TextObjects5= [];
gdjs.Level_326Code.GDStartOver_95TextObjects6= [];
gdjs.Level_326Code.GDStartOver_95TextObjects7= [];
gdjs.Level_326Code.GDSubmit_95TextObjects1= [];
gdjs.Level_326Code.GDSubmit_95TextObjects2= [];
gdjs.Level_326Code.GDSubmit_95TextObjects3= [];
gdjs.Level_326Code.GDSubmit_95TextObjects4= [];
gdjs.Level_326Code.GDSubmit_95TextObjects5= [];
gdjs.Level_326Code.GDSubmit_95TextObjects6= [];
gdjs.Level_326Code.GDSubmit_95TextObjects7= [];
gdjs.Level_326Code.GDChina_95textObjects1= [];
gdjs.Level_326Code.GDChina_95textObjects2= [];
gdjs.Level_326Code.GDChina_95textObjects3= [];
gdjs.Level_326Code.GDChina_95textObjects4= [];
gdjs.Level_326Code.GDChina_95textObjects5= [];
gdjs.Level_326Code.GDChina_95textObjects6= [];
gdjs.Level_326Code.GDChina_95textObjects7= [];
gdjs.Level_326Code.GDSection_95text1Objects1= [];
gdjs.Level_326Code.GDSection_95text1Objects2= [];
gdjs.Level_326Code.GDSection_95text1Objects3= [];
gdjs.Level_326Code.GDSection_95text1Objects4= [];
gdjs.Level_326Code.GDSection_95text1Objects5= [];
gdjs.Level_326Code.GDSection_95text1Objects6= [];
gdjs.Level_326Code.GDSection_95text1Objects7= [];
gdjs.Level_326Code.GDSource_95textObjects1= [];
gdjs.Level_326Code.GDSource_95textObjects2= [];
gdjs.Level_326Code.GDSource_95textObjects3= [];
gdjs.Level_326Code.GDSource_95textObjects4= [];
gdjs.Level_326Code.GDSource_95textObjects5= [];
gdjs.Level_326Code.GDSource_95textObjects6= [];
gdjs.Level_326Code.GDSource_95textObjects7= [];
gdjs.Level_326Code.GDYear_95textObjects1= [];
gdjs.Level_326Code.GDYear_95textObjects2= [];
gdjs.Level_326Code.GDYear_95textObjects3= [];
gdjs.Level_326Code.GDYear_95textObjects4= [];
gdjs.Level_326Code.GDYear_95textObjects5= [];
gdjs.Level_326Code.GDYear_95textObjects6= [];
gdjs.Level_326Code.GDYear_95textObjects7= [];
gdjs.Level_326Code.GDYesObjects1= [];
gdjs.Level_326Code.GDYesObjects2= [];
gdjs.Level_326Code.GDYesObjects3= [];
gdjs.Level_326Code.GDYesObjects4= [];
gdjs.Level_326Code.GDYesObjects5= [];
gdjs.Level_326Code.GDYesObjects6= [];
gdjs.Level_326Code.GDYesObjects7= [];
gdjs.Level_326Code.GDYes2Objects1= [];
gdjs.Level_326Code.GDYes2Objects2= [];
gdjs.Level_326Code.GDYes2Objects3= [];
gdjs.Level_326Code.GDYes2Objects4= [];
gdjs.Level_326Code.GDYes2Objects5= [];
gdjs.Level_326Code.GDYes2Objects6= [];
gdjs.Level_326Code.GDYes2Objects7= [];
gdjs.Level_326Code.GDYes3Objects1= [];
gdjs.Level_326Code.GDYes3Objects2= [];
gdjs.Level_326Code.GDYes3Objects3= [];
gdjs.Level_326Code.GDYes3Objects4= [];
gdjs.Level_326Code.GDYes3Objects5= [];
gdjs.Level_326Code.GDYes3Objects6= [];
gdjs.Level_326Code.GDYes3Objects7= [];
gdjs.Level_326Code.GDYes32Objects1= [];
gdjs.Level_326Code.GDYes32Objects2= [];
gdjs.Level_326Code.GDYes32Objects3= [];
gdjs.Level_326Code.GDYes32Objects4= [];
gdjs.Level_326Code.GDYes32Objects5= [];
gdjs.Level_326Code.GDYes32Objects6= [];
gdjs.Level_326Code.GDYes32Objects7= [];
gdjs.Level_326Code.GDYes4Objects1= [];
gdjs.Level_326Code.GDYes4Objects2= [];
gdjs.Level_326Code.GDYes4Objects3= [];
gdjs.Level_326Code.GDYes4Objects4= [];
gdjs.Level_326Code.GDYes4Objects5= [];
gdjs.Level_326Code.GDYes4Objects6= [];
gdjs.Level_326Code.GDYes4Objects7= [];
gdjs.Level_326Code.GDYes5Objects1= [];
gdjs.Level_326Code.GDYes5Objects2= [];
gdjs.Level_326Code.GDYes5Objects3= [];
gdjs.Level_326Code.GDYes5Objects4= [];
gdjs.Level_326Code.GDYes5Objects5= [];
gdjs.Level_326Code.GDYes5Objects6= [];
gdjs.Level_326Code.GDYes5Objects7= [];
gdjs.Level_326Code.GDYes6Objects1= [];
gdjs.Level_326Code.GDYes6Objects2= [];
gdjs.Level_326Code.GDYes6Objects3= [];
gdjs.Level_326Code.GDYes6Objects4= [];
gdjs.Level_326Code.GDYes6Objects5= [];
gdjs.Level_326Code.GDYes6Objects6= [];
gdjs.Level_326Code.GDYes6Objects7= [];
gdjs.Level_326Code.GDYes7Objects1= [];
gdjs.Level_326Code.GDYes7Objects2= [];
gdjs.Level_326Code.GDYes7Objects3= [];
gdjs.Level_326Code.GDYes7Objects4= [];
gdjs.Level_326Code.GDYes7Objects5= [];
gdjs.Level_326Code.GDYes7Objects6= [];
gdjs.Level_326Code.GDYes7Objects7= [];
gdjs.Level_326Code.GDYes8Objects1= [];
gdjs.Level_326Code.GDYes8Objects2= [];
gdjs.Level_326Code.GDYes8Objects3= [];
gdjs.Level_326Code.GDYes8Objects4= [];
gdjs.Level_326Code.GDYes8Objects5= [];
gdjs.Level_326Code.GDYes8Objects6= [];
gdjs.Level_326Code.GDYes8Objects7= [];
gdjs.Level_326Code.GDChinaObjects1= [];
gdjs.Level_326Code.GDChinaObjects2= [];
gdjs.Level_326Code.GDChinaObjects3= [];
gdjs.Level_326Code.GDChinaObjects4= [];
gdjs.Level_326Code.GDChinaObjects5= [];
gdjs.Level_326Code.GDChinaObjects6= [];
gdjs.Level_326Code.GDChinaObjects7= [];
gdjs.Level_326Code.GDNoObjects1= [];
gdjs.Level_326Code.GDNoObjects2= [];
gdjs.Level_326Code.GDNoObjects3= [];
gdjs.Level_326Code.GDNoObjects4= [];
gdjs.Level_326Code.GDNoObjects5= [];
gdjs.Level_326Code.GDNoObjects6= [];
gdjs.Level_326Code.GDNoObjects7= [];
gdjs.Level_326Code.GDNo2Objects1= [];
gdjs.Level_326Code.GDNo2Objects2= [];
gdjs.Level_326Code.GDNo2Objects3= [];
gdjs.Level_326Code.GDNo2Objects4= [];
gdjs.Level_326Code.GDNo2Objects5= [];
gdjs.Level_326Code.GDNo2Objects6= [];
gdjs.Level_326Code.GDNo2Objects7= [];
gdjs.Level_326Code.GDNo3Objects1= [];
gdjs.Level_326Code.GDNo3Objects2= [];
gdjs.Level_326Code.GDNo3Objects3= [];
gdjs.Level_326Code.GDNo3Objects4= [];
gdjs.Level_326Code.GDNo3Objects5= [];
gdjs.Level_326Code.GDNo3Objects6= [];
gdjs.Level_326Code.GDNo3Objects7= [];
gdjs.Level_326Code.GDNo4Objects1= [];
gdjs.Level_326Code.GDNo4Objects2= [];
gdjs.Level_326Code.GDNo4Objects3= [];
gdjs.Level_326Code.GDNo4Objects4= [];
gdjs.Level_326Code.GDNo4Objects5= [];
gdjs.Level_326Code.GDNo4Objects6= [];
gdjs.Level_326Code.GDNo4Objects7= [];
gdjs.Level_326Code.GDNo5Objects1= [];
gdjs.Level_326Code.GDNo5Objects2= [];
gdjs.Level_326Code.GDNo5Objects3= [];
gdjs.Level_326Code.GDNo5Objects4= [];
gdjs.Level_326Code.GDNo5Objects5= [];
gdjs.Level_326Code.GDNo5Objects6= [];
gdjs.Level_326Code.GDNo5Objects7= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects1= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects2= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects3= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects4= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects5= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects6= [];
gdjs.Level_326Code.GDBallsInCup_95TextObjects7= [];
gdjs.Level_326Code.GDQ_955Objects1= [];
gdjs.Level_326Code.GDQ_955Objects2= [];
gdjs.Level_326Code.GDQ_955Objects3= [];
gdjs.Level_326Code.GDQ_955Objects4= [];
gdjs.Level_326Code.GDQ_955Objects5= [];
gdjs.Level_326Code.GDQ_955Objects6= [];
gdjs.Level_326Code.GDQ_955Objects7= [];
gdjs.Level_326Code.GDPickupTruckLargeObjects1= [];
gdjs.Level_326Code.GDPickupTruckLargeObjects2= [];
gdjs.Level_326Code.GDPickupTruckLargeObjects3= [];
gdjs.Level_326Code.GDPickupTruckLargeObjects4= [];
gdjs.Level_326Code.GDPickupTruckLargeObjects5= [];
gdjs.Level_326Code.GDPickupTruckLargeObjects6= [];
gdjs.Level_326Code.GDPickupTruckLargeObjects7= [];
gdjs.Level_326Code.GDFurnitureObjects1= [];
gdjs.Level_326Code.GDFurnitureObjects2= [];
gdjs.Level_326Code.GDFurnitureObjects3= [];
gdjs.Level_326Code.GDFurnitureObjects4= [];
gdjs.Level_326Code.GDFurnitureObjects5= [];
gdjs.Level_326Code.GDFurnitureObjects6= [];
gdjs.Level_326Code.GDFurnitureObjects7= [];
gdjs.Level_326Code.GDSandwichDishObjects1= [];
gdjs.Level_326Code.GDSandwichDishObjects2= [];
gdjs.Level_326Code.GDSandwichDishObjects3= [];
gdjs.Level_326Code.GDSandwichDishObjects4= [];
gdjs.Level_326Code.GDSandwichDishObjects5= [];
gdjs.Level_326Code.GDSandwichDishObjects6= [];
gdjs.Level_326Code.GDSandwichDishObjects7= [];
gdjs.Level_326Code.GDOldComputerMonitorObjects1= [];
gdjs.Level_326Code.GDOldComputerMonitorObjects2= [];
gdjs.Level_326Code.GDOldComputerMonitorObjects3= [];
gdjs.Level_326Code.GDOldComputerMonitorObjects4= [];
gdjs.Level_326Code.GDOldComputerMonitorObjects5= [];
gdjs.Level_326Code.GDOldComputerMonitorObjects6= [];
gdjs.Level_326Code.GDOldComputerMonitorObjects7= [];
gdjs.Level_326Code.GDLeatherShoesObjects1= [];
gdjs.Level_326Code.GDLeatherShoesObjects2= [];
gdjs.Level_326Code.GDLeatherShoesObjects3= [];
gdjs.Level_326Code.GDLeatherShoesObjects4= [];
gdjs.Level_326Code.GDLeatherShoesObjects5= [];
gdjs.Level_326Code.GDLeatherShoesObjects6= [];
gdjs.Level_326Code.GDLeatherShoesObjects7= [];
gdjs.Level_326Code.GDMachinesObjects1= [];
gdjs.Level_326Code.GDMachinesObjects2= [];
gdjs.Level_326Code.GDMachinesObjects3= [];
gdjs.Level_326Code.GDMachinesObjects4= [];
gdjs.Level_326Code.GDMachinesObjects5= [];
gdjs.Level_326Code.GDMachinesObjects6= [];
gdjs.Level_326Code.GDMachinesObjects7= [];
gdjs.Level_326Code.GDTransportationsObjects1= [];
gdjs.Level_326Code.GDTransportationsObjects2= [];
gdjs.Level_326Code.GDTransportationsObjects3= [];
gdjs.Level_326Code.GDTransportationsObjects4= [];
gdjs.Level_326Code.GDTransportationsObjects5= [];
gdjs.Level_326Code.GDTransportationsObjects6= [];
gdjs.Level_326Code.GDTransportationsObjects7= [];
gdjs.Level_326Code.GDFurniture_95textObjects1= [];
gdjs.Level_326Code.GDFurniture_95textObjects2= [];
gdjs.Level_326Code.GDFurniture_95textObjects3= [];
gdjs.Level_326Code.GDFurniture_95textObjects4= [];
gdjs.Level_326Code.GDFurniture_95textObjects5= [];
gdjs.Level_326Code.GDFurniture_95textObjects6= [];
gdjs.Level_326Code.GDFurniture_95textObjects7= [];
gdjs.Level_326Code.GDPaperObjects1= [];
gdjs.Level_326Code.GDPaperObjects2= [];
gdjs.Level_326Code.GDPaperObjects3= [];
gdjs.Level_326Code.GDPaperObjects4= [];
gdjs.Level_326Code.GDPaperObjects5= [];
gdjs.Level_326Code.GDPaperObjects6= [];
gdjs.Level_326Code.GDPaperObjects7= [];
gdjs.Level_326Code.GDAnimalObjects1= [];
gdjs.Level_326Code.GDAnimalObjects2= [];
gdjs.Level_326Code.GDAnimalObjects3= [];
gdjs.Level_326Code.GDAnimalObjects4= [];
gdjs.Level_326Code.GDAnimalObjects5= [];
gdjs.Level_326Code.GDAnimalObjects6= [];
gdjs.Level_326Code.GDAnimalObjects7= [];
gdjs.Level_326Code.GDGlassObjects1= [];
gdjs.Level_326Code.GDGlassObjects2= [];
gdjs.Level_326Code.GDGlassObjects3= [];
gdjs.Level_326Code.GDGlassObjects4= [];
gdjs.Level_326Code.GDGlassObjects5= [];
gdjs.Level_326Code.GDGlassObjects6= [];
gdjs.Level_326Code.GDGlassObjects7= [];
gdjs.Level_326Code.GDToyObjects1= [];
gdjs.Level_326Code.GDToyObjects2= [];
gdjs.Level_326Code.GDToyObjects3= [];
gdjs.Level_326Code.GDToyObjects4= [];
gdjs.Level_326Code.GDToyObjects5= [];
gdjs.Level_326Code.GDToyObjects6= [];
gdjs.Level_326Code.GDToyObjects7= [];
gdjs.Level_326Code.GDTextileObjects1= [];
gdjs.Level_326Code.GDTextileObjects2= [];
gdjs.Level_326Code.GDTextileObjects3= [];
gdjs.Level_326Code.GDTextileObjects4= [];
gdjs.Level_326Code.GDTextileObjects5= [];
gdjs.Level_326Code.GDTextileObjects6= [];
gdjs.Level_326Code.GDTextileObjects7= [];
gdjs.Level_326Code.GDFootwearObjects1= [];
gdjs.Level_326Code.GDFootwearObjects2= [];
gdjs.Level_326Code.GDFootwearObjects3= [];
gdjs.Level_326Code.GDFootwearObjects4= [];
gdjs.Level_326Code.GDFootwearObjects5= [];
gdjs.Level_326Code.GDFootwearObjects6= [];
gdjs.Level_326Code.GDFootwearObjects7= [];
gdjs.Level_326Code.GDYarnObjects1= [];
gdjs.Level_326Code.GDYarnObjects2= [];
gdjs.Level_326Code.GDYarnObjects3= [];
gdjs.Level_326Code.GDYarnObjects4= [];
gdjs.Level_326Code.GDYarnObjects5= [];
gdjs.Level_326Code.GDYarnObjects6= [];
gdjs.Level_326Code.GDYarnObjects7= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects1= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects2= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects3= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects4= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects5= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects6= [];
gdjs.Level_326Code.GDMagnifyingGlassObjects7= [];
gdjs.Level_326Code.GDtoysObjects1= [];
gdjs.Level_326Code.GDtoysObjects2= [];
gdjs.Level_326Code.GDtoysObjects3= [];
gdjs.Level_326Code.GDtoysObjects4= [];
gdjs.Level_326Code.GDtoysObjects5= [];
gdjs.Level_326Code.GDtoysObjects6= [];
gdjs.Level_326Code.GDtoysObjects7= [];
gdjs.Level_326Code.GDBullObjects1= [];
gdjs.Level_326Code.GDBullObjects2= [];
gdjs.Level_326Code.GDBullObjects3= [];
gdjs.Level_326Code.GDBullObjects4= [];
gdjs.Level_326Code.GDBullObjects5= [];
gdjs.Level_326Code.GDBullObjects6= [];
gdjs.Level_326Code.GDBullObjects7= [];
gdjs.Level_326Code.GDPaperBagObjects1= [];
gdjs.Level_326Code.GDPaperBagObjects2= [];
gdjs.Level_326Code.GDPaperBagObjects3= [];
gdjs.Level_326Code.GDPaperBagObjects4= [];
gdjs.Level_326Code.GDPaperBagObjects5= [];
gdjs.Level_326Code.GDPaperBagObjects6= [];
gdjs.Level_326Code.GDPaperBagObjects7= [];
gdjs.Level_326Code.GDQ_956Objects1= [];
gdjs.Level_326Code.GDQ_956Objects2= [];
gdjs.Level_326Code.GDQ_956Objects3= [];
gdjs.Level_326Code.GDQ_956Objects4= [];
gdjs.Level_326Code.GDQ_956Objects5= [];
gdjs.Level_326Code.GDQ_956Objects6= [];
gdjs.Level_326Code.GDQ_956Objects7= [];

gdjs.Level_326Code.conditionTrue_0 = {val:false};
gdjs.Level_326Code.condition0IsTrue_0 = {val:false};
gdjs.Level_326Code.condition1IsTrue_0 = {val:false};
gdjs.Level_326Code.condition2IsTrue_0 = {val:false};
gdjs.Level_326Code.condition3IsTrue_0 = {val:false};
gdjs.Level_326Code.condition4IsTrue_0 = {val:false};
gdjs.Level_326Code.conditionTrue_1 = {val:false};
gdjs.Level_326Code.condition0IsTrue_1 = {val:false};
gdjs.Level_326Code.condition1IsTrue_1 = {val:false};
gdjs.Level_326Code.condition2IsTrue_1 = {val:false};
gdjs.Level_326Code.condition3IsTrue_1 = {val:false};
gdjs.Level_326Code.condition4IsTrue_1 = {val:false};
gdjs.Level_326Code.conditionTrue_2 = {val:false};
gdjs.Level_326Code.condition0IsTrue_2 = {val:false};
gdjs.Level_326Code.condition1IsTrue_2 = {val:false};
gdjs.Level_326Code.condition2IsTrue_2 = {val:false};
gdjs.Level_326Code.condition3IsTrue_2 = {val:false};
gdjs.Level_326Code.condition4IsTrue_2 = {val:false};


gdjs.Level_326Code.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "PlayTimer", runtimeScene, runtimeScene.getVariables().get("PlayTimer"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "MovesMade", runtimeScene, runtimeScene.getVariables().get("MovesMade"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "CurrentLevel", runtimeScene, runtimeScene.getVariables().get("CurrentLevel"));
}}

}


};gdjs.Level_326Code.eventsList1 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PlayTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "PlayTimer");
}}

}


};gdjs.Level_326Code.eventsList2 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Shared UI", 0, 0);
}}

}


{


{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Debugging");
}}

}


{


{
}

}


{


gdjs.Level_326Code.eventsList1(runtimeScene);
}


};gdjs.Level_326Code.eventsList3 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cloud1"), gdjs.Level_326Code.GDCloud1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud2"), gdjs.Level_326Code.GDCloud2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud3"), gdjs.Level_326Code.GDCloud3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud4"), gdjs.Level_326Code.GDCloud4Objects4);
{for(var i = 0, len = gdjs.Level_326Code.GDCloud1Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDCloud1Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_326Code.GDCloud2Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDCloud2Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_326Code.GDCloud3Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDCloud3Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_326Code.GDCloud4Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDCloud4Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
}{for(var i = 0, len = gdjs.Level_326Code.GDCloud1Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDCloud1Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_326Code.GDCloud2Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDCloud2Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_326Code.GDCloud3Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDCloud3Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_326Code.GDCloud4Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDCloud4Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
}}

}


};gdjs.Level_326Code.eventsList4 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Clouds", 0, 0);
}
{ //Subevents
gdjs.Level_326Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList5 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) + 0), "", 0);
}}

}


{



}


{


{
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "SlideCameraIn", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 1000, "easeOutBack");
}}

}


};gdjs.Level_326Code.asyncCallback11127148 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getVariables().get("GameState").setString("Idle");
}}
gdjs.Level_326Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11127148(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList7 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("StartingZoom").setNumber(0.65);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("StartingZoom")), "", 0);
}}

}


{


gdjs.Level_326Code.eventsList5(runtimeScene);
}


{


{

{ //Subevents
gdjs.Level_326Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList8 = function(runtimeScene) {

{



}


};gdjs.Level_326Code.eventsList9 = function(runtimeScene) {

{



}


};gdjs.Level_326Code.eventsList10 = function(runtimeScene) {

{


gdjs.Level_326Code.eventsList0(runtimeScene);
}


{


gdjs.Level_326Code.eventsList2(runtimeScene);
}


{


gdjs.Level_326Code.eventsList4(runtimeScene);
}


{



}


{


gdjs.Level_326Code.eventsList7(runtimeScene);
}


{



}


{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ExplosionDelay");
}}

}


{



}


{


{
{runtimeScene.getVariables().get("PickupBall_Duration").setNumber(125);
}{runtimeScene.getVariables().get("MoveBall_Duration").setNumber(150);
}{runtimeScene.getVariables().get("DropBall_Duration").setNumber(150);
}{/* Unknown object - skipped. */}{runtimeScene.getVariables().get("MaxBallsPerCup").setNumber(4);
}}

}


{


gdjs.Level_326Code.eventsList8(runtimeScene);
}


{


gdjs.Level_326Code.eventsList9(runtimeScene);
}


};gdjs.Level_326Code.eventsList11 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDBall_95951Objects3ObjectsGDgdjs_46Level_95326Code_46GDBall_95954Objects3ObjectsGDgdjs_46Level_95326Code_46GDBall_95955Objects3ObjectsGDgdjs_46Level_95326Code_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_326Code.GDBall_951Objects3, "Ball_4": gdjs.Level_326Code.GDBall_954Objects3, "Ball_5": gdjs.Level_326Code.GDBall_955Objects3, "Ball_6": gdjs.Level_326Code.GDBall_956Objects3});
gdjs.Level_326Code.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DraggingBall");
}}

}


{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("BallFloating");
}}

}


};gdjs.Level_326Code.asyncCallback11140508 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Level_326Code.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_326Code.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11140508(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList14 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.Level_326Code.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList15 = function(runtimeScene) {

{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Nikolay Overchenko - Whoosh, cartoon, whirring 2.aac", false, 20, gdjs.randomFloatInRange(1.5, 1.7));
}{gdjs.deviceVibration.startVibration(25);
}}

}


{



}


{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "PlayTimer");
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "PlayTimer");
}}

}


{


gdjs.Level_326Code.eventsList14(runtimeScene);
}


};gdjs.Level_326Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_326Code.GDBall_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_326Code.GDBall_954Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_326Code.GDBall_955Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_326Code.GDBall_956Objects3);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
gdjs.Level_326Code.condition2IsTrue_0.val = false;
gdjs.Level_326Code.condition3IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
/* Unknown object - skipped. */}if ( gdjs.Level_326Code.condition1IsTrue_0.val ) {
{
gdjs.Level_326Code.condition2IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDBall_95951Objects3ObjectsGDgdjs_46Level_95326Code_46GDBall_95954Objects3ObjectsGDgdjs_46Level_95326Code_46GDBall_95955Objects3ObjectsGDgdjs_46Level_95326Code_46GDBall_95956Objects3Objects, 0, 0, false);
}if ( gdjs.Level_326Code.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_951Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_326Code.GDBall_951Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_326Code.condition3IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_951Objects3[k] = gdjs.Level_326Code.GDBall_951Objects3[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_951Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_954Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_326Code.GDBall_954Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_326Code.condition3IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_954Objects3[k] = gdjs.Level_326Code.GDBall_954Objects3[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_954Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_955Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_326Code.GDBall_955Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_326Code.condition3IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_955Objects3[k] = gdjs.Level_326Code.GDBall_955Objects3[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_955Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_956Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_326Code.GDBall_956Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_326Code.condition3IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_956Objects3[k] = gdjs.Level_326Code.GDBall_956Objects3[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_956Objects3.length = k;}}
}
}
if (gdjs.Level_326Code.condition3IsTrue_0.val) {
/* Reuse gdjs.Level_326Code.GDBall_951Objects3 */
/* Reuse gdjs.Level_326Code.GDBall_954Objects3 */
/* Reuse gdjs.Level_326Code.GDBall_955Objects3 */
/* Reuse gdjs.Level_326Code.GDBall_956Objects3 */
{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", 0 - 1.1 * (gdjs.Level_326Code.GDBall_951Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", 0 - 1.1 * (gdjs.Level_326Code.GDBall_954Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", 0 - 1.1 * (gdjs.Level_326Code.GDBall_955Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", 0 - 1.1 * (gdjs.Level_326Code.GDBall_956Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
}{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects3[i].setVariableBoolean(gdjs.Level_326Code.GDBall_951Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects3[i].setVariableBoolean(gdjs.Level_326Code.GDBall_954Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects3[i].setVariableBoolean(gdjs.Level_326Code.GDBall_955Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects3[i].setVariableBoolean(gdjs.Level_326Code.GDBall_956Objects3[i].getVariables().get("PickedUp"), true);
}
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{runtimeScene.getVariables().get("HoverOffsetX").setNumber(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 0);
}{runtimeScene.getVariables().get("HoverOffsetY").setNumber(gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 0 + 1.1 * (( gdjs.Level_326Code.GDBall_956Objects3.length === 0 ) ? (( gdjs.Level_326Code.GDBall_955Objects3.length === 0 ) ? (( gdjs.Level_326Code.GDBall_954Objects3.length === 0 ) ? (( gdjs.Level_326Code.GDBall_951Objects3.length === 0 ) ? 0 :gdjs.Level_326Code.GDBall_951Objects3[0].getHeight()) :gdjs.Level_326Code.GDBall_954Objects3[0].getHeight()) :gdjs.Level_326Code.GDBall_955Objects3[0].getHeight()) :gdjs.Level_326Code.GDBall_956Objects3[0].getHeight()));
}{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects3[i].setLayer("FrontCups");
}
}
{ //Subevents
gdjs.Level_326Code.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList17 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition1IsTrue_0;
gdjs.Level_326Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11134756);
}
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList18 = function(runtimeScene) {

{


gdjs.Level_326Code.eventsList17(runtimeScene);
}


};gdjs.Level_326Code.eventsList19 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "Idle";
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList20 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition1IsTrue_0;
gdjs.Level_326Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11142524);
}
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DroppingBall");
}}

}


};gdjs.Level_326Code.eventsList21 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "BallFloating";
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_326Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_326Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_326Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_326Code.GDBall_956Objects4);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_951Objects4[k] = gdjs.Level_326Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_954Objects4[k] = gdjs.Level_326Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_955Objects4[k] = gdjs.Level_326Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_956Objects4[k] = gdjs.Level_326Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_956Objects4.length = k;}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_326Code.GDBall_951Objects4 */
/* Reuse gdjs.Level_326Code.GDBall_954Objects4 */
/* Reuse gdjs.Level_326Code.GDBall_955Objects4 */
/* Reuse gdjs.Level_326Code.GDBall_956Objects4 */
{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_326Code.GDBall_951Objects4[i].getX()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_326Code.GDBall_951Objects4[i].getY()), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_326Code.GDBall_954Objects4[i].getX()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_326Code.GDBall_954Objects4[i].getY()), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_326Code.GDBall_955Objects4[i].getX()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_326Code.GDBall_955Objects4[i].getY()), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_326Code.GDBall_956Objects4[i].getX()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_326Code.GDBall_956Objects4[i].getY()), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
}}

}


{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DroppingBall");
}}

}


};gdjs.Level_326Code.eventsList23 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "DraggingBall";
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList24 = function(runtimeScene) {

{


{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), false);
}{/* Unknown object - skipped. */}}

}


};gdjs.Level_326Code.eventsList25 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}{/* Unknown object - skipped. */}}

}


{



}


{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
/* Unknown object - skipped. */}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}{/* Unknown object - skipped. */}}

}


};gdjs.Level_326Code.eventsList26 = function(runtimeScene) {

{



}


{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.asyncCallback11111428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Level_326Code.GDBall_951Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Level_326Code.GDBall_954Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Level_326Code.GDBall_955Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Level_326Code.GDBall_956Objects6);

{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects6.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects6.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects6.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects6.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects6[i].setLayer("Balls");
}
}{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects6.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_326Code.GDBall_951Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects6.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_326Code.GDBall_954Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects6.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_326Code.GDBall_955Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects6.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_326Code.GDBall_956Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
}{/* Unknown object - skipped. */}}
gdjs.Level_326Code.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_326Code.GDBall_951Objects5) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Level_326Code.GDBall_954Objects5) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Level_326Code.GDBall_955Objects5) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Level_326Code.GDBall_956Objects5) asyncObjectsList.addObject("Ball_6", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11111428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList28 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("MovesMade").add(1);
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_326Code.GDBall_951Objects4, gdjs.Level_326Code.GDBall_951Objects5);

gdjs.copyArray(gdjs.Level_326Code.GDBall_954Objects4, gdjs.Level_326Code.GDBall_954Objects5);

gdjs.copyArray(gdjs.Level_326Code.GDBall_955Objects4, gdjs.Level_326Code.GDBall_955Objects5);

gdjs.copyArray(gdjs.Level_326Code.GDBall_956Objects4, gdjs.Level_326Code.GDBall_956Objects5);

{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_326Code.GDBall_951Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_326Code.GDBall_954Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_326Code.GDBall_955Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_326Code.GDBall_956Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
}{gdjs.deviceVibration.startVibration(25);
}
{ //Subevents
gdjs.Level_326Code.eventsList27(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList29 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
gdjs.Level_326Code.condition2IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
/* Unknown object - skipped. */}if ( gdjs.Level_326Code.condition1IsTrue_0.val ) {
{
/* Unknown object - skipped. */}}
}
if (gdjs.Level_326Code.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.asyncCallback11111429 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Level_326Code.GDBall_951Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Level_326Code.GDBall_954Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Level_326Code.GDBall_955Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Level_326Code.GDBall_956Objects5);

{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects5[i].setLayer("Balls");
}
}{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_326Code.GDBall_951Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_326Code.GDBall_954Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_326Code.GDBall_955Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_326Code.GDBall_956Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
}{/* Unknown object - skipped. */}}
gdjs.Level_326Code.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_326Code.GDBall_951Objects4) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Level_326Code.GDBall_954Objects4) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Level_326Code.GDBall_955Objects4) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Level_326Code.GDBall_956Objects4) asyncObjectsList.addObject("Ball_6", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11111429(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList31 = function(runtimeScene) {

{



}


{


{
/* Reuse gdjs.Level_326Code.GDBall_951Objects4 */
/* Reuse gdjs.Level_326Code.GDBall_954Objects4 */
/* Reuse gdjs.Level_326Code.GDBall_955Objects4 */
/* Reuse gdjs.Level_326Code.GDBall_956Objects4 */
{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_326Code.GDBall_951Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_326Code.GDBall_954Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_326Code.GDBall_955Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_326Code.GDBall_956Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
}{gdjs.deviceVibration.startVibration(25);
}
{ //Subevents
gdjs.Level_326Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList32 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), false);
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
/* Unknown object - skipped. */}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList33 = function(runtimeScene) {

{


gdjs.Level_326Code.eventsList26(runtimeScene);
}


{


gdjs.Level_326Code.eventsList29(runtimeScene);
}


{


gdjs.Level_326Code.eventsList32(runtimeScene);
}


};gdjs.Level_326Code.eventsList34 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_326Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_326Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_326Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_326Code.GDBall_956Objects4);
{for(var i = 0, len = gdjs.Level_326Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_951Objects4[i].setVariableBoolean(gdjs.Level_326Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_954Objects4[i].setVariableBoolean(gdjs.Level_326Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_955Objects4[i].setVariableBoolean(gdjs.Level_326Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_326Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDBall_956Objects4[i].setVariableBoolean(gdjs.Level_326Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), false);
}
}}

}


};gdjs.Level_326Code.asyncCallback11155300 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.deviceVibration.startVibration(25);
}{runtimeScene.getVariables().get("GameState").setString("CheckIfComplete");
}}
gdjs.Level_326Code.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration"))) / 1000), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11155300(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList36 = function(runtimeScene) {

{


gdjs.Level_326Code.eventsList34(runtimeScene);
}


{


{

{ //Subevents
gdjs.Level_326Code.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList37 = function(runtimeScene) {

{


gdjs.Level_326Code.eventsList24(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_326Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_326Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_326Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_326Code.GDBall_956Objects4);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_951Objects4[k] = gdjs.Level_326Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_954Objects4[k] = gdjs.Level_326Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_955Objects4[k] = gdjs.Level_326Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_0.val = true;
        gdjs.Level_326Code.GDBall_956Objects4[k] = gdjs.Level_326Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_956Objects4.length = k;}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList33(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_326Code.eventsList36(runtimeScene);
}


};gdjs.Level_326Code.eventsList38 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "DroppingBall";
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition1IsTrue_0;
gdjs.Level_326Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11146012);
}
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList37(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4Objects = Hashtable.newFrom({"GdevelopGLogoWhite": gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects3Objects = Hashtable.newFrom({"GdevelopGLogoWhite": gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3});
gdjs.Level_326Code.asyncCallback11115444 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PauseMenu");
}}
gdjs.Level_326Code.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11115444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList40 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11114500);
}
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4Objects, runtimeScene, true, true);
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition1IsTrue_0;
gdjs.Level_326Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11112940);
}
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects3Objects, runtimeScene, true, false);
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.asyncCallback11117500 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Level_326Code.eventsList42 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11117500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.asyncCallback11117020 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("GdevelopGLogoWhite"), gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4);

{for(var i = 0, len = gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4[i].getBehavior("Tween").addObjectAngleTween("SpinLogo", 0, "swingFromTo", 1000, false);
}
}
{ //Subevents
gdjs.Level_326Code.eventsList42(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_326Code.eventsList43 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3) asyncObjectsList.addObject("GdevelopGLogoWhite", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11117020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList44 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.condition0IsTrue_1.val = false;
gdjs.Level_326Code.condition1IsTrue_1.val = false;
{
gdjs.Level_326Code.condition0IsTrue_1.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "SpinLogo", 20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if( gdjs.Level_326Code.condition0IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level_326Code.condition1IsTrue_1.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if( gdjs.Level_326Code.condition1IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3);
{for(var i = 0, len = gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3[i].getBehavior("Tween").addObjectAngleTween("SpinLogo", 360, "swingFromTo", 1000, false);
}
}
{ //Subevents
gdjs.Level_326Code.eventsList43(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_326Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_326Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_326Code.GDMenuObjects4});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_326Code.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Level_326Code.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Level_326Code.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Level_326Code.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Level_326Code.GDSubmit_95TextObjects4});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_326Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_326Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_326Code.GDMenuObjects4});
gdjs.Level_326Code.eventsList45 = function(runtimeScene) {

{

/* Reuse gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_326Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_326Code.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_326Code.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Level_326Code.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_326Code.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_326Code.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_326Code.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_326Code.GDSubmit_95TextObjects4);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDSubmit_9595TextObjects4Objects, gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_326Code.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Level_326Code.GDPlay_95TextObjects4 */
/* Reuse gdjs.Level_326Code.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Level_326Code.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Level_326Code.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Level_326Code.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDPlay_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDMainMenu_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDResetProgress_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDStartOver_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDSubmit_95TextObjects4[i].setColor("255;255;255");
}
}}

}


};gdjs.Level_326Code.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_326Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_326Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_326Code.GDMenuObjects4);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects, runtimeScene, true, true);
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_326Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_326Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_326Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_326Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGreyButtonObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDLeaderboardObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDMenuObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Level_326Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGreyButtonObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_326Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDLeaderboardObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_326Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDMenuObjects4[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.Level_326Code.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_326Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_326Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_326Code.GDMenuObjects4});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_326Code.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Level_326Code.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Level_326Code.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Level_326Code.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Level_326Code.GDSubmit_95TextObjects4});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_326Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_326Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_326Code.GDMenuObjects4});
gdjs.Level_326Code.eventsList47 = function(runtimeScene) {

{

/* Reuse gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_326Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_326Code.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_326Code.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Level_326Code.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_326Code.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_326Code.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_326Code.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_326Code.GDSubmit_95TextObjects4);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95326Code_46GDSubmit_9595TextObjects4Objects, gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_326Code.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Level_326Code.GDPlay_95TextObjects4 */
/* Reuse gdjs.Level_326Code.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Level_326Code.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Level_326Code.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Level_326Code.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDPlay_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_326Code.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDMainMenu_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_326Code.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDResetProgress_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_326Code.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDStartOver_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_326Code.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDSubmit_95TextObjects4[i].setColor("241;91;181");
}
}}

}


};gdjs.Level_326Code.eventsList48 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_326Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_326Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_326Code.GDMenuObjects4);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition1IsTrue_0;
gdjs.Level_326Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11173756);
}
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_326Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_326Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_326Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_326Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGreyButtonObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_326Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDLeaderboardObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_326Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDMenuObjects4[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.Level_326Code.eventsList47(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_326Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_326Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_326Code.GDMenuObjects4});
gdjs.Level_326Code.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_326Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_326Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_326Code.GDMenuObjects4);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_326Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_326Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_326Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_326Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGreyButtonObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_326Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDLeaderboardObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_326Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_326Code.GDMenuObjects4[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_326Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_326Code.GDLeaderboardObjects3, "GdevelopGLogoWhite": gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3, "Menu": gdjs.Level_326Code.GDMenuObjects3});
gdjs.Level_326Code.eventsList50 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition1IsTrue_0;
gdjs.Level_326Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11175812);
}
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList49(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_326Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_326Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_326Code.GDMenuObjects3);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
gdjs.Level_326Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_95326Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_95326Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_95326Code_46GDMenuObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3 */
/* Reuse gdjs.Level_326Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_326Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_326Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_326Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDGreyButtonObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDLeaderboardObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_326Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_326Code.GDMenuObjects3[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.Level_326Code.eventsList51 = function(runtimeScene) {

{


gdjs.Level_326Code.eventsList46(runtimeScene);
}


{


gdjs.Level_326Code.eventsList48(runtimeScene);
}


{


gdjs.Level_326Code.eventsList50(runtimeScene);
}


};gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDMenuObjects4Objects = Hashtable.newFrom({"Menu": gdjs.Level_326Code.GDMenuObjects4});
gdjs.Level_326Code.asyncCallback11158492 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PauseMenu");
}}
gdjs.Level_326Code.eventsList52 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11158492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList53 = function(runtimeScene) {

{

gdjs.Level_326Code.GDMenuObjects3.length = 0;


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.GDMenuObjects3_1final.length = 0;gdjs.Level_326Code.condition0IsTrue_1.val = false;
gdjs.Level_326Code.condition1IsTrue_1.val = false;
{
gdjs.Level_326Code.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if( gdjs.Level_326Code.condition0IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_326Code.GDMenuObjects4);
{gdjs.Level_326Code.conditionTrue_2 = gdjs.Level_326Code.condition1IsTrue_1;
gdjs.Level_326Code.condition0IsTrue_2.val = false;
gdjs.Level_326Code.condition1IsTrue_2.val = false;
{
gdjs.Level_326Code.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level_326Code.condition0IsTrue_2.val ) {
{
gdjs.Level_326Code.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
gdjs.Level_326Code.conditionTrue_2.val = true && gdjs.Level_326Code.condition0IsTrue_2.val && gdjs.Level_326Code.condition1IsTrue_2.val;
}
if( gdjs.Level_326Code.condition1IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_326Code.GDMenuObjects4.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDMenuObjects3_1final.indexOf(gdjs.Level_326Code.GDMenuObjects4[j]) === -1 )
            gdjs.Level_326Code.GDMenuObjects3_1final.push(gdjs.Level_326Code.GDMenuObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_326Code.GDMenuObjects3_1final, gdjs.Level_326Code.GDMenuObjects3);
}
}
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList52(runtimeScene);} //End of subevents
}

}


};gdjs.Level_326Code.eventsList54 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition1IsTrue_0;
gdjs.Level_326Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11159956);
}
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


};gdjs.Level_326Code.eventsList55 = function(runtimeScene) {

{


{
{/* Unknown object - skipped. */}}

}


{

gdjs.Level_326Code.GDBall_951Objects3.length = 0;

gdjs.Level_326Code.GDBall_954Objects3.length = 0;

gdjs.Level_326Code.GDBall_955Objects3.length = 0;

gdjs.Level_326Code.GDBall_956Objects3.length = 0;


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.GDBall_951Objects3_1final.length = 0;gdjs.Level_326Code.GDBall_954Objects3_1final.length = 0;gdjs.Level_326Code.GDBall_955Objects3_1final.length = 0;gdjs.Level_326Code.GDBall_956Objects3_1final.length = 0;gdjs.Level_326Code.condition0IsTrue_1.val = false;
gdjs.Level_326Code.condition1IsTrue_1.val = false;
{
/* Unknown object - skipped. */if( gdjs.Level_326Code.condition0IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_326Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_326Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_326Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_326Code.GDBall_956Objects4);
{gdjs.Level_326Code.conditionTrue_2 = gdjs.Level_326Code.condition1IsTrue_1;
gdjs.Level_326Code.condition0IsTrue_2.val = false;
gdjs.Level_326Code.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_2.val = true;
        gdjs.Level_326Code.GDBall_951Objects4[k] = gdjs.Level_326Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_2.val = true;
        gdjs.Level_326Code.GDBall_954Objects4[k] = gdjs.Level_326Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_2.val = true;
        gdjs.Level_326Code.GDBall_955Objects4[k] = gdjs.Level_326Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_326Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_326Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_326Code.condition0IsTrue_2.val = true;
        gdjs.Level_326Code.GDBall_956Objects4[k] = gdjs.Level_326Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_326Code.GDBall_956Objects4.length = k;}if ( gdjs.Level_326Code.condition0IsTrue_2.val ) {
{
/* Unknown object - skipped. */}}
gdjs.Level_326Code.conditionTrue_2.val = true && gdjs.Level_326Code.condition0IsTrue_2.val && gdjs.Level_326Code.condition1IsTrue_2.val;
}
if( gdjs.Level_326Code.condition1IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_326Code.GDBall_951Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDBall_951Objects3_1final.indexOf(gdjs.Level_326Code.GDBall_951Objects4[j]) === -1 )
            gdjs.Level_326Code.GDBall_951Objects3_1final.push(gdjs.Level_326Code.GDBall_951Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_326Code.GDBall_954Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDBall_954Objects3_1final.indexOf(gdjs.Level_326Code.GDBall_954Objects4[j]) === -1 )
            gdjs.Level_326Code.GDBall_954Objects3_1final.push(gdjs.Level_326Code.GDBall_954Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_326Code.GDBall_955Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDBall_955Objects3_1final.indexOf(gdjs.Level_326Code.GDBall_955Objects4[j]) === -1 )
            gdjs.Level_326Code.GDBall_955Objects3_1final.push(gdjs.Level_326Code.GDBall_955Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_326Code.GDBall_956Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDBall_956Objects3_1final.indexOf(gdjs.Level_326Code.GDBall_956Objects4[j]) === -1 )
            gdjs.Level_326Code.GDBall_956Objects3_1final.push(gdjs.Level_326Code.GDBall_956Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_326Code.GDBall_951Objects3_1final, gdjs.Level_326Code.GDBall_951Objects3);
gdjs.copyArray(gdjs.Level_326Code.GDBall_954Objects3_1final, gdjs.Level_326Code.GDBall_954Objects3);
gdjs.copyArray(gdjs.Level_326Code.GDBall_955Objects3_1final, gdjs.Level_326Code.GDBall_955Objects3);
gdjs.copyArray(gdjs.Level_326Code.GDBall_956Objects3_1final, gdjs.Level_326Code.GDBall_956Objects3);
}
}
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


};gdjs.Level_326Code.eventsList56 = function(runtimeScene) {

};gdjs.Level_326Code.eventsList57 = function(runtimeScene) {

{


{
{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Balls", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "FrontCups", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Debugging", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Clouds", 0, true, true, false, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level_326Code.eventsList58 = function(runtimeScene) {

{



}


{


gdjs.Level_326Code.eventsList41(runtimeScene);
}


{


gdjs.Level_326Code.eventsList44(runtimeScene);
}


{



}


{


gdjs.Level_326Code.eventsList51(runtimeScene);
}


{


gdjs.Level_326Code.eventsList53(runtimeScene);
}


{


gdjs.Level_326Code.eventsList54(runtimeScene);
}


{


gdjs.Level_326Code.eventsList55(runtimeScene);
}


{


gdjs.Level_326Code.eventsList56(runtimeScene);
}


{


gdjs.Level_326Code.eventsList57(runtimeScene);
}


};gdjs.Level_326Code.eventsList59 = function(runtimeScene) {

{


gdjs.Level_326Code.eventsList11(runtimeScene);
}


{


gdjs.Level_326Code.eventsList19(runtimeScene);
}


{


gdjs.Level_326Code.eventsList21(runtimeScene);
}


{


gdjs.Level_326Code.eventsList23(runtimeScene);
}


{


gdjs.Level_326Code.eventsList38(runtimeScene);
}


{


gdjs.Level_326Code.eventsList58(runtimeScene);
}


};gdjs.Level_326Code.eventsList60 = function(runtimeScene) {

{



}


{


gdjs.Level_326Code.eventsList59(runtimeScene);
}


{



}


};gdjs.Level_326Code.eventsList61 = function(runtimeScene) {

{


gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("No2"), gdjs.Level_326Code.GDNo2Objects1);
gdjs.copyArray(runtimeScene.getObjects("No3"), gdjs.Level_326Code.GDNo3Objects1);
gdjs.copyArray(runtimeScene.getObjects("No4"), gdjs.Level_326Code.GDNo4Objects1);
gdjs.copyArray(runtimeScene.getObjects("No5"), gdjs.Level_326Code.GDNo5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Level_326Code.GDYesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Yes2"), gdjs.Level_326Code.GDYes2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Yes32"), gdjs.Level_326Code.GDYes32Objects1);
gdjs.copyArray(runtimeScene.getObjects("Yes4"), gdjs.Level_326Code.GDYes4Objects1);
{for(var i = 0, len = gdjs.Level_326Code.GDNo2Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDNo2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_326Code.GDNo3Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDNo3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_326Code.GDYes2Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDYes2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_326Code.GDYes32Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDYes32Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_326Code.GDYes4Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDYes4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_326Code.GDYesObjects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDYesObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_326Code.GDNo5Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDNo5Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_326Code.GDNo4Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDNo4Objects1[i].hide();
}
}}

}


};gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDBullObjects2Objects = Hashtable.newFrom({"Bull": gdjs.Level_326Code.GDBullObjects2});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDOldComputerMonitorObjects2Objects = Hashtable.newFrom({"OldComputerMonitor": gdjs.Level_326Code.GDOldComputerMonitorObjects2});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDYarnObjects2Objects = Hashtable.newFrom({"Yarn": gdjs.Level_326Code.GDYarnObjects2});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDLeatherShoesObjects2Objects = Hashtable.newFrom({"LeatherShoes": gdjs.Level_326Code.GDLeatherShoesObjects2});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDFurnitureObjects1Objects = Hashtable.newFrom({"Furniture": gdjs.Level_326Code.GDFurnitureObjects1});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDtoysObjects1Objects = Hashtable.newFrom({"toys": gdjs.Level_326Code.GDtoysObjects1});
gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDMagnifyingGlassObjects1Objects = Hashtable.newFrom({"MagnifyingGlass": gdjs.Level_326Code.GDMagnifyingGlassObjects1});
gdjs.Level_326Code.asyncCallback11049020 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 11", false);
}}
gdjs.Level_326Code.eventsList62 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11049020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.asyncCallback11048564 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Level_326Code.GDYesObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "correct-6033.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_326Code.GDYesObjects2.length ;i < len;++i) {
    gdjs.Level_326Code.GDYesObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.Level_326Code.eventsList62(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_326Code.eventsList63 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_326Code.asyncCallback11048564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_326Code.eventsList64 = function(runtimeScene) {

{


gdjs.Level_326Code.eventsList60(runtimeScene);
}


{


gdjs.Level_326Code.eventsList61(runtimeScene);
}


{

gdjs.Level_326Code.GDBullObjects1.length = 0;


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.GDBullObjects1_1final.length = 0;gdjs.Level_326Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bull"), gdjs.Level_326Code.GDBullObjects2);
gdjs.Level_326Code.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDBullObjects2Objects, runtimeScene, true, false);
if( gdjs.Level_326Code.condition0IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_326Code.GDBullObjects2.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDBullObjects1_1final.indexOf(gdjs.Level_326Code.GDBullObjects2[j]) === -1 )
            gdjs.Level_326Code.GDBullObjects1_1final.push(gdjs.Level_326Code.GDBullObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_326Code.GDBullObjects1_1final, gdjs.Level_326Code.GDBullObjects1);
}
}
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
gdjs.Level_326Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("No2"), gdjs.Level_326Code.GDNo2Objects1);
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.sound.playSound(runtimeScene, "buzzer-or-wrong-answer-20582.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_326Code.GDNo2Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDNo2Objects1[i].hide(false);
}
}}

}


{

gdjs.Level_326Code.GDOldComputerMonitorObjects1.length = 0;


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.GDOldComputerMonitorObjects1_1final.length = 0;gdjs.Level_326Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("OldComputerMonitor"), gdjs.Level_326Code.GDOldComputerMonitorObjects2);
gdjs.Level_326Code.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDOldComputerMonitorObjects2Objects, runtimeScene, true, false);
if( gdjs.Level_326Code.condition0IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_326Code.GDOldComputerMonitorObjects2.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDOldComputerMonitorObjects1_1final.indexOf(gdjs.Level_326Code.GDOldComputerMonitorObjects2[j]) === -1 )
            gdjs.Level_326Code.GDOldComputerMonitorObjects1_1final.push(gdjs.Level_326Code.GDOldComputerMonitorObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_326Code.GDOldComputerMonitorObjects1_1final, gdjs.Level_326Code.GDOldComputerMonitorObjects1);
}
}
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
gdjs.Level_326Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("No3"), gdjs.Level_326Code.GDNo3Objects1);
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.sound.playSound(runtimeScene, "buzzer-or-wrong-answer-20582.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_326Code.GDNo3Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDNo3Objects1[i].hide(false);
}
}}

}


{

gdjs.Level_326Code.GDYarnObjects1.length = 0;


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.GDYarnObjects1_1final.length = 0;gdjs.Level_326Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Yarn"), gdjs.Level_326Code.GDYarnObjects2);
gdjs.Level_326Code.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDYarnObjects2Objects, runtimeScene, true, false);
if( gdjs.Level_326Code.condition0IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_326Code.GDYarnObjects2.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDYarnObjects1_1final.indexOf(gdjs.Level_326Code.GDYarnObjects2[j]) === -1 )
            gdjs.Level_326Code.GDYarnObjects1_1final.push(gdjs.Level_326Code.GDYarnObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_326Code.GDYarnObjects1_1final, gdjs.Level_326Code.GDYarnObjects1);
}
}
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
gdjs.Level_326Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("No4"), gdjs.Level_326Code.GDNo4Objects1);
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.sound.playSound(runtimeScene, "buzzer-or-wrong-answer-20582.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_326Code.GDNo4Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDNo4Objects1[i].hide(false);
}
}}

}


{

gdjs.Level_326Code.GDLeatherShoesObjects1.length = 0;


gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.GDLeatherShoesObjects1_1final.length = 0;gdjs.Level_326Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("LeatherShoes"), gdjs.Level_326Code.GDLeatherShoesObjects2);
gdjs.Level_326Code.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDLeatherShoesObjects2Objects, runtimeScene, true, false);
if( gdjs.Level_326Code.condition0IsTrue_1.val ) {
    gdjs.Level_326Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_326Code.GDLeatherShoesObjects2.length;j<jLen;++j) {
        if ( gdjs.Level_326Code.GDLeatherShoesObjects1_1final.indexOf(gdjs.Level_326Code.GDLeatherShoesObjects2[j]) === -1 )
            gdjs.Level_326Code.GDLeatherShoesObjects1_1final.push(gdjs.Level_326Code.GDLeatherShoesObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_326Code.GDLeatherShoesObjects1_1final, gdjs.Level_326Code.GDLeatherShoesObjects1);
}
}
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
gdjs.Level_326Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("No5"), gdjs.Level_326Code.GDNo5Objects1);
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.sound.playSound(runtimeScene, "buzzer-or-wrong-answer-20582.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_326Code.GDNo5Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDNo5Objects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Furniture"), gdjs.Level_326Code.GDFurnitureObjects1);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDFurnitureObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
gdjs.Level_326Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Yes2"), gdjs.Level_326Code.GDYes2Objects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "correct-6033.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_326Code.GDYes2Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDYes2Objects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("toys"), gdjs.Level_326Code.GDtoysObjects1);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDtoysObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
gdjs.Level_326Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Yes32"), gdjs.Level_326Code.GDYes32Objects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "correct-6033.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_326Code.GDYes32Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDYes32Objects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MagnifyingGlass"), gdjs.Level_326Code.GDMagnifyingGlassObjects1);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
gdjs.Level_326Code.condition1IsTrue_0.val = false;
{
gdjs.Level_326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_326Code.mapOfGDgdjs_46Level_95326Code_46GDMagnifyingGlassObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Level_326Code.condition0IsTrue_0.val ) {
{
gdjs.Level_326Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Level_326Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Yes4"), gdjs.Level_326Code.GDYes4Objects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "correct-6033.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_326Code.GDYes4Objects1.length ;i < len;++i) {
    gdjs.Level_326Code.GDYes4Objects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Yes2"), gdjs.Level_326Code.GDYes2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Yes32"), gdjs.Level_326Code.GDYes32Objects1);
gdjs.copyArray(runtimeScene.getObjects("Yes4"), gdjs.Level_326Code.GDYes4Objects1);

gdjs.Level_326Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_326Code.conditionTrue_1 = gdjs.Level_326Code.condition0IsTrue_0;
gdjs.Level_326Code.condition0IsTrue_1.val = false;
gdjs.Level_326Code.condition1IsTrue_1.val = false;
gdjs.Level_326Code.condition2IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_326Code.GDYes2Objects1.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDYes2Objects1[i].isVisible() ) {
        gdjs.Level_326Code.condition0IsTrue_1.val = true;
        gdjs.Level_326Code.GDYes2Objects1[k] = gdjs.Level_326Code.GDYes2Objects1[i];
        ++k;
    }
}
gdjs.Level_326Code.GDYes2Objects1.length = k;}if ( gdjs.Level_326Code.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_326Code.GDYes32Objects1.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDYes32Objects1[i].isVisible() ) {
        gdjs.Level_326Code.condition1IsTrue_1.val = true;
        gdjs.Level_326Code.GDYes32Objects1[k] = gdjs.Level_326Code.GDYes32Objects1[i];
        ++k;
    }
}
gdjs.Level_326Code.GDYes32Objects1.length = k;}if ( gdjs.Level_326Code.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_326Code.GDYes4Objects1.length;i<l;++i) {
    if ( gdjs.Level_326Code.GDYes4Objects1[i].isVisible() ) {
        gdjs.Level_326Code.condition2IsTrue_1.val = true;
        gdjs.Level_326Code.GDYes4Objects1[k] = gdjs.Level_326Code.GDYes4Objects1[i];
        ++k;
    }
}
gdjs.Level_326Code.GDYes4Objects1.length = k;}}
}
gdjs.Level_326Code.conditionTrue_1.val = true && gdjs.Level_326Code.condition0IsTrue_1.val && gdjs.Level_326Code.condition1IsTrue_1.val && gdjs.Level_326Code.condition2IsTrue_1.val;
}
}if (gdjs.Level_326Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_326Code.eventsList63(runtimeScene);} //End of subevents
}

}


{


{
}

}


};

gdjs.Level_326Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_326Code.GDBall_951Objects1.length = 0;
gdjs.Level_326Code.GDBall_951Objects2.length = 0;
gdjs.Level_326Code.GDBall_951Objects3.length = 0;
gdjs.Level_326Code.GDBall_951Objects4.length = 0;
gdjs.Level_326Code.GDBall_951Objects5.length = 0;
gdjs.Level_326Code.GDBall_951Objects6.length = 0;
gdjs.Level_326Code.GDBall_951Objects7.length = 0;
gdjs.Level_326Code.GDBall_954Objects1.length = 0;
gdjs.Level_326Code.GDBall_954Objects2.length = 0;
gdjs.Level_326Code.GDBall_954Objects3.length = 0;
gdjs.Level_326Code.GDBall_954Objects4.length = 0;
gdjs.Level_326Code.GDBall_954Objects5.length = 0;
gdjs.Level_326Code.GDBall_954Objects6.length = 0;
gdjs.Level_326Code.GDBall_954Objects7.length = 0;
gdjs.Level_326Code.GDBall_955Objects1.length = 0;
gdjs.Level_326Code.GDBall_955Objects2.length = 0;
gdjs.Level_326Code.GDBall_955Objects3.length = 0;
gdjs.Level_326Code.GDBall_955Objects4.length = 0;
gdjs.Level_326Code.GDBall_955Objects5.length = 0;
gdjs.Level_326Code.GDBall_955Objects6.length = 0;
gdjs.Level_326Code.GDBall_955Objects7.length = 0;
gdjs.Level_326Code.GDBall_956Objects1.length = 0;
gdjs.Level_326Code.GDBall_956Objects2.length = 0;
gdjs.Level_326Code.GDBall_956Objects3.length = 0;
gdjs.Level_326Code.GDBall_956Objects4.length = 0;
gdjs.Level_326Code.GDBall_956Objects5.length = 0;
gdjs.Level_326Code.GDBall_956Objects6.length = 0;
gdjs.Level_326Code.GDBall_956Objects7.length = 0;
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects6.length = 0;
gdjs.Level_326Code.GDGlassBreaking_95ParticlesObjects7.length = 0;
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects1.length = 0;
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects2.length = 0;
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects3.length = 0;
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects4.length = 0;
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects5.length = 0;
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects6.length = 0;
gdjs.Level_326Code.GDGdevelopGLogoWhiteObjects7.length = 0;
gdjs.Level_326Code.GDCloud1Objects1.length = 0;
gdjs.Level_326Code.GDCloud1Objects2.length = 0;
gdjs.Level_326Code.GDCloud1Objects3.length = 0;
gdjs.Level_326Code.GDCloud1Objects4.length = 0;
gdjs.Level_326Code.GDCloud1Objects5.length = 0;
gdjs.Level_326Code.GDCloud1Objects6.length = 0;
gdjs.Level_326Code.GDCloud1Objects7.length = 0;
gdjs.Level_326Code.GDCloud2Objects1.length = 0;
gdjs.Level_326Code.GDCloud2Objects2.length = 0;
gdjs.Level_326Code.GDCloud2Objects3.length = 0;
gdjs.Level_326Code.GDCloud2Objects4.length = 0;
gdjs.Level_326Code.GDCloud2Objects5.length = 0;
gdjs.Level_326Code.GDCloud2Objects6.length = 0;
gdjs.Level_326Code.GDCloud2Objects7.length = 0;
gdjs.Level_326Code.GDCloud3Objects1.length = 0;
gdjs.Level_326Code.GDCloud3Objects2.length = 0;
gdjs.Level_326Code.GDCloud3Objects3.length = 0;
gdjs.Level_326Code.GDCloud3Objects4.length = 0;
gdjs.Level_326Code.GDCloud3Objects5.length = 0;
gdjs.Level_326Code.GDCloud3Objects6.length = 0;
gdjs.Level_326Code.GDCloud3Objects7.length = 0;
gdjs.Level_326Code.GDCloud4Objects1.length = 0;
gdjs.Level_326Code.GDCloud4Objects2.length = 0;
gdjs.Level_326Code.GDCloud4Objects3.length = 0;
gdjs.Level_326Code.GDCloud4Objects4.length = 0;
gdjs.Level_326Code.GDCloud4Objects5.length = 0;
gdjs.Level_326Code.GDCloud4Objects6.length = 0;
gdjs.Level_326Code.GDCloud4Objects7.length = 0;
gdjs.Level_326Code.GDGreyButtonObjects1.length = 0;
gdjs.Level_326Code.GDGreyButtonObjects2.length = 0;
gdjs.Level_326Code.GDGreyButtonObjects3.length = 0;
gdjs.Level_326Code.GDGreyButtonObjects4.length = 0;
gdjs.Level_326Code.GDGreyButtonObjects5.length = 0;
gdjs.Level_326Code.GDGreyButtonObjects6.length = 0;
gdjs.Level_326Code.GDGreyButtonObjects7.length = 0;
gdjs.Level_326Code.GDButtonCNObjects1.length = 0;
gdjs.Level_326Code.GDButtonCNObjects2.length = 0;
gdjs.Level_326Code.GDButtonCNObjects3.length = 0;
gdjs.Level_326Code.GDButtonCNObjects4.length = 0;
gdjs.Level_326Code.GDButtonCNObjects5.length = 0;
gdjs.Level_326Code.GDButtonCNObjects6.length = 0;
gdjs.Level_326Code.GDButtonCNObjects7.length = 0;
gdjs.Level_326Code.GDMenuObjects1.length = 0;
gdjs.Level_326Code.GDMenuObjects2.length = 0;
gdjs.Level_326Code.GDMenuObjects3.length = 0;
gdjs.Level_326Code.GDMenuObjects4.length = 0;
gdjs.Level_326Code.GDMenuObjects5.length = 0;
gdjs.Level_326Code.GDMenuObjects6.length = 0;
gdjs.Level_326Code.GDMenuObjects7.length = 0;
gdjs.Level_326Code.GDGameState_95TextObjects1.length = 0;
gdjs.Level_326Code.GDGameState_95TextObjects2.length = 0;
gdjs.Level_326Code.GDGameState_95TextObjects3.length = 0;
gdjs.Level_326Code.GDGameState_95TextObjects4.length = 0;
gdjs.Level_326Code.GDGameState_95TextObjects5.length = 0;
gdjs.Level_326Code.GDGameState_95TextObjects6.length = 0;
gdjs.Level_326Code.GDGameState_95TextObjects7.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects6.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects7.length = 0;
gdjs.Level_326Code.GDClick_95textObjects1.length = 0;
gdjs.Level_326Code.GDClick_95textObjects2.length = 0;
gdjs.Level_326Code.GDClick_95textObjects3.length = 0;
gdjs.Level_326Code.GDClick_95textObjects4.length = 0;
gdjs.Level_326Code.GDClick_95textObjects5.length = 0;
gdjs.Level_326Code.GDClick_95textObjects6.length = 0;
gdjs.Level_326Code.GDClick_95textObjects7.length = 0;
gdjs.Level_326Code.GDYarnObjects1.length = 0;
gdjs.Level_326Code.GDYarnObjects2.length = 0;
gdjs.Level_326Code.GDYarnObjects3.length = 0;
gdjs.Level_326Code.GDYarnObjects4.length = 0;
gdjs.Level_326Code.GDYarnObjects5.length = 0;
gdjs.Level_326Code.GDYarnObjects6.length = 0;
gdjs.Level_326Code.GDYarnObjects7.length = 0;
gdjs.Level_326Code.GDBullObjects1.length = 0;
gdjs.Level_326Code.GDBullObjects2.length = 0;
gdjs.Level_326Code.GDBullObjects3.length = 0;
gdjs.Level_326Code.GDBullObjects4.length = 0;
gdjs.Level_326Code.GDBullObjects5.length = 0;
gdjs.Level_326Code.GDBullObjects6.length = 0;
gdjs.Level_326Code.GDBullObjects7.length = 0;
gdjs.Level_326Code.GDClick_95text2Objects1.length = 0;
gdjs.Level_326Code.GDClick_95text2Objects2.length = 0;
gdjs.Level_326Code.GDClick_95text2Objects3.length = 0;
gdjs.Level_326Code.GDClick_95text2Objects4.length = 0;
gdjs.Level_326Code.GDClick_95text2Objects5.length = 0;
gdjs.Level_326Code.GDClick_95text2Objects6.length = 0;
gdjs.Level_326Code.GDClick_95text2Objects7.length = 0;
gdjs.Level_326Code.GDPlay_95TextObjects1.length = 0;
gdjs.Level_326Code.GDPlay_95TextObjects2.length = 0;
gdjs.Level_326Code.GDPlay_95TextObjects3.length = 0;
gdjs.Level_326Code.GDPlay_95TextObjects4.length = 0;
gdjs.Level_326Code.GDPlay_95TextObjects5.length = 0;
gdjs.Level_326Code.GDPlay_95TextObjects6.length = 0;
gdjs.Level_326Code.GDPlay_95TextObjects7.length = 0;
gdjs.Level_326Code.GDLeaderboardObjects1.length = 0;
gdjs.Level_326Code.GDLeaderboardObjects2.length = 0;
gdjs.Level_326Code.GDLeaderboardObjects3.length = 0;
gdjs.Level_326Code.GDLeaderboardObjects4.length = 0;
gdjs.Level_326Code.GDLeaderboardObjects5.length = 0;
gdjs.Level_326Code.GDLeaderboardObjects6.length = 0;
gdjs.Level_326Code.GDLeaderboardObjects7.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects1.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects2.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects3.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects4.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects5.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects6.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects7.length = 0;
gdjs.Level_326Code.GDFurnitureObjects1.length = 0;
gdjs.Level_326Code.GDFurnitureObjects2.length = 0;
gdjs.Level_326Code.GDFurnitureObjects3.length = 0;
gdjs.Level_326Code.GDFurnitureObjects4.length = 0;
gdjs.Level_326Code.GDFurnitureObjects5.length = 0;
gdjs.Level_326Code.GDFurnitureObjects6.length = 0;
gdjs.Level_326Code.GDFurnitureObjects7.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects1.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects2.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects3.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects4.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects5.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects6.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects7.length = 0;
gdjs.Level_326Code.GDtoysObjects1.length = 0;
gdjs.Level_326Code.GDtoysObjects2.length = 0;
gdjs.Level_326Code.GDtoysObjects3.length = 0;
gdjs.Level_326Code.GDtoysObjects4.length = 0;
gdjs.Level_326Code.GDtoysObjects5.length = 0;
gdjs.Level_326Code.GDtoysObjects6.length = 0;
gdjs.Level_326Code.GDtoysObjects7.length = 0;
gdjs.Level_326Code.GDMainMenu_95TextObjects1.length = 0;
gdjs.Level_326Code.GDMainMenu_95TextObjects2.length = 0;
gdjs.Level_326Code.GDMainMenu_95TextObjects3.length = 0;
gdjs.Level_326Code.GDMainMenu_95TextObjects4.length = 0;
gdjs.Level_326Code.GDMainMenu_95TextObjects5.length = 0;
gdjs.Level_326Code.GDMainMenu_95TextObjects6.length = 0;
gdjs.Level_326Code.GDMainMenu_95TextObjects7.length = 0;
gdjs.Level_326Code.GDResetProgress_95TextObjects1.length = 0;
gdjs.Level_326Code.GDResetProgress_95TextObjects2.length = 0;
gdjs.Level_326Code.GDResetProgress_95TextObjects3.length = 0;
gdjs.Level_326Code.GDResetProgress_95TextObjects4.length = 0;
gdjs.Level_326Code.GDResetProgress_95TextObjects5.length = 0;
gdjs.Level_326Code.GDResetProgress_95TextObjects6.length = 0;
gdjs.Level_326Code.GDResetProgress_95TextObjects7.length = 0;
gdjs.Level_326Code.GDStartOver_95TextObjects1.length = 0;
gdjs.Level_326Code.GDStartOver_95TextObjects2.length = 0;
gdjs.Level_326Code.GDStartOver_95TextObjects3.length = 0;
gdjs.Level_326Code.GDStartOver_95TextObjects4.length = 0;
gdjs.Level_326Code.GDStartOver_95TextObjects5.length = 0;
gdjs.Level_326Code.GDStartOver_95TextObjects6.length = 0;
gdjs.Level_326Code.GDStartOver_95TextObjects7.length = 0;
gdjs.Level_326Code.GDSubmit_95TextObjects1.length = 0;
gdjs.Level_326Code.GDSubmit_95TextObjects2.length = 0;
gdjs.Level_326Code.GDSubmit_95TextObjects3.length = 0;
gdjs.Level_326Code.GDSubmit_95TextObjects4.length = 0;
gdjs.Level_326Code.GDSubmit_95TextObjects5.length = 0;
gdjs.Level_326Code.GDSubmit_95TextObjects6.length = 0;
gdjs.Level_326Code.GDSubmit_95TextObjects7.length = 0;
gdjs.Level_326Code.GDChina_95textObjects1.length = 0;
gdjs.Level_326Code.GDChina_95textObjects2.length = 0;
gdjs.Level_326Code.GDChina_95textObjects3.length = 0;
gdjs.Level_326Code.GDChina_95textObjects4.length = 0;
gdjs.Level_326Code.GDChina_95textObjects5.length = 0;
gdjs.Level_326Code.GDChina_95textObjects6.length = 0;
gdjs.Level_326Code.GDChina_95textObjects7.length = 0;
gdjs.Level_326Code.GDSection_95text1Objects1.length = 0;
gdjs.Level_326Code.GDSection_95text1Objects2.length = 0;
gdjs.Level_326Code.GDSection_95text1Objects3.length = 0;
gdjs.Level_326Code.GDSection_95text1Objects4.length = 0;
gdjs.Level_326Code.GDSection_95text1Objects5.length = 0;
gdjs.Level_326Code.GDSection_95text1Objects6.length = 0;
gdjs.Level_326Code.GDSection_95text1Objects7.length = 0;
gdjs.Level_326Code.GDSource_95textObjects1.length = 0;
gdjs.Level_326Code.GDSource_95textObjects2.length = 0;
gdjs.Level_326Code.GDSource_95textObjects3.length = 0;
gdjs.Level_326Code.GDSource_95textObjects4.length = 0;
gdjs.Level_326Code.GDSource_95textObjects5.length = 0;
gdjs.Level_326Code.GDSource_95textObjects6.length = 0;
gdjs.Level_326Code.GDSource_95textObjects7.length = 0;
gdjs.Level_326Code.GDYear_95textObjects1.length = 0;
gdjs.Level_326Code.GDYear_95textObjects2.length = 0;
gdjs.Level_326Code.GDYear_95textObjects3.length = 0;
gdjs.Level_326Code.GDYear_95textObjects4.length = 0;
gdjs.Level_326Code.GDYear_95textObjects5.length = 0;
gdjs.Level_326Code.GDYear_95textObjects6.length = 0;
gdjs.Level_326Code.GDYear_95textObjects7.length = 0;
gdjs.Level_326Code.GDYesObjects1.length = 0;
gdjs.Level_326Code.GDYesObjects2.length = 0;
gdjs.Level_326Code.GDYesObjects3.length = 0;
gdjs.Level_326Code.GDYesObjects4.length = 0;
gdjs.Level_326Code.GDYesObjects5.length = 0;
gdjs.Level_326Code.GDYesObjects6.length = 0;
gdjs.Level_326Code.GDYesObjects7.length = 0;
gdjs.Level_326Code.GDYes2Objects1.length = 0;
gdjs.Level_326Code.GDYes2Objects2.length = 0;
gdjs.Level_326Code.GDYes2Objects3.length = 0;
gdjs.Level_326Code.GDYes2Objects4.length = 0;
gdjs.Level_326Code.GDYes2Objects5.length = 0;
gdjs.Level_326Code.GDYes2Objects6.length = 0;
gdjs.Level_326Code.GDYes2Objects7.length = 0;
gdjs.Level_326Code.GDYes3Objects1.length = 0;
gdjs.Level_326Code.GDYes3Objects2.length = 0;
gdjs.Level_326Code.GDYes3Objects3.length = 0;
gdjs.Level_326Code.GDYes3Objects4.length = 0;
gdjs.Level_326Code.GDYes3Objects5.length = 0;
gdjs.Level_326Code.GDYes3Objects6.length = 0;
gdjs.Level_326Code.GDYes3Objects7.length = 0;
gdjs.Level_326Code.GDYes32Objects1.length = 0;
gdjs.Level_326Code.GDYes32Objects2.length = 0;
gdjs.Level_326Code.GDYes32Objects3.length = 0;
gdjs.Level_326Code.GDYes32Objects4.length = 0;
gdjs.Level_326Code.GDYes32Objects5.length = 0;
gdjs.Level_326Code.GDYes32Objects6.length = 0;
gdjs.Level_326Code.GDYes32Objects7.length = 0;
gdjs.Level_326Code.GDYes4Objects1.length = 0;
gdjs.Level_326Code.GDYes4Objects2.length = 0;
gdjs.Level_326Code.GDYes4Objects3.length = 0;
gdjs.Level_326Code.GDYes4Objects4.length = 0;
gdjs.Level_326Code.GDYes4Objects5.length = 0;
gdjs.Level_326Code.GDYes4Objects6.length = 0;
gdjs.Level_326Code.GDYes4Objects7.length = 0;
gdjs.Level_326Code.GDYes5Objects1.length = 0;
gdjs.Level_326Code.GDYes5Objects2.length = 0;
gdjs.Level_326Code.GDYes5Objects3.length = 0;
gdjs.Level_326Code.GDYes5Objects4.length = 0;
gdjs.Level_326Code.GDYes5Objects5.length = 0;
gdjs.Level_326Code.GDYes5Objects6.length = 0;
gdjs.Level_326Code.GDYes5Objects7.length = 0;
gdjs.Level_326Code.GDYes6Objects1.length = 0;
gdjs.Level_326Code.GDYes6Objects2.length = 0;
gdjs.Level_326Code.GDYes6Objects3.length = 0;
gdjs.Level_326Code.GDYes6Objects4.length = 0;
gdjs.Level_326Code.GDYes6Objects5.length = 0;
gdjs.Level_326Code.GDYes6Objects6.length = 0;
gdjs.Level_326Code.GDYes6Objects7.length = 0;
gdjs.Level_326Code.GDYes7Objects1.length = 0;
gdjs.Level_326Code.GDYes7Objects2.length = 0;
gdjs.Level_326Code.GDYes7Objects3.length = 0;
gdjs.Level_326Code.GDYes7Objects4.length = 0;
gdjs.Level_326Code.GDYes7Objects5.length = 0;
gdjs.Level_326Code.GDYes7Objects6.length = 0;
gdjs.Level_326Code.GDYes7Objects7.length = 0;
gdjs.Level_326Code.GDYes8Objects1.length = 0;
gdjs.Level_326Code.GDYes8Objects2.length = 0;
gdjs.Level_326Code.GDYes8Objects3.length = 0;
gdjs.Level_326Code.GDYes8Objects4.length = 0;
gdjs.Level_326Code.GDYes8Objects5.length = 0;
gdjs.Level_326Code.GDYes8Objects6.length = 0;
gdjs.Level_326Code.GDYes8Objects7.length = 0;
gdjs.Level_326Code.GDChinaObjects1.length = 0;
gdjs.Level_326Code.GDChinaObjects2.length = 0;
gdjs.Level_326Code.GDChinaObjects3.length = 0;
gdjs.Level_326Code.GDChinaObjects4.length = 0;
gdjs.Level_326Code.GDChinaObjects5.length = 0;
gdjs.Level_326Code.GDChinaObjects6.length = 0;
gdjs.Level_326Code.GDChinaObjects7.length = 0;
gdjs.Level_326Code.GDNoObjects1.length = 0;
gdjs.Level_326Code.GDNoObjects2.length = 0;
gdjs.Level_326Code.GDNoObjects3.length = 0;
gdjs.Level_326Code.GDNoObjects4.length = 0;
gdjs.Level_326Code.GDNoObjects5.length = 0;
gdjs.Level_326Code.GDNoObjects6.length = 0;
gdjs.Level_326Code.GDNoObjects7.length = 0;
gdjs.Level_326Code.GDNo2Objects1.length = 0;
gdjs.Level_326Code.GDNo2Objects2.length = 0;
gdjs.Level_326Code.GDNo2Objects3.length = 0;
gdjs.Level_326Code.GDNo2Objects4.length = 0;
gdjs.Level_326Code.GDNo2Objects5.length = 0;
gdjs.Level_326Code.GDNo2Objects6.length = 0;
gdjs.Level_326Code.GDNo2Objects7.length = 0;
gdjs.Level_326Code.GDNo3Objects1.length = 0;
gdjs.Level_326Code.GDNo3Objects2.length = 0;
gdjs.Level_326Code.GDNo3Objects3.length = 0;
gdjs.Level_326Code.GDNo3Objects4.length = 0;
gdjs.Level_326Code.GDNo3Objects5.length = 0;
gdjs.Level_326Code.GDNo3Objects6.length = 0;
gdjs.Level_326Code.GDNo3Objects7.length = 0;
gdjs.Level_326Code.GDNo4Objects1.length = 0;
gdjs.Level_326Code.GDNo4Objects2.length = 0;
gdjs.Level_326Code.GDNo4Objects3.length = 0;
gdjs.Level_326Code.GDNo4Objects4.length = 0;
gdjs.Level_326Code.GDNo4Objects5.length = 0;
gdjs.Level_326Code.GDNo4Objects6.length = 0;
gdjs.Level_326Code.GDNo4Objects7.length = 0;
gdjs.Level_326Code.GDNo5Objects1.length = 0;
gdjs.Level_326Code.GDNo5Objects2.length = 0;
gdjs.Level_326Code.GDNo5Objects3.length = 0;
gdjs.Level_326Code.GDNo5Objects4.length = 0;
gdjs.Level_326Code.GDNo5Objects5.length = 0;
gdjs.Level_326Code.GDNo5Objects6.length = 0;
gdjs.Level_326Code.GDNo5Objects7.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects6.length = 0;
gdjs.Level_326Code.GDBallsInCup_95TextObjects7.length = 0;
gdjs.Level_326Code.GDQ_955Objects1.length = 0;
gdjs.Level_326Code.GDQ_955Objects2.length = 0;
gdjs.Level_326Code.GDQ_955Objects3.length = 0;
gdjs.Level_326Code.GDQ_955Objects4.length = 0;
gdjs.Level_326Code.GDQ_955Objects5.length = 0;
gdjs.Level_326Code.GDQ_955Objects6.length = 0;
gdjs.Level_326Code.GDQ_955Objects7.length = 0;
gdjs.Level_326Code.GDPickupTruckLargeObjects1.length = 0;
gdjs.Level_326Code.GDPickupTruckLargeObjects2.length = 0;
gdjs.Level_326Code.GDPickupTruckLargeObjects3.length = 0;
gdjs.Level_326Code.GDPickupTruckLargeObjects4.length = 0;
gdjs.Level_326Code.GDPickupTruckLargeObjects5.length = 0;
gdjs.Level_326Code.GDPickupTruckLargeObjects6.length = 0;
gdjs.Level_326Code.GDPickupTruckLargeObjects7.length = 0;
gdjs.Level_326Code.GDFurnitureObjects1.length = 0;
gdjs.Level_326Code.GDFurnitureObjects2.length = 0;
gdjs.Level_326Code.GDFurnitureObjects3.length = 0;
gdjs.Level_326Code.GDFurnitureObjects4.length = 0;
gdjs.Level_326Code.GDFurnitureObjects5.length = 0;
gdjs.Level_326Code.GDFurnitureObjects6.length = 0;
gdjs.Level_326Code.GDFurnitureObjects7.length = 0;
gdjs.Level_326Code.GDSandwichDishObjects1.length = 0;
gdjs.Level_326Code.GDSandwichDishObjects2.length = 0;
gdjs.Level_326Code.GDSandwichDishObjects3.length = 0;
gdjs.Level_326Code.GDSandwichDishObjects4.length = 0;
gdjs.Level_326Code.GDSandwichDishObjects5.length = 0;
gdjs.Level_326Code.GDSandwichDishObjects6.length = 0;
gdjs.Level_326Code.GDSandwichDishObjects7.length = 0;
gdjs.Level_326Code.GDOldComputerMonitorObjects1.length = 0;
gdjs.Level_326Code.GDOldComputerMonitorObjects2.length = 0;
gdjs.Level_326Code.GDOldComputerMonitorObjects3.length = 0;
gdjs.Level_326Code.GDOldComputerMonitorObjects4.length = 0;
gdjs.Level_326Code.GDOldComputerMonitorObjects5.length = 0;
gdjs.Level_326Code.GDOldComputerMonitorObjects6.length = 0;
gdjs.Level_326Code.GDOldComputerMonitorObjects7.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects1.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects2.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects3.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects4.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects5.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects6.length = 0;
gdjs.Level_326Code.GDLeatherShoesObjects7.length = 0;
gdjs.Level_326Code.GDMachinesObjects1.length = 0;
gdjs.Level_326Code.GDMachinesObjects2.length = 0;
gdjs.Level_326Code.GDMachinesObjects3.length = 0;
gdjs.Level_326Code.GDMachinesObjects4.length = 0;
gdjs.Level_326Code.GDMachinesObjects5.length = 0;
gdjs.Level_326Code.GDMachinesObjects6.length = 0;
gdjs.Level_326Code.GDMachinesObjects7.length = 0;
gdjs.Level_326Code.GDTransportationsObjects1.length = 0;
gdjs.Level_326Code.GDTransportationsObjects2.length = 0;
gdjs.Level_326Code.GDTransportationsObjects3.length = 0;
gdjs.Level_326Code.GDTransportationsObjects4.length = 0;
gdjs.Level_326Code.GDTransportationsObjects5.length = 0;
gdjs.Level_326Code.GDTransportationsObjects6.length = 0;
gdjs.Level_326Code.GDTransportationsObjects7.length = 0;
gdjs.Level_326Code.GDFurniture_95textObjects1.length = 0;
gdjs.Level_326Code.GDFurniture_95textObjects2.length = 0;
gdjs.Level_326Code.GDFurniture_95textObjects3.length = 0;
gdjs.Level_326Code.GDFurniture_95textObjects4.length = 0;
gdjs.Level_326Code.GDFurniture_95textObjects5.length = 0;
gdjs.Level_326Code.GDFurniture_95textObjects6.length = 0;
gdjs.Level_326Code.GDFurniture_95textObjects7.length = 0;
gdjs.Level_326Code.GDPaperObjects1.length = 0;
gdjs.Level_326Code.GDPaperObjects2.length = 0;
gdjs.Level_326Code.GDPaperObjects3.length = 0;
gdjs.Level_326Code.GDPaperObjects4.length = 0;
gdjs.Level_326Code.GDPaperObjects5.length = 0;
gdjs.Level_326Code.GDPaperObjects6.length = 0;
gdjs.Level_326Code.GDPaperObjects7.length = 0;
gdjs.Level_326Code.GDAnimalObjects1.length = 0;
gdjs.Level_326Code.GDAnimalObjects2.length = 0;
gdjs.Level_326Code.GDAnimalObjects3.length = 0;
gdjs.Level_326Code.GDAnimalObjects4.length = 0;
gdjs.Level_326Code.GDAnimalObjects5.length = 0;
gdjs.Level_326Code.GDAnimalObjects6.length = 0;
gdjs.Level_326Code.GDAnimalObjects7.length = 0;
gdjs.Level_326Code.GDGlassObjects1.length = 0;
gdjs.Level_326Code.GDGlassObjects2.length = 0;
gdjs.Level_326Code.GDGlassObjects3.length = 0;
gdjs.Level_326Code.GDGlassObjects4.length = 0;
gdjs.Level_326Code.GDGlassObjects5.length = 0;
gdjs.Level_326Code.GDGlassObjects6.length = 0;
gdjs.Level_326Code.GDGlassObjects7.length = 0;
gdjs.Level_326Code.GDToyObjects1.length = 0;
gdjs.Level_326Code.GDToyObjects2.length = 0;
gdjs.Level_326Code.GDToyObjects3.length = 0;
gdjs.Level_326Code.GDToyObjects4.length = 0;
gdjs.Level_326Code.GDToyObjects5.length = 0;
gdjs.Level_326Code.GDToyObjects6.length = 0;
gdjs.Level_326Code.GDToyObjects7.length = 0;
gdjs.Level_326Code.GDTextileObjects1.length = 0;
gdjs.Level_326Code.GDTextileObjects2.length = 0;
gdjs.Level_326Code.GDTextileObjects3.length = 0;
gdjs.Level_326Code.GDTextileObjects4.length = 0;
gdjs.Level_326Code.GDTextileObjects5.length = 0;
gdjs.Level_326Code.GDTextileObjects6.length = 0;
gdjs.Level_326Code.GDTextileObjects7.length = 0;
gdjs.Level_326Code.GDFootwearObjects1.length = 0;
gdjs.Level_326Code.GDFootwearObjects2.length = 0;
gdjs.Level_326Code.GDFootwearObjects3.length = 0;
gdjs.Level_326Code.GDFootwearObjects4.length = 0;
gdjs.Level_326Code.GDFootwearObjects5.length = 0;
gdjs.Level_326Code.GDFootwearObjects6.length = 0;
gdjs.Level_326Code.GDFootwearObjects7.length = 0;
gdjs.Level_326Code.GDYarnObjects1.length = 0;
gdjs.Level_326Code.GDYarnObjects2.length = 0;
gdjs.Level_326Code.GDYarnObjects3.length = 0;
gdjs.Level_326Code.GDYarnObjects4.length = 0;
gdjs.Level_326Code.GDYarnObjects5.length = 0;
gdjs.Level_326Code.GDYarnObjects6.length = 0;
gdjs.Level_326Code.GDYarnObjects7.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects1.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects2.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects3.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects4.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects5.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects6.length = 0;
gdjs.Level_326Code.GDMagnifyingGlassObjects7.length = 0;
gdjs.Level_326Code.GDtoysObjects1.length = 0;
gdjs.Level_326Code.GDtoysObjects2.length = 0;
gdjs.Level_326Code.GDtoysObjects3.length = 0;
gdjs.Level_326Code.GDtoysObjects4.length = 0;
gdjs.Level_326Code.GDtoysObjects5.length = 0;
gdjs.Level_326Code.GDtoysObjects6.length = 0;
gdjs.Level_326Code.GDtoysObjects7.length = 0;
gdjs.Level_326Code.GDBullObjects1.length = 0;
gdjs.Level_326Code.GDBullObjects2.length = 0;
gdjs.Level_326Code.GDBullObjects3.length = 0;
gdjs.Level_326Code.GDBullObjects4.length = 0;
gdjs.Level_326Code.GDBullObjects5.length = 0;
gdjs.Level_326Code.GDBullObjects6.length = 0;
gdjs.Level_326Code.GDBullObjects7.length = 0;
gdjs.Level_326Code.GDPaperBagObjects1.length = 0;
gdjs.Level_326Code.GDPaperBagObjects2.length = 0;
gdjs.Level_326Code.GDPaperBagObjects3.length = 0;
gdjs.Level_326Code.GDPaperBagObjects4.length = 0;
gdjs.Level_326Code.GDPaperBagObjects5.length = 0;
gdjs.Level_326Code.GDPaperBagObjects6.length = 0;
gdjs.Level_326Code.GDPaperBagObjects7.length = 0;
gdjs.Level_326Code.GDQ_956Objects1.length = 0;
gdjs.Level_326Code.GDQ_956Objects2.length = 0;
gdjs.Level_326Code.GDQ_956Objects3.length = 0;
gdjs.Level_326Code.GDQ_956Objects4.length = 0;
gdjs.Level_326Code.GDQ_956Objects5.length = 0;
gdjs.Level_326Code.GDQ_956Objects6.length = 0;
gdjs.Level_326Code.GDQ_956Objects7.length = 0;

gdjs.Level_326Code.eventsList64(runtimeScene);
return;

}

gdjs['Level_326Code'] = gdjs.Level_326Code;
