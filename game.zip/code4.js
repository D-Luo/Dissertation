gdjs.Level_324Code = {};
gdjs.Level_324Code.GDBall_951Objects3_1final = [];

gdjs.Level_324Code.GDBall_954Objects3_1final = [];

gdjs.Level_324Code.GDBall_955Objects3_1final = [];

gdjs.Level_324Code.GDBall_956Objects3_1final = [];

gdjs.Level_324Code.GDChinaObjects1_1final = [];

gdjs.Level_324Code.GDMenuObjects3_1final = [];

gdjs.Level_324Code.GDp_9527_956Objects1_1final = [];

gdjs.Level_324Code.GDp_954_958Objects1_1final = [];

gdjs.Level_324Code.GDp_958_955Objects1_1final = [];

gdjs.Level_324Code.GDBall_951Objects1= [];
gdjs.Level_324Code.GDBall_951Objects2= [];
gdjs.Level_324Code.GDBall_951Objects3= [];
gdjs.Level_324Code.GDBall_951Objects4= [];
gdjs.Level_324Code.GDBall_951Objects5= [];
gdjs.Level_324Code.GDBall_951Objects6= [];
gdjs.Level_324Code.GDBall_951Objects7= [];
gdjs.Level_324Code.GDBall_954Objects1= [];
gdjs.Level_324Code.GDBall_954Objects2= [];
gdjs.Level_324Code.GDBall_954Objects3= [];
gdjs.Level_324Code.GDBall_954Objects4= [];
gdjs.Level_324Code.GDBall_954Objects5= [];
gdjs.Level_324Code.GDBall_954Objects6= [];
gdjs.Level_324Code.GDBall_954Objects7= [];
gdjs.Level_324Code.GDBall_955Objects1= [];
gdjs.Level_324Code.GDBall_955Objects2= [];
gdjs.Level_324Code.GDBall_955Objects3= [];
gdjs.Level_324Code.GDBall_955Objects4= [];
gdjs.Level_324Code.GDBall_955Objects5= [];
gdjs.Level_324Code.GDBall_955Objects6= [];
gdjs.Level_324Code.GDBall_955Objects7= [];
gdjs.Level_324Code.GDBall_956Objects1= [];
gdjs.Level_324Code.GDBall_956Objects2= [];
gdjs.Level_324Code.GDBall_956Objects3= [];
gdjs.Level_324Code.GDBall_956Objects4= [];
gdjs.Level_324Code.GDBall_956Objects5= [];
gdjs.Level_324Code.GDBall_956Objects6= [];
gdjs.Level_324Code.GDBall_956Objects7= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects6= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7= [];
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects1= [];
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects2= [];
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3= [];
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4= [];
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects5= [];
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects6= [];
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects7= [];
gdjs.Level_324Code.GDCloud1Objects1= [];
gdjs.Level_324Code.GDCloud1Objects2= [];
gdjs.Level_324Code.GDCloud1Objects3= [];
gdjs.Level_324Code.GDCloud1Objects4= [];
gdjs.Level_324Code.GDCloud1Objects5= [];
gdjs.Level_324Code.GDCloud1Objects6= [];
gdjs.Level_324Code.GDCloud1Objects7= [];
gdjs.Level_324Code.GDCloud2Objects1= [];
gdjs.Level_324Code.GDCloud2Objects2= [];
gdjs.Level_324Code.GDCloud2Objects3= [];
gdjs.Level_324Code.GDCloud2Objects4= [];
gdjs.Level_324Code.GDCloud2Objects5= [];
gdjs.Level_324Code.GDCloud2Objects6= [];
gdjs.Level_324Code.GDCloud2Objects7= [];
gdjs.Level_324Code.GDCloud3Objects1= [];
gdjs.Level_324Code.GDCloud3Objects2= [];
gdjs.Level_324Code.GDCloud3Objects3= [];
gdjs.Level_324Code.GDCloud3Objects4= [];
gdjs.Level_324Code.GDCloud3Objects5= [];
gdjs.Level_324Code.GDCloud3Objects6= [];
gdjs.Level_324Code.GDCloud3Objects7= [];
gdjs.Level_324Code.GDCloud4Objects1= [];
gdjs.Level_324Code.GDCloud4Objects2= [];
gdjs.Level_324Code.GDCloud4Objects3= [];
gdjs.Level_324Code.GDCloud4Objects4= [];
gdjs.Level_324Code.GDCloud4Objects5= [];
gdjs.Level_324Code.GDCloud4Objects6= [];
gdjs.Level_324Code.GDCloud4Objects7= [];
gdjs.Level_324Code.GDGreyButtonObjects1= [];
gdjs.Level_324Code.GDGreyButtonObjects2= [];
gdjs.Level_324Code.GDGreyButtonObjects3= [];
gdjs.Level_324Code.GDGreyButtonObjects4= [];
gdjs.Level_324Code.GDGreyButtonObjects5= [];
gdjs.Level_324Code.GDGreyButtonObjects6= [];
gdjs.Level_324Code.GDGreyButtonObjects7= [];
gdjs.Level_324Code.GDButtonCNObjects1= [];
gdjs.Level_324Code.GDButtonCNObjects2= [];
gdjs.Level_324Code.GDButtonCNObjects3= [];
gdjs.Level_324Code.GDButtonCNObjects4= [];
gdjs.Level_324Code.GDButtonCNObjects5= [];
gdjs.Level_324Code.GDButtonCNObjects6= [];
gdjs.Level_324Code.GDButtonCNObjects7= [];
gdjs.Level_324Code.GDMenuObjects1= [];
gdjs.Level_324Code.GDMenuObjects2= [];
gdjs.Level_324Code.GDMenuObjects3= [];
gdjs.Level_324Code.GDMenuObjects4= [];
gdjs.Level_324Code.GDMenuObjects5= [];
gdjs.Level_324Code.GDMenuObjects6= [];
gdjs.Level_324Code.GDMenuObjects7= [];
gdjs.Level_324Code.GDGameState_95TextObjects1= [];
gdjs.Level_324Code.GDGameState_95TextObjects2= [];
gdjs.Level_324Code.GDGameState_95TextObjects3= [];
gdjs.Level_324Code.GDGameState_95TextObjects4= [];
gdjs.Level_324Code.GDGameState_95TextObjects5= [];
gdjs.Level_324Code.GDGameState_95TextObjects6= [];
gdjs.Level_324Code.GDGameState_95TextObjects7= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects1= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects2= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects3= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects4= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects5= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects6= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects7= [];
gdjs.Level_324Code.GDClick_95textObjects1= [];
gdjs.Level_324Code.GDClick_95textObjects2= [];
gdjs.Level_324Code.GDClick_95textObjects3= [];
gdjs.Level_324Code.GDClick_95textObjects4= [];
gdjs.Level_324Code.GDClick_95textObjects5= [];
gdjs.Level_324Code.GDClick_95textObjects6= [];
gdjs.Level_324Code.GDClick_95textObjects7= [];
gdjs.Level_324Code.GDYarnObjects1= [];
gdjs.Level_324Code.GDYarnObjects2= [];
gdjs.Level_324Code.GDYarnObjects3= [];
gdjs.Level_324Code.GDYarnObjects4= [];
gdjs.Level_324Code.GDYarnObjects5= [];
gdjs.Level_324Code.GDYarnObjects6= [];
gdjs.Level_324Code.GDYarnObjects7= [];
gdjs.Level_324Code.GDBullObjects1= [];
gdjs.Level_324Code.GDBullObjects2= [];
gdjs.Level_324Code.GDBullObjects3= [];
gdjs.Level_324Code.GDBullObjects4= [];
gdjs.Level_324Code.GDBullObjects5= [];
gdjs.Level_324Code.GDBullObjects6= [];
gdjs.Level_324Code.GDBullObjects7= [];
gdjs.Level_324Code.GDClick_95text2Objects1= [];
gdjs.Level_324Code.GDClick_95text2Objects2= [];
gdjs.Level_324Code.GDClick_95text2Objects3= [];
gdjs.Level_324Code.GDClick_95text2Objects4= [];
gdjs.Level_324Code.GDClick_95text2Objects5= [];
gdjs.Level_324Code.GDClick_95text2Objects6= [];
gdjs.Level_324Code.GDClick_95text2Objects7= [];
gdjs.Level_324Code.GDPlay_95TextObjects1= [];
gdjs.Level_324Code.GDPlay_95TextObjects2= [];
gdjs.Level_324Code.GDPlay_95TextObjects3= [];
gdjs.Level_324Code.GDPlay_95TextObjects4= [];
gdjs.Level_324Code.GDPlay_95TextObjects5= [];
gdjs.Level_324Code.GDPlay_95TextObjects6= [];
gdjs.Level_324Code.GDPlay_95TextObjects7= [];
gdjs.Level_324Code.GDLeaderboardObjects1= [];
gdjs.Level_324Code.GDLeaderboardObjects2= [];
gdjs.Level_324Code.GDLeaderboardObjects3= [];
gdjs.Level_324Code.GDLeaderboardObjects4= [];
gdjs.Level_324Code.GDLeaderboardObjects5= [];
gdjs.Level_324Code.GDLeaderboardObjects6= [];
gdjs.Level_324Code.GDLeaderboardObjects7= [];
gdjs.Level_324Code.GDLeatherShoesObjects1= [];
gdjs.Level_324Code.GDLeatherShoesObjects2= [];
gdjs.Level_324Code.GDLeatherShoesObjects3= [];
gdjs.Level_324Code.GDLeatherShoesObjects4= [];
gdjs.Level_324Code.GDLeatherShoesObjects5= [];
gdjs.Level_324Code.GDLeatherShoesObjects6= [];
gdjs.Level_324Code.GDLeatherShoesObjects7= [];
gdjs.Level_324Code.GDFurnitureObjects1= [];
gdjs.Level_324Code.GDFurnitureObjects2= [];
gdjs.Level_324Code.GDFurnitureObjects3= [];
gdjs.Level_324Code.GDFurnitureObjects4= [];
gdjs.Level_324Code.GDFurnitureObjects5= [];
gdjs.Level_324Code.GDFurnitureObjects6= [];
gdjs.Level_324Code.GDFurnitureObjects7= [];
gdjs.Level_324Code.GDMagnifyingGlassObjects1= [];
gdjs.Level_324Code.GDMagnifyingGlassObjects2= [];
gdjs.Level_324Code.GDMagnifyingGlassObjects3= [];
gdjs.Level_324Code.GDMagnifyingGlassObjects4= [];
gdjs.Level_324Code.GDMagnifyingGlassObjects5= [];
gdjs.Level_324Code.GDMagnifyingGlassObjects6= [];
gdjs.Level_324Code.GDMagnifyingGlassObjects7= [];
gdjs.Level_324Code.GDtoysObjects1= [];
gdjs.Level_324Code.GDtoysObjects2= [];
gdjs.Level_324Code.GDtoysObjects3= [];
gdjs.Level_324Code.GDtoysObjects4= [];
gdjs.Level_324Code.GDtoysObjects5= [];
gdjs.Level_324Code.GDtoysObjects6= [];
gdjs.Level_324Code.GDtoysObjects7= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects1= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects2= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects3= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects4= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects5= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects6= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects7= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects1= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects2= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects3= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects4= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects5= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects6= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects7= [];
gdjs.Level_324Code.GDStartOver_95TextObjects1= [];
gdjs.Level_324Code.GDStartOver_95TextObjects2= [];
gdjs.Level_324Code.GDStartOver_95TextObjects3= [];
gdjs.Level_324Code.GDStartOver_95TextObjects4= [];
gdjs.Level_324Code.GDStartOver_95TextObjects5= [];
gdjs.Level_324Code.GDStartOver_95TextObjects6= [];
gdjs.Level_324Code.GDStartOver_95TextObjects7= [];
gdjs.Level_324Code.GDSubmit_95TextObjects1= [];
gdjs.Level_324Code.GDSubmit_95TextObjects2= [];
gdjs.Level_324Code.GDSubmit_95TextObjects3= [];
gdjs.Level_324Code.GDSubmit_95TextObjects4= [];
gdjs.Level_324Code.GDSubmit_95TextObjects5= [];
gdjs.Level_324Code.GDSubmit_95TextObjects6= [];
gdjs.Level_324Code.GDSubmit_95TextObjects7= [];
gdjs.Level_324Code.GDChina_95textObjects1= [];
gdjs.Level_324Code.GDChina_95textObjects2= [];
gdjs.Level_324Code.GDChina_95textObjects3= [];
gdjs.Level_324Code.GDChina_95textObjects4= [];
gdjs.Level_324Code.GDChina_95textObjects5= [];
gdjs.Level_324Code.GDChina_95textObjects6= [];
gdjs.Level_324Code.GDChina_95textObjects7= [];
gdjs.Level_324Code.GDSection_95text1Objects1= [];
gdjs.Level_324Code.GDSection_95text1Objects2= [];
gdjs.Level_324Code.GDSection_95text1Objects3= [];
gdjs.Level_324Code.GDSection_95text1Objects4= [];
gdjs.Level_324Code.GDSection_95text1Objects5= [];
gdjs.Level_324Code.GDSection_95text1Objects6= [];
gdjs.Level_324Code.GDSection_95text1Objects7= [];
gdjs.Level_324Code.GDSource_95textObjects1= [];
gdjs.Level_324Code.GDSource_95textObjects2= [];
gdjs.Level_324Code.GDSource_95textObjects3= [];
gdjs.Level_324Code.GDSource_95textObjects4= [];
gdjs.Level_324Code.GDSource_95textObjects5= [];
gdjs.Level_324Code.GDSource_95textObjects6= [];
gdjs.Level_324Code.GDSource_95textObjects7= [];
gdjs.Level_324Code.GDYear_95textObjects1= [];
gdjs.Level_324Code.GDYear_95textObjects2= [];
gdjs.Level_324Code.GDYear_95textObjects3= [];
gdjs.Level_324Code.GDYear_95textObjects4= [];
gdjs.Level_324Code.GDYear_95textObjects5= [];
gdjs.Level_324Code.GDYear_95textObjects6= [];
gdjs.Level_324Code.GDYear_95textObjects7= [];
gdjs.Level_324Code.GDYesObjects1= [];
gdjs.Level_324Code.GDYesObjects2= [];
gdjs.Level_324Code.GDYesObjects3= [];
gdjs.Level_324Code.GDYesObjects4= [];
gdjs.Level_324Code.GDYesObjects5= [];
gdjs.Level_324Code.GDYesObjects6= [];
gdjs.Level_324Code.GDYesObjects7= [];
gdjs.Level_324Code.GDYes2Objects1= [];
gdjs.Level_324Code.GDYes2Objects2= [];
gdjs.Level_324Code.GDYes2Objects3= [];
gdjs.Level_324Code.GDYes2Objects4= [];
gdjs.Level_324Code.GDYes2Objects5= [];
gdjs.Level_324Code.GDYes2Objects6= [];
gdjs.Level_324Code.GDYes2Objects7= [];
gdjs.Level_324Code.GDYes3Objects1= [];
gdjs.Level_324Code.GDYes3Objects2= [];
gdjs.Level_324Code.GDYes3Objects3= [];
gdjs.Level_324Code.GDYes3Objects4= [];
gdjs.Level_324Code.GDYes3Objects5= [];
gdjs.Level_324Code.GDYes3Objects6= [];
gdjs.Level_324Code.GDYes3Objects7= [];
gdjs.Level_324Code.GDYes32Objects1= [];
gdjs.Level_324Code.GDYes32Objects2= [];
gdjs.Level_324Code.GDYes32Objects3= [];
gdjs.Level_324Code.GDYes32Objects4= [];
gdjs.Level_324Code.GDYes32Objects5= [];
gdjs.Level_324Code.GDYes32Objects6= [];
gdjs.Level_324Code.GDYes32Objects7= [];
gdjs.Level_324Code.GDYes4Objects1= [];
gdjs.Level_324Code.GDYes4Objects2= [];
gdjs.Level_324Code.GDYes4Objects3= [];
gdjs.Level_324Code.GDYes4Objects4= [];
gdjs.Level_324Code.GDYes4Objects5= [];
gdjs.Level_324Code.GDYes4Objects6= [];
gdjs.Level_324Code.GDYes4Objects7= [];
gdjs.Level_324Code.GDYes5Objects1= [];
gdjs.Level_324Code.GDYes5Objects2= [];
gdjs.Level_324Code.GDYes5Objects3= [];
gdjs.Level_324Code.GDYes5Objects4= [];
gdjs.Level_324Code.GDYes5Objects5= [];
gdjs.Level_324Code.GDYes5Objects6= [];
gdjs.Level_324Code.GDYes5Objects7= [];
gdjs.Level_324Code.GDYes6Objects1= [];
gdjs.Level_324Code.GDYes6Objects2= [];
gdjs.Level_324Code.GDYes6Objects3= [];
gdjs.Level_324Code.GDYes6Objects4= [];
gdjs.Level_324Code.GDYes6Objects5= [];
gdjs.Level_324Code.GDYes6Objects6= [];
gdjs.Level_324Code.GDYes6Objects7= [];
gdjs.Level_324Code.GDYes7Objects1= [];
gdjs.Level_324Code.GDYes7Objects2= [];
gdjs.Level_324Code.GDYes7Objects3= [];
gdjs.Level_324Code.GDYes7Objects4= [];
gdjs.Level_324Code.GDYes7Objects5= [];
gdjs.Level_324Code.GDYes7Objects6= [];
gdjs.Level_324Code.GDYes7Objects7= [];
gdjs.Level_324Code.GDYes8Objects1= [];
gdjs.Level_324Code.GDYes8Objects2= [];
gdjs.Level_324Code.GDYes8Objects3= [];
gdjs.Level_324Code.GDYes8Objects4= [];
gdjs.Level_324Code.GDYes8Objects5= [];
gdjs.Level_324Code.GDYes8Objects6= [];
gdjs.Level_324Code.GDYes8Objects7= [];
gdjs.Level_324Code.GDChinaObjects1= [];
gdjs.Level_324Code.GDChinaObjects2= [];
gdjs.Level_324Code.GDChinaObjects3= [];
gdjs.Level_324Code.GDChinaObjects4= [];
gdjs.Level_324Code.GDChinaObjects5= [];
gdjs.Level_324Code.GDChinaObjects6= [];
gdjs.Level_324Code.GDChinaObjects7= [];
gdjs.Level_324Code.GDNoObjects1= [];
gdjs.Level_324Code.GDNoObjects2= [];
gdjs.Level_324Code.GDNoObjects3= [];
gdjs.Level_324Code.GDNoObjects4= [];
gdjs.Level_324Code.GDNoObjects5= [];
gdjs.Level_324Code.GDNoObjects6= [];
gdjs.Level_324Code.GDNoObjects7= [];
gdjs.Level_324Code.GDNo2Objects1= [];
gdjs.Level_324Code.GDNo2Objects2= [];
gdjs.Level_324Code.GDNo2Objects3= [];
gdjs.Level_324Code.GDNo2Objects4= [];
gdjs.Level_324Code.GDNo2Objects5= [];
gdjs.Level_324Code.GDNo2Objects6= [];
gdjs.Level_324Code.GDNo2Objects7= [];
gdjs.Level_324Code.GDNo3Objects1= [];
gdjs.Level_324Code.GDNo3Objects2= [];
gdjs.Level_324Code.GDNo3Objects3= [];
gdjs.Level_324Code.GDNo3Objects4= [];
gdjs.Level_324Code.GDNo3Objects5= [];
gdjs.Level_324Code.GDNo3Objects6= [];
gdjs.Level_324Code.GDNo3Objects7= [];
gdjs.Level_324Code.GDNo4Objects1= [];
gdjs.Level_324Code.GDNo4Objects2= [];
gdjs.Level_324Code.GDNo4Objects3= [];
gdjs.Level_324Code.GDNo4Objects4= [];
gdjs.Level_324Code.GDNo4Objects5= [];
gdjs.Level_324Code.GDNo4Objects6= [];
gdjs.Level_324Code.GDNo4Objects7= [];
gdjs.Level_324Code.GDNo5Objects1= [];
gdjs.Level_324Code.GDNo5Objects2= [];
gdjs.Level_324Code.GDNo5Objects3= [];
gdjs.Level_324Code.GDNo5Objects4= [];
gdjs.Level_324Code.GDNo5Objects5= [];
gdjs.Level_324Code.GDNo5Objects6= [];
gdjs.Level_324Code.GDNo5Objects7= [];
gdjs.Level_324Code.GDTutorial_95TextObjects1= [];
gdjs.Level_324Code.GDTutorial_95TextObjects2= [];
gdjs.Level_324Code.GDTutorial_95TextObjects3= [];
gdjs.Level_324Code.GDTutorial_95TextObjects4= [];
gdjs.Level_324Code.GDTutorial_95TextObjects5= [];
gdjs.Level_324Code.GDTutorial_95TextObjects6= [];
gdjs.Level_324Code.GDTutorial_95TextObjects7= [];
gdjs.Level_324Code.GDP_9513_954Objects1= [];
gdjs.Level_324Code.GDP_9513_954Objects2= [];
gdjs.Level_324Code.GDP_9513_954Objects3= [];
gdjs.Level_324Code.GDP_9513_954Objects4= [];
gdjs.Level_324Code.GDP_9513_954Objects5= [];
gdjs.Level_324Code.GDP_9513_954Objects6= [];
gdjs.Level_324Code.GDP_9513_954Objects7= [];
gdjs.Level_324Code.GDp_9527_956Objects1= [];
gdjs.Level_324Code.GDp_9527_956Objects2= [];
gdjs.Level_324Code.GDp_9527_956Objects3= [];
gdjs.Level_324Code.GDp_9527_956Objects4= [];
gdjs.Level_324Code.GDp_9527_956Objects5= [];
gdjs.Level_324Code.GDp_9527_956Objects6= [];
gdjs.Level_324Code.GDp_9527_956Objects7= [];
gdjs.Level_324Code.GDp_954_958Objects1= [];
gdjs.Level_324Code.GDp_954_958Objects2= [];
gdjs.Level_324Code.GDp_954_958Objects3= [];
gdjs.Level_324Code.GDp_954_958Objects4= [];
gdjs.Level_324Code.GDp_954_958Objects5= [];
gdjs.Level_324Code.GDp_954_958Objects6= [];
gdjs.Level_324Code.GDp_954_958Objects7= [];
gdjs.Level_324Code.GDp_958_955Objects1= [];
gdjs.Level_324Code.GDp_958_955Objects2= [];
gdjs.Level_324Code.GDp_958_955Objects3= [];
gdjs.Level_324Code.GDp_958_955Objects4= [];
gdjs.Level_324Code.GDp_958_955Objects5= [];
gdjs.Level_324Code.GDp_958_955Objects6= [];
gdjs.Level_324Code.GDp_958_955Objects7= [];
gdjs.Level_324Code.GDDrag_95textObjects1= [];
gdjs.Level_324Code.GDDrag_95textObjects2= [];
gdjs.Level_324Code.GDDrag_95textObjects3= [];
gdjs.Level_324Code.GDDrag_95textObjects4= [];
gdjs.Level_324Code.GDDrag_95textObjects5= [];
gdjs.Level_324Code.GDDrag_95textObjects6= [];
gdjs.Level_324Code.GDDrag_95textObjects7= [];

gdjs.Level_324Code.conditionTrue_0 = {val:false};
gdjs.Level_324Code.condition0IsTrue_0 = {val:false};
gdjs.Level_324Code.condition1IsTrue_0 = {val:false};
gdjs.Level_324Code.condition2IsTrue_0 = {val:false};
gdjs.Level_324Code.condition3IsTrue_0 = {val:false};
gdjs.Level_324Code.condition4IsTrue_0 = {val:false};
gdjs.Level_324Code.conditionTrue_1 = {val:false};
gdjs.Level_324Code.condition0IsTrue_1 = {val:false};
gdjs.Level_324Code.condition1IsTrue_1 = {val:false};
gdjs.Level_324Code.condition2IsTrue_1 = {val:false};
gdjs.Level_324Code.condition3IsTrue_1 = {val:false};
gdjs.Level_324Code.condition4IsTrue_1 = {val:false};
gdjs.Level_324Code.conditionTrue_2 = {val:false};
gdjs.Level_324Code.condition0IsTrue_2 = {val:false};
gdjs.Level_324Code.condition1IsTrue_2 = {val:false};
gdjs.Level_324Code.condition2IsTrue_2 = {val:false};
gdjs.Level_324Code.condition3IsTrue_2 = {val:false};
gdjs.Level_324Code.condition4IsTrue_2 = {val:false};


gdjs.Level_324Code.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "PlayTimer", runtimeScene, runtimeScene.getVariables().get("PlayTimer"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "MovesMade", runtimeScene, runtimeScene.getVariables().get("MovesMade"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "CurrentLevel", runtimeScene, runtimeScene.getVariables().get("CurrentLevel"));
}}

}


};gdjs.Level_324Code.eventsList1 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PlayTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "PlayTimer");
}}

}


};gdjs.Level_324Code.eventsList2 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Shared UI", 0, 0);
}}

}


{


{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Debugging");
}}

}


{


{
}

}


{


gdjs.Level_324Code.eventsList1(runtimeScene);
}


};gdjs.Level_324Code.eventsList3 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cloud1"), gdjs.Level_324Code.GDCloud1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud2"), gdjs.Level_324Code.GDCloud2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud3"), gdjs.Level_324Code.GDCloud3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud4"), gdjs.Level_324Code.GDCloud4Objects4);
{for(var i = 0, len = gdjs.Level_324Code.GDCloud1Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud1Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud2Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud2Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud3Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud3Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud4Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud4Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCloud1Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud1Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud2Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud2Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud3Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud3Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud4Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud4Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
}}

}


};gdjs.Level_324Code.eventsList4 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Clouds", 0, 0);
}
{ //Subevents
gdjs.Level_324Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList5 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) + 0), "", 0);
}}

}


{



}


{


{
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "SlideCameraIn", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 1000, "easeOutBack");
}}

}


};gdjs.Level_324Code.asyncCallback11127148 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getVariables().get("GameState").setString("Idle");
}}
gdjs.Level_324Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11127148(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList7 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("StartingZoom").setNumber(0.65);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("StartingZoom")), "", 0);
}}

}


{


gdjs.Level_324Code.eventsList5(runtimeScene);
}


{


{

{ //Subevents
gdjs.Level_324Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList8 = function(runtimeScene) {

{



}


};gdjs.Level_324Code.eventsList9 = function(runtimeScene) {

{



}


};gdjs.Level_324Code.eventsList10 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList0(runtimeScene);
}


{


gdjs.Level_324Code.eventsList2(runtimeScene);
}


{


gdjs.Level_324Code.eventsList4(runtimeScene);
}


{



}


{


gdjs.Level_324Code.eventsList7(runtimeScene);
}


{



}


{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ExplosionDelay");
}}

}


{



}


{


{
{runtimeScene.getVariables().get("PickupBall_Duration").setNumber(125);
}{runtimeScene.getVariables().get("MoveBall_Duration").setNumber(150);
}{runtimeScene.getVariables().get("DropBall_Duration").setNumber(150);
}{/* Unknown object - skipped. */}{runtimeScene.getVariables().get("MaxBallsPerCup").setNumber(4);
}}

}


{


gdjs.Level_324Code.eventsList8(runtimeScene);
}


{


gdjs.Level_324Code.eventsList9(runtimeScene);
}


};gdjs.Level_324Code.eventsList11 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects3, "Ball_4": gdjs.Level_324Code.GDBall_954Objects3, "Ball_5": gdjs.Level_324Code.GDBall_955Objects3, "Ball_6": gdjs.Level_324Code.GDBall_956Objects3});
gdjs.Level_324Code.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DraggingBall");
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("BallFloating");
}}

}


};gdjs.Level_324Code.asyncCallback11140508 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Level_324Code.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_324Code.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11140508(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList14 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.Level_324Code.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList15 = function(runtimeScene) {

{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Nikolay Overchenko - Whoosh, cartoon, whirring 2.aac", false, 20, gdjs.randomFloatInRange(1.5, 1.7));
}{gdjs.deviceVibration.startVibration(25);
}}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "PlayTimer");
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "PlayTimer");
}}

}


{


gdjs.Level_324Code.eventsList14(runtimeScene);
}


};gdjs.Level_324Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects3);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
gdjs.Level_324Code.condition2IsTrue_0.val = false;
gdjs.Level_324Code.condition3IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
/* Unknown object - skipped. */}if ( gdjs.Level_324Code.condition1IsTrue_0.val ) {
{
gdjs.Level_324Code.condition2IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects3Objects, 0, 0, false);
}if ( gdjs.Level_324Code.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_951Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_951Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_951Objects3[k] = gdjs.Level_324Code.GDBall_951Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_951Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_954Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_954Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_954Objects3[k] = gdjs.Level_324Code.GDBall_954Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_954Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_955Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_955Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_955Objects3[k] = gdjs.Level_324Code.GDBall_955Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_955Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_956Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_956Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_956Objects3[k] = gdjs.Level_324Code.GDBall_956Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_956Objects3.length = k;}}
}
}
if (gdjs.Level_324Code.condition3IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects3 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects3 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects3 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects3 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", 0 - 1.1 * (gdjs.Level_324Code.GDBall_951Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", 0 - 1.1 * (gdjs.Level_324Code.GDBall_954Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", 0 - 1.1 * (gdjs.Level_324Code.GDBall_955Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", 0 - 1.1 * (gdjs.Level_324Code.GDBall_956Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_951Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_954Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_955Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_956Objects3[i].getVariables().get("PickedUp"), true);
}
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{runtimeScene.getVariables().get("HoverOffsetX").setNumber(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 0);
}{runtimeScene.getVariables().get("HoverOffsetY").setNumber(gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 0 + 1.1 * (( gdjs.Level_324Code.GDBall_956Objects3.length === 0 ) ? (( gdjs.Level_324Code.GDBall_955Objects3.length === 0 ) ? (( gdjs.Level_324Code.GDBall_954Objects3.length === 0 ) ? (( gdjs.Level_324Code.GDBall_951Objects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDBall_951Objects3[0].getHeight()) :gdjs.Level_324Code.GDBall_954Objects3[0].getHeight()) :gdjs.Level_324Code.GDBall_955Objects3[0].getHeight()) :gdjs.Level_324Code.GDBall_956Objects3[0].getHeight()));
}{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects3[i].setLayer("FrontCups");
}
}
{ //Subevents
gdjs.Level_324Code.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList17 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11134756);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList18 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList17(runtimeScene);
}


};gdjs.Level_324Code.eventsList19 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "Idle";
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList20 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11142524);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DroppingBall");
}}

}


};gdjs.Level_324Code.eventsList21 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "BallFloating";
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_951Objects4[k] = gdjs.Level_324Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_954Objects4[k] = gdjs.Level_324Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_955Objects4[k] = gdjs.Level_324Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_956Objects4[k] = gdjs.Level_324Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_956Objects4.length = k;}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_951Objects4[i].getX()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_951Objects4[i].getY()), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_954Objects4[i].getX()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_954Objects4[i].getY()), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_955Objects4[i].getX()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_955Objects4[i].getY()), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_956Objects4[i].getX()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_956Objects4[i].getY()), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DroppingBall");
}}

}


};gdjs.Level_324Code.eventsList23 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "DraggingBall";
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList24 = function(runtimeScene) {

{


{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), false);
}{/* Unknown object - skipped. */}}

}


};gdjs.Level_324Code.eventsList25 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}{/* Unknown object - skipped. */}}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
/* Unknown object - skipped. */}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}{/* Unknown object - skipped. */}}

}


};gdjs.Level_324Code.eventsList26 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.asyncCallback11111428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects6);

{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects6[i].setLayer("Balls");
}
}{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_324Code.GDBall_951Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_324Code.GDBall_954Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_324Code.GDBall_955Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_324Code.GDBall_956Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
}{/* Unknown object - skipped. */}}
gdjs.Level_324Code.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_324Code.GDBall_951Objects5) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Level_324Code.GDBall_954Objects5) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Level_324Code.GDBall_955Objects5) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Level_324Code.GDBall_956Objects5) asyncObjectsList.addObject("Ball_6", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11111428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList28 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("MovesMade").add(1);
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDBall_951Objects4, gdjs.Level_324Code.GDBall_951Objects5);

gdjs.copyArray(gdjs.Level_324Code.GDBall_954Objects4, gdjs.Level_324Code.GDBall_954Objects5);

gdjs.copyArray(gdjs.Level_324Code.GDBall_955Objects4, gdjs.Level_324Code.GDBall_955Objects5);

gdjs.copyArray(gdjs.Level_324Code.GDBall_956Objects4, gdjs.Level_324Code.GDBall_956Objects5);

{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_324Code.GDBall_951Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_324Code.GDBall_954Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_324Code.GDBall_955Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_324Code.GDBall_956Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
}{gdjs.deviceVibration.startVibration(25);
}
{ //Subevents
gdjs.Level_324Code.eventsList27(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList29 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
gdjs.Level_324Code.condition2IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
/* Unknown object - skipped. */}if ( gdjs.Level_324Code.condition1IsTrue_0.val ) {
{
/* Unknown object - skipped. */}}
}
if (gdjs.Level_324Code.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.asyncCallback11111429 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects5);

{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects5[i].setLayer("Balls");
}
}{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_324Code.GDBall_951Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_324Code.GDBall_954Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_324Code.GDBall_955Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", 0, 0 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - 0 - 1) * (gdjs.Level_324Code.GDBall_956Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
}{/* Unknown object - skipped. */}}
gdjs.Level_324Code.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_324Code.GDBall_951Objects4) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Level_324Code.GDBall_954Objects4) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Level_324Code.GDBall_955Objects4) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Level_324Code.GDBall_956Objects4) asyncObjectsList.addObject("Ball_6", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11111429(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList31 = function(runtimeScene) {

{



}


{


{
/* Reuse gdjs.Level_324Code.GDBall_951Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_324Code.GDBall_951Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_324Code.GDBall_954Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_324Code.GDBall_955Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", 0, 0 - (1.5 * (gdjs.Level_324Code.GDBall_956Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
}{gdjs.deviceVibration.startVibration(25);
}
{ //Subevents
gdjs.Level_324Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList32 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
/* Unknown object - skipped. */}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList33 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList26(runtimeScene);
}


{


gdjs.Level_324Code.eventsList29(runtimeScene);
}


{


gdjs.Level_324Code.eventsList32(runtimeScene);
}


};gdjs.Level_324Code.eventsList34 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects4);
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), false);
}
}}

}


};gdjs.Level_324Code.asyncCallback11155300 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.deviceVibration.startVibration(25);
}{runtimeScene.getVariables().get("GameState").setString("CheckIfComplete");
}}
gdjs.Level_324Code.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration"))) / 1000), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11155300(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList36 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList34(runtimeScene);
}


{


{

{ //Subevents
gdjs.Level_324Code.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList37 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList24(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_951Objects4[k] = gdjs.Level_324Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_954Objects4[k] = gdjs.Level_324Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_955Objects4[k] = gdjs.Level_324Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_956Objects4[k] = gdjs.Level_324Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_956Objects4.length = k;}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList33(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_324Code.eventsList36(runtimeScene);
}


};gdjs.Level_324Code.eventsList38 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "DroppingBall";
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11146012);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList37(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4Objects = Hashtable.newFrom({"GdevelopGLogoWhite": gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects3Objects = Hashtable.newFrom({"GdevelopGLogoWhite": gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3});
gdjs.Level_324Code.asyncCallback11115444 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PauseMenu");
}}
gdjs.Level_324Code.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11115444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList40 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11114500);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4Objects, runtimeScene, true, true);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11112940);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects3Objects, runtimeScene, true, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.asyncCallback11117500 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Level_324Code.eventsList42 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11117500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.asyncCallback11117020 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("GdevelopGLogoWhite"), gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4);

{for(var i = 0, len = gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4[i].getBehavior("Tween").addObjectAngleTween("SpinLogo", 0, "swingFromTo", 1000, false);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList42(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_324Code.eventsList43 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3) asyncObjectsList.addObject("GdevelopGLogoWhite", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11117020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList44 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.condition0IsTrue_1.val = false;
gdjs.Level_324Code.condition1IsTrue_1.val = false;
{
gdjs.Level_324Code.condition0IsTrue_1.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "SpinLogo", 20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if( gdjs.Level_324Code.condition0IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level_324Code.condition1IsTrue_1.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if( gdjs.Level_324Code.condition1IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3);
{for(var i = 0, len = gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3[i].getBehavior("Tween").addObjectAngleTween("SpinLogo", 360, "swingFromTo", 1000, false);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList43(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_324Code.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Level_324Code.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Level_324Code.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Level_324Code.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Level_324Code.GDSubmit_95TextObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.eventsList45 = function(runtimeScene) {

{

/* Reuse gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_324Code.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_324Code.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_324Code.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_324Code.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_324Code.GDSubmit_95TextObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDSubmit_9595TextObjects4Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDPlay_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDPlay_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMainMenu_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDResetProgress_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDStartOver_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDSubmit_95TextObjects4[i].setColor("255;255;255");
}
}}

}


};gdjs.Level_324Code.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_324Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_324Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, runtimeScene, true, true);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects4[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_324Code.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Level_324Code.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Level_324Code.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Level_324Code.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Level_324Code.GDSubmit_95TextObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.eventsList47 = function(runtimeScene) {

{

/* Reuse gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_324Code.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_324Code.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_324Code.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_324Code.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_324Code.GDSubmit_95TextObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDSubmit_9595TextObjects4Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDPlay_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDPlay_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_324Code.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMainMenu_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_324Code.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDResetProgress_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_324Code.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDStartOver_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_324Code.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDSubmit_95TextObjects4[i].setColor("241;91;181");
}
}}

}


};gdjs.Level_324Code.eventsList48 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_324Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_324Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11173756);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects4[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.Level_324Code.eventsList47(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "GdevelopGLogoWhite": gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_324Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_324Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4 */
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects4[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects3, "GdevelopGLogoWhite": gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3, "Menu": gdjs.Level_324Code.GDMenuObjects3});
gdjs.Level_324Code.eventsList50 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11175812);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList49(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_324Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_324Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects3);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
gdjs.Level_324Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_95324Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3 */
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_324Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects3[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.Level_324Code.eventsList51 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList46(runtimeScene);
}


{


gdjs.Level_324Code.eventsList48(runtimeScene);
}


{


gdjs.Level_324Code.eventsList50(runtimeScene);
}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.asyncCallback11158492 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PauseMenu");
}}
gdjs.Level_324Code.eventsList52 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11158492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList53 = function(runtimeScene) {

{

gdjs.Level_324Code.GDMenuObjects3.length = 0;


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.GDMenuObjects3_1final.length = 0;gdjs.Level_324Code.condition0IsTrue_1.val = false;
gdjs.Level_324Code.condition1IsTrue_1.val = false;
{
gdjs.Level_324Code.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if( gdjs.Level_324Code.condition0IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects4);
{gdjs.Level_324Code.conditionTrue_2 = gdjs.Level_324Code.condition1IsTrue_1;
gdjs.Level_324Code.condition0IsTrue_2.val = false;
gdjs.Level_324Code.condition1IsTrue_2.val = false;
{
gdjs.Level_324Code.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level_324Code.condition0IsTrue_2.val ) {
{
gdjs.Level_324Code.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
gdjs.Level_324Code.conditionTrue_2.val = true && gdjs.Level_324Code.condition0IsTrue_2.val && gdjs.Level_324Code.condition1IsTrue_2.val;
}
if( gdjs.Level_324Code.condition1IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_324Code.GDMenuObjects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDMenuObjects3_1final.indexOf(gdjs.Level_324Code.GDMenuObjects4[j]) === -1 )
            gdjs.Level_324Code.GDMenuObjects3_1final.push(gdjs.Level_324Code.GDMenuObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_324Code.GDMenuObjects3_1final, gdjs.Level_324Code.GDMenuObjects3);
}
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList52(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList54 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11159956);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


};gdjs.Level_324Code.eventsList55 = function(runtimeScene) {

{


{
{/* Unknown object - skipped. */}}

}


{

gdjs.Level_324Code.GDBall_951Objects3.length = 0;

gdjs.Level_324Code.GDBall_954Objects3.length = 0;

gdjs.Level_324Code.GDBall_955Objects3.length = 0;

gdjs.Level_324Code.GDBall_956Objects3.length = 0;


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.GDBall_951Objects3_1final.length = 0;gdjs.Level_324Code.GDBall_954Objects3_1final.length = 0;gdjs.Level_324Code.GDBall_955Objects3_1final.length = 0;gdjs.Level_324Code.GDBall_956Objects3_1final.length = 0;gdjs.Level_324Code.condition0IsTrue_1.val = false;
gdjs.Level_324Code.condition1IsTrue_1.val = false;
{
/* Unknown object - skipped. */if( gdjs.Level_324Code.condition0IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects4);
{gdjs.Level_324Code.conditionTrue_2 = gdjs.Level_324Code.condition1IsTrue_1;
gdjs.Level_324Code.condition0IsTrue_2.val = false;
gdjs.Level_324Code.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_951Objects4[k] = gdjs.Level_324Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_954Objects4[k] = gdjs.Level_324Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_955Objects4[k] = gdjs.Level_324Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_956Objects4[k] = gdjs.Level_324Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_956Objects4.length = k;}if ( gdjs.Level_324Code.condition0IsTrue_2.val ) {
{
/* Unknown object - skipped. */}}
gdjs.Level_324Code.conditionTrue_2.val = true && gdjs.Level_324Code.condition0IsTrue_2.val && gdjs.Level_324Code.condition1IsTrue_2.val;
}
if( gdjs.Level_324Code.condition1IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_951Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_951Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_951Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_951Objects3_1final.push(gdjs.Level_324Code.GDBall_951Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_954Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_954Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_954Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_954Objects3_1final.push(gdjs.Level_324Code.GDBall_954Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_955Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_955Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_955Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_955Objects3_1final.push(gdjs.Level_324Code.GDBall_955Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_956Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_956Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_956Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_956Objects3_1final.push(gdjs.Level_324Code.GDBall_956Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_324Code.GDBall_951Objects3_1final, gdjs.Level_324Code.GDBall_951Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDBall_954Objects3_1final, gdjs.Level_324Code.GDBall_954Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDBall_955Objects3_1final, gdjs.Level_324Code.GDBall_955Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDBall_956Objects3_1final, gdjs.Level_324Code.GDBall_956Objects3);
}
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


};gdjs.Level_324Code.eventsList56 = function(runtimeScene) {

};gdjs.Level_324Code.eventsList57 = function(runtimeScene) {

{


{
{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Balls", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "FrontCups", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Debugging", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Clouds", 0, true, true, false, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level_324Code.eventsList58 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList41(runtimeScene);
}


{


gdjs.Level_324Code.eventsList44(runtimeScene);
}


{



}


{


gdjs.Level_324Code.eventsList51(runtimeScene);
}


{


gdjs.Level_324Code.eventsList53(runtimeScene);
}


{


gdjs.Level_324Code.eventsList54(runtimeScene);
}


{


gdjs.Level_324Code.eventsList55(runtimeScene);
}


{


gdjs.Level_324Code.eventsList56(runtimeScene);
}


{


gdjs.Level_324Code.eventsList57(runtimeScene);
}


};gdjs.Level_324Code.eventsList59 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList11(runtimeScene);
}


{


gdjs.Level_324Code.eventsList19(runtimeScene);
}


{


gdjs.Level_324Code.eventsList21(runtimeScene);
}


{


gdjs.Level_324Code.eventsList23(runtimeScene);
}


{


gdjs.Level_324Code.eventsList38(runtimeScene);
}


{


gdjs.Level_324Code.eventsList58(runtimeScene);
}


};gdjs.Level_324Code.eventsList60 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList59(runtimeScene);
}


{



}


};gdjs.Level_324Code.eventsList61 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Level_324Code.GDNoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Text"), gdjs.Level_324Code.GDTutorial_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Level_324Code.GDYesObjects2);
{for(var i = 0, len = gdjs.Level_324Code.GDTutorial_95TextObjects2.length ;i < len;++i) {
    gdjs.Level_324Code.GDTutorial_95TextObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_324Code.GDYesObjects2.length ;i < len;++i) {
    gdjs.Level_324Code.GDYesObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_324Code.GDNoObjects2.length ;i < len;++i) {
    gdjs.Level_324Code.GDNoObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Text"), gdjs.Level_324Code.GDTutorial_95TextObjects2);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
gdjs.Level_324Code.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDTutorial_95TextObjects2.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDTutorial_95TextObjects2[i].isVisible()) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDTutorial_95TextObjects2[k] = gdjs.Level_324Code.GDTutorial_95TextObjects2[i];
        ++k;
    }
}
gdjs.Level_324Code.GDTutorial_95TextObjects2.length = k;}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
gdjs.Level_324Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "Idle";
}if ( gdjs.Level_324Code.condition1IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition2IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10983780);
}
}}
}
if (gdjs.Level_324Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDTutorial_95TextObjects2 */
{for(var i = 0, len = gdjs.Level_324Code.GDTutorial_95TextObjects2.length ;i < len;++i) {
    gdjs.Level_324Code.GDTutorial_95TextObjects2[i].setX(gdjs.Level_324Code.GDTutorial_95TextObjects2[i].getX() - (gdjs.evtTools.camera.getCameraWidth(runtimeScene, "UI", 0)));
}
}{for(var i = 0, len = gdjs.Level_324Code.GDTutorial_95TextObjects2.length ;i < len;++i) {
    gdjs.Level_324Code.GDTutorial_95TextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDTutorial_95TextObjects2.length ;i < len;++i) {
    gdjs.Level_324Code.GDTutorial_95TextObjects2[i].getBehavior("Tween").addObjectPositionXTween("SlideInText", gdjs.evtTools.camera.getCameraX(runtimeScene, "UI", 0) - (gdjs.Level_324Code.GDTutorial_95TextObjects2[i].getWidth()) / 2, "easeOutQuad", 500, false);
}
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "LevelComplete";
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10985012);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Text"), gdjs.Level_324Code.GDTutorial_95TextObjects1);
{for(var i = 0, len = gdjs.Level_324Code.GDTutorial_95TextObjects1.length ;i < len;++i) {
    gdjs.Level_324Code.GDTutorial_95TextObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDp_959527_95956Objects2Objects = Hashtable.newFrom({"p_27_6": gdjs.Level_324Code.GDp_9527_956Objects2});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDChinaObjects2Objects = Hashtable.newFrom({"China": gdjs.Level_324Code.GDChinaObjects2});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDp_95954_95958Objects2Objects = Hashtable.newFrom({"p_4_8": gdjs.Level_324Code.GDp_954_958Objects2});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDChinaObjects2Objects = Hashtable.newFrom({"China": gdjs.Level_324Code.GDChinaObjects2});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDp_95958_95955Objects2Objects = Hashtable.newFrom({"p_8_5": gdjs.Level_324Code.GDp_958_955Objects2});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDChinaObjects2Objects = Hashtable.newFrom({"China": gdjs.Level_324Code.GDChinaObjects2});
gdjs.Level_324Code.asyncCallback10988244 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("No"), gdjs.Level_324Code.GDNoObjects2);

{for(var i = 0, len = gdjs.Level_324Code.GDNoObjects2.length ;i < len;++i) {
    gdjs.Level_324Code.GDNoObjects2[i].hide();
}
}}
gdjs.Level_324Code.eventsList62 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_324Code.GDNoObjects1) asyncObjectsList.addObject("No", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_324Code.asyncCallback10988244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDP_959513_95954Objects1Objects = Hashtable.newFrom({"P_13_4": gdjs.Level_324Code.GDP_9513_954Objects1});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDChinaObjects1Objects = Hashtable.newFrom({"China": gdjs.Level_324Code.GDChinaObjects1});
gdjs.Level_324Code.asyncCallback10989492 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 5", false);
}}
gdjs.Level_324Code.eventsList63 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_324Code.asyncCallback10989492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList64 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.Level_324Code.eventsList63(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList65 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList60(runtimeScene);
}


{


gdjs.Level_324Code.eventsList61(runtimeScene);
}


{



}


{

gdjs.Level_324Code.GDChinaObjects1.length = 0;

gdjs.Level_324Code.GDp_9527_956Objects1.length = 0;

gdjs.Level_324Code.GDp_954_958Objects1.length = 0;

gdjs.Level_324Code.GDp_958_955Objects1.length = 0;


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.GDChinaObjects1_1final.length = 0;gdjs.Level_324Code.GDp_9527_956Objects1_1final.length = 0;gdjs.Level_324Code.GDp_954_958Objects1_1final.length = 0;gdjs.Level_324Code.GDp_958_955Objects1_1final.length = 0;gdjs.Level_324Code.condition0IsTrue_1.val = false;
gdjs.Level_324Code.condition1IsTrue_1.val = false;
gdjs.Level_324Code.condition2IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("China"), gdjs.Level_324Code.GDChinaObjects2);
gdjs.copyArray(runtimeScene.getObjects("p_27_6"), gdjs.Level_324Code.GDp_9527_956Objects2);
gdjs.Level_324Code.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDp_959527_95956Objects2Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDChinaObjects2Objects, false, runtimeScene, false);
if( gdjs.Level_324Code.condition0IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_324Code.GDChinaObjects2.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDChinaObjects1_1final.indexOf(gdjs.Level_324Code.GDChinaObjects2[j]) === -1 )
            gdjs.Level_324Code.GDChinaObjects1_1final.push(gdjs.Level_324Code.GDChinaObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDp_9527_956Objects2.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDp_9527_956Objects1_1final.indexOf(gdjs.Level_324Code.GDp_9527_956Objects2[j]) === -1 )
            gdjs.Level_324Code.GDp_9527_956Objects1_1final.push(gdjs.Level_324Code.GDp_9527_956Objects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("China"), gdjs.Level_324Code.GDChinaObjects2);
gdjs.copyArray(runtimeScene.getObjects("p_4_8"), gdjs.Level_324Code.GDp_954_958Objects2);
gdjs.Level_324Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDp_95954_95958Objects2Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDChinaObjects2Objects, false, runtimeScene, false);
if( gdjs.Level_324Code.condition1IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_324Code.GDChinaObjects2.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDChinaObjects1_1final.indexOf(gdjs.Level_324Code.GDChinaObjects2[j]) === -1 )
            gdjs.Level_324Code.GDChinaObjects1_1final.push(gdjs.Level_324Code.GDChinaObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDp_954_958Objects2.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDp_954_958Objects1_1final.indexOf(gdjs.Level_324Code.GDp_954_958Objects2[j]) === -1 )
            gdjs.Level_324Code.GDp_954_958Objects1_1final.push(gdjs.Level_324Code.GDp_954_958Objects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("China"), gdjs.Level_324Code.GDChinaObjects2);
gdjs.copyArray(runtimeScene.getObjects("p_8_5"), gdjs.Level_324Code.GDp_958_955Objects2);
gdjs.Level_324Code.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDp_95958_95955Objects2Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDChinaObjects2Objects, false, runtimeScene, false);
if( gdjs.Level_324Code.condition2IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_324Code.GDChinaObjects2.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDChinaObjects1_1final.indexOf(gdjs.Level_324Code.GDChinaObjects2[j]) === -1 )
            gdjs.Level_324Code.GDChinaObjects1_1final.push(gdjs.Level_324Code.GDChinaObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDp_958_955Objects2.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDp_958_955Objects1_1final.indexOf(gdjs.Level_324Code.GDp_958_955Objects2[j]) === -1 )
            gdjs.Level_324Code.GDp_958_955Objects1_1final.push(gdjs.Level_324Code.GDp_958_955Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_324Code.GDChinaObjects1_1final, gdjs.Level_324Code.GDChinaObjects1);
gdjs.copyArray(gdjs.Level_324Code.GDp_9527_956Objects1_1final, gdjs.Level_324Code.GDp_9527_956Objects1);
gdjs.copyArray(gdjs.Level_324Code.GDp_954_958Objects1_1final, gdjs.Level_324Code.GDp_954_958Objects1);
gdjs.copyArray(gdjs.Level_324Code.GDp_958_955Objects1_1final, gdjs.Level_324Code.GDp_958_955Objects1);
}
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Level_324Code.GDNoObjects1);
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.sound.playSound(runtimeScene, "buzzer-or-wrong-answer-20582.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_324Code.GDNoObjects1.length ;i < len;++i) {
    gdjs.Level_324Code.GDNoObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList62(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("China"), gdjs.Level_324Code.GDChinaObjects1);
gdjs.copyArray(runtimeScene.getObjects("P_13_4"), gdjs.Level_324Code.GDP_9513_954Objects1);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDP_959513_95954Objects1Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDChinaObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Level_324Code.GDYesObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "correct-6033.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_324Code.GDYesObjects1.length ;i < len;++i) {
    gdjs.Level_324Code.GDYesObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList64(runtimeScene);} //End of subevents
}

}


};

gdjs.Level_324Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_324Code.GDBall_951Objects1.length = 0;
gdjs.Level_324Code.GDBall_951Objects2.length = 0;
gdjs.Level_324Code.GDBall_951Objects3.length = 0;
gdjs.Level_324Code.GDBall_951Objects4.length = 0;
gdjs.Level_324Code.GDBall_951Objects5.length = 0;
gdjs.Level_324Code.GDBall_951Objects6.length = 0;
gdjs.Level_324Code.GDBall_951Objects7.length = 0;
gdjs.Level_324Code.GDBall_954Objects1.length = 0;
gdjs.Level_324Code.GDBall_954Objects2.length = 0;
gdjs.Level_324Code.GDBall_954Objects3.length = 0;
gdjs.Level_324Code.GDBall_954Objects4.length = 0;
gdjs.Level_324Code.GDBall_954Objects5.length = 0;
gdjs.Level_324Code.GDBall_954Objects6.length = 0;
gdjs.Level_324Code.GDBall_954Objects7.length = 0;
gdjs.Level_324Code.GDBall_955Objects1.length = 0;
gdjs.Level_324Code.GDBall_955Objects2.length = 0;
gdjs.Level_324Code.GDBall_955Objects3.length = 0;
gdjs.Level_324Code.GDBall_955Objects4.length = 0;
gdjs.Level_324Code.GDBall_955Objects5.length = 0;
gdjs.Level_324Code.GDBall_955Objects6.length = 0;
gdjs.Level_324Code.GDBall_955Objects7.length = 0;
gdjs.Level_324Code.GDBall_956Objects1.length = 0;
gdjs.Level_324Code.GDBall_956Objects2.length = 0;
gdjs.Level_324Code.GDBall_956Objects3.length = 0;
gdjs.Level_324Code.GDBall_956Objects4.length = 0;
gdjs.Level_324Code.GDBall_956Objects5.length = 0;
gdjs.Level_324Code.GDBall_956Objects6.length = 0;
gdjs.Level_324Code.GDBall_956Objects7.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects6.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length = 0;
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects1.length = 0;
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects2.length = 0;
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects3.length = 0;
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects4.length = 0;
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects5.length = 0;
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects6.length = 0;
gdjs.Level_324Code.GDGdevelopGLogoWhiteObjects7.length = 0;
gdjs.Level_324Code.GDCloud1Objects1.length = 0;
gdjs.Level_324Code.GDCloud1Objects2.length = 0;
gdjs.Level_324Code.GDCloud1Objects3.length = 0;
gdjs.Level_324Code.GDCloud1Objects4.length = 0;
gdjs.Level_324Code.GDCloud1Objects5.length = 0;
gdjs.Level_324Code.GDCloud1Objects6.length = 0;
gdjs.Level_324Code.GDCloud1Objects7.length = 0;
gdjs.Level_324Code.GDCloud2Objects1.length = 0;
gdjs.Level_324Code.GDCloud2Objects2.length = 0;
gdjs.Level_324Code.GDCloud2Objects3.length = 0;
gdjs.Level_324Code.GDCloud2Objects4.length = 0;
gdjs.Level_324Code.GDCloud2Objects5.length = 0;
gdjs.Level_324Code.GDCloud2Objects6.length = 0;
gdjs.Level_324Code.GDCloud2Objects7.length = 0;
gdjs.Level_324Code.GDCloud3Objects1.length = 0;
gdjs.Level_324Code.GDCloud3Objects2.length = 0;
gdjs.Level_324Code.GDCloud3Objects3.length = 0;
gdjs.Level_324Code.GDCloud3Objects4.length = 0;
gdjs.Level_324Code.GDCloud3Objects5.length = 0;
gdjs.Level_324Code.GDCloud3Objects6.length = 0;
gdjs.Level_324Code.GDCloud3Objects7.length = 0;
gdjs.Level_324Code.GDCloud4Objects1.length = 0;
gdjs.Level_324Code.GDCloud4Objects2.length = 0;
gdjs.Level_324Code.GDCloud4Objects3.length = 0;
gdjs.Level_324Code.GDCloud4Objects4.length = 0;
gdjs.Level_324Code.GDCloud4Objects5.length = 0;
gdjs.Level_324Code.GDCloud4Objects6.length = 0;
gdjs.Level_324Code.GDCloud4Objects7.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects1.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects2.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects3.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects4.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects5.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects6.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects7.length = 0;
gdjs.Level_324Code.GDButtonCNObjects1.length = 0;
gdjs.Level_324Code.GDButtonCNObjects2.length = 0;
gdjs.Level_324Code.GDButtonCNObjects3.length = 0;
gdjs.Level_324Code.GDButtonCNObjects4.length = 0;
gdjs.Level_324Code.GDButtonCNObjects5.length = 0;
gdjs.Level_324Code.GDButtonCNObjects6.length = 0;
gdjs.Level_324Code.GDButtonCNObjects7.length = 0;
gdjs.Level_324Code.GDMenuObjects1.length = 0;
gdjs.Level_324Code.GDMenuObjects2.length = 0;
gdjs.Level_324Code.GDMenuObjects3.length = 0;
gdjs.Level_324Code.GDMenuObjects4.length = 0;
gdjs.Level_324Code.GDMenuObjects5.length = 0;
gdjs.Level_324Code.GDMenuObjects6.length = 0;
gdjs.Level_324Code.GDMenuObjects7.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects1.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects2.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects3.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects4.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects5.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects6.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects7.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects6.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects7.length = 0;
gdjs.Level_324Code.GDClick_95textObjects1.length = 0;
gdjs.Level_324Code.GDClick_95textObjects2.length = 0;
gdjs.Level_324Code.GDClick_95textObjects3.length = 0;
gdjs.Level_324Code.GDClick_95textObjects4.length = 0;
gdjs.Level_324Code.GDClick_95textObjects5.length = 0;
gdjs.Level_324Code.GDClick_95textObjects6.length = 0;
gdjs.Level_324Code.GDClick_95textObjects7.length = 0;
gdjs.Level_324Code.GDYarnObjects1.length = 0;
gdjs.Level_324Code.GDYarnObjects2.length = 0;
gdjs.Level_324Code.GDYarnObjects3.length = 0;
gdjs.Level_324Code.GDYarnObjects4.length = 0;
gdjs.Level_324Code.GDYarnObjects5.length = 0;
gdjs.Level_324Code.GDYarnObjects6.length = 0;
gdjs.Level_324Code.GDYarnObjects7.length = 0;
gdjs.Level_324Code.GDBullObjects1.length = 0;
gdjs.Level_324Code.GDBullObjects2.length = 0;
gdjs.Level_324Code.GDBullObjects3.length = 0;
gdjs.Level_324Code.GDBullObjects4.length = 0;
gdjs.Level_324Code.GDBullObjects5.length = 0;
gdjs.Level_324Code.GDBullObjects6.length = 0;
gdjs.Level_324Code.GDBullObjects7.length = 0;
gdjs.Level_324Code.GDClick_95text2Objects1.length = 0;
gdjs.Level_324Code.GDClick_95text2Objects2.length = 0;
gdjs.Level_324Code.GDClick_95text2Objects3.length = 0;
gdjs.Level_324Code.GDClick_95text2Objects4.length = 0;
gdjs.Level_324Code.GDClick_95text2Objects5.length = 0;
gdjs.Level_324Code.GDClick_95text2Objects6.length = 0;
gdjs.Level_324Code.GDClick_95text2Objects7.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects1.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects2.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects3.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects4.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects5.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects6.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects7.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects1.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects2.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects3.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects4.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects5.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects6.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects7.length = 0;
gdjs.Level_324Code.GDLeatherShoesObjects1.length = 0;
gdjs.Level_324Code.GDLeatherShoesObjects2.length = 0;
gdjs.Level_324Code.GDLeatherShoesObjects3.length = 0;
gdjs.Level_324Code.GDLeatherShoesObjects4.length = 0;
gdjs.Level_324Code.GDLeatherShoesObjects5.length = 0;
gdjs.Level_324Code.GDLeatherShoesObjects6.length = 0;
gdjs.Level_324Code.GDLeatherShoesObjects7.length = 0;
gdjs.Level_324Code.GDFurnitureObjects1.length = 0;
gdjs.Level_324Code.GDFurnitureObjects2.length = 0;
gdjs.Level_324Code.GDFurnitureObjects3.length = 0;
gdjs.Level_324Code.GDFurnitureObjects4.length = 0;
gdjs.Level_324Code.GDFurnitureObjects5.length = 0;
gdjs.Level_324Code.GDFurnitureObjects6.length = 0;
gdjs.Level_324Code.GDFurnitureObjects7.length = 0;
gdjs.Level_324Code.GDMagnifyingGlassObjects1.length = 0;
gdjs.Level_324Code.GDMagnifyingGlassObjects2.length = 0;
gdjs.Level_324Code.GDMagnifyingGlassObjects3.length = 0;
gdjs.Level_324Code.GDMagnifyingGlassObjects4.length = 0;
gdjs.Level_324Code.GDMagnifyingGlassObjects5.length = 0;
gdjs.Level_324Code.GDMagnifyingGlassObjects6.length = 0;
gdjs.Level_324Code.GDMagnifyingGlassObjects7.length = 0;
gdjs.Level_324Code.GDtoysObjects1.length = 0;
gdjs.Level_324Code.GDtoysObjects2.length = 0;
gdjs.Level_324Code.GDtoysObjects3.length = 0;
gdjs.Level_324Code.GDtoysObjects4.length = 0;
gdjs.Level_324Code.GDtoysObjects5.length = 0;
gdjs.Level_324Code.GDtoysObjects6.length = 0;
gdjs.Level_324Code.GDtoysObjects7.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects1.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects2.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects3.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects4.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects5.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects6.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects7.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects1.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects2.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects3.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects4.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects5.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects6.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects7.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects1.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects2.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects3.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects4.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects5.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects6.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects7.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects1.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects2.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects3.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects4.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects5.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects6.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects7.length = 0;
gdjs.Level_324Code.GDChina_95textObjects1.length = 0;
gdjs.Level_324Code.GDChina_95textObjects2.length = 0;
gdjs.Level_324Code.GDChina_95textObjects3.length = 0;
gdjs.Level_324Code.GDChina_95textObjects4.length = 0;
gdjs.Level_324Code.GDChina_95textObjects5.length = 0;
gdjs.Level_324Code.GDChina_95textObjects6.length = 0;
gdjs.Level_324Code.GDChina_95textObjects7.length = 0;
gdjs.Level_324Code.GDSection_95text1Objects1.length = 0;
gdjs.Level_324Code.GDSection_95text1Objects2.length = 0;
gdjs.Level_324Code.GDSection_95text1Objects3.length = 0;
gdjs.Level_324Code.GDSection_95text1Objects4.length = 0;
gdjs.Level_324Code.GDSection_95text1Objects5.length = 0;
gdjs.Level_324Code.GDSection_95text1Objects6.length = 0;
gdjs.Level_324Code.GDSection_95text1Objects7.length = 0;
gdjs.Level_324Code.GDSource_95textObjects1.length = 0;
gdjs.Level_324Code.GDSource_95textObjects2.length = 0;
gdjs.Level_324Code.GDSource_95textObjects3.length = 0;
gdjs.Level_324Code.GDSource_95textObjects4.length = 0;
gdjs.Level_324Code.GDSource_95textObjects5.length = 0;
gdjs.Level_324Code.GDSource_95textObjects6.length = 0;
gdjs.Level_324Code.GDSource_95textObjects7.length = 0;
gdjs.Level_324Code.GDYear_95textObjects1.length = 0;
gdjs.Level_324Code.GDYear_95textObjects2.length = 0;
gdjs.Level_324Code.GDYear_95textObjects3.length = 0;
gdjs.Level_324Code.GDYear_95textObjects4.length = 0;
gdjs.Level_324Code.GDYear_95textObjects5.length = 0;
gdjs.Level_324Code.GDYear_95textObjects6.length = 0;
gdjs.Level_324Code.GDYear_95textObjects7.length = 0;
gdjs.Level_324Code.GDYesObjects1.length = 0;
gdjs.Level_324Code.GDYesObjects2.length = 0;
gdjs.Level_324Code.GDYesObjects3.length = 0;
gdjs.Level_324Code.GDYesObjects4.length = 0;
gdjs.Level_324Code.GDYesObjects5.length = 0;
gdjs.Level_324Code.GDYesObjects6.length = 0;
gdjs.Level_324Code.GDYesObjects7.length = 0;
gdjs.Level_324Code.GDYes2Objects1.length = 0;
gdjs.Level_324Code.GDYes2Objects2.length = 0;
gdjs.Level_324Code.GDYes2Objects3.length = 0;
gdjs.Level_324Code.GDYes2Objects4.length = 0;
gdjs.Level_324Code.GDYes2Objects5.length = 0;
gdjs.Level_324Code.GDYes2Objects6.length = 0;
gdjs.Level_324Code.GDYes2Objects7.length = 0;
gdjs.Level_324Code.GDYes3Objects1.length = 0;
gdjs.Level_324Code.GDYes3Objects2.length = 0;
gdjs.Level_324Code.GDYes3Objects3.length = 0;
gdjs.Level_324Code.GDYes3Objects4.length = 0;
gdjs.Level_324Code.GDYes3Objects5.length = 0;
gdjs.Level_324Code.GDYes3Objects6.length = 0;
gdjs.Level_324Code.GDYes3Objects7.length = 0;
gdjs.Level_324Code.GDYes32Objects1.length = 0;
gdjs.Level_324Code.GDYes32Objects2.length = 0;
gdjs.Level_324Code.GDYes32Objects3.length = 0;
gdjs.Level_324Code.GDYes32Objects4.length = 0;
gdjs.Level_324Code.GDYes32Objects5.length = 0;
gdjs.Level_324Code.GDYes32Objects6.length = 0;
gdjs.Level_324Code.GDYes32Objects7.length = 0;
gdjs.Level_324Code.GDYes4Objects1.length = 0;
gdjs.Level_324Code.GDYes4Objects2.length = 0;
gdjs.Level_324Code.GDYes4Objects3.length = 0;
gdjs.Level_324Code.GDYes4Objects4.length = 0;
gdjs.Level_324Code.GDYes4Objects5.length = 0;
gdjs.Level_324Code.GDYes4Objects6.length = 0;
gdjs.Level_324Code.GDYes4Objects7.length = 0;
gdjs.Level_324Code.GDYes5Objects1.length = 0;
gdjs.Level_324Code.GDYes5Objects2.length = 0;
gdjs.Level_324Code.GDYes5Objects3.length = 0;
gdjs.Level_324Code.GDYes5Objects4.length = 0;
gdjs.Level_324Code.GDYes5Objects5.length = 0;
gdjs.Level_324Code.GDYes5Objects6.length = 0;
gdjs.Level_324Code.GDYes5Objects7.length = 0;
gdjs.Level_324Code.GDYes6Objects1.length = 0;
gdjs.Level_324Code.GDYes6Objects2.length = 0;
gdjs.Level_324Code.GDYes6Objects3.length = 0;
gdjs.Level_324Code.GDYes6Objects4.length = 0;
gdjs.Level_324Code.GDYes6Objects5.length = 0;
gdjs.Level_324Code.GDYes6Objects6.length = 0;
gdjs.Level_324Code.GDYes6Objects7.length = 0;
gdjs.Level_324Code.GDYes7Objects1.length = 0;
gdjs.Level_324Code.GDYes7Objects2.length = 0;
gdjs.Level_324Code.GDYes7Objects3.length = 0;
gdjs.Level_324Code.GDYes7Objects4.length = 0;
gdjs.Level_324Code.GDYes7Objects5.length = 0;
gdjs.Level_324Code.GDYes7Objects6.length = 0;
gdjs.Level_324Code.GDYes7Objects7.length = 0;
gdjs.Level_324Code.GDYes8Objects1.length = 0;
gdjs.Level_324Code.GDYes8Objects2.length = 0;
gdjs.Level_324Code.GDYes8Objects3.length = 0;
gdjs.Level_324Code.GDYes8Objects4.length = 0;
gdjs.Level_324Code.GDYes8Objects5.length = 0;
gdjs.Level_324Code.GDYes8Objects6.length = 0;
gdjs.Level_324Code.GDYes8Objects7.length = 0;
gdjs.Level_324Code.GDChinaObjects1.length = 0;
gdjs.Level_324Code.GDChinaObjects2.length = 0;
gdjs.Level_324Code.GDChinaObjects3.length = 0;
gdjs.Level_324Code.GDChinaObjects4.length = 0;
gdjs.Level_324Code.GDChinaObjects5.length = 0;
gdjs.Level_324Code.GDChinaObjects6.length = 0;
gdjs.Level_324Code.GDChinaObjects7.length = 0;
gdjs.Level_324Code.GDNoObjects1.length = 0;
gdjs.Level_324Code.GDNoObjects2.length = 0;
gdjs.Level_324Code.GDNoObjects3.length = 0;
gdjs.Level_324Code.GDNoObjects4.length = 0;
gdjs.Level_324Code.GDNoObjects5.length = 0;
gdjs.Level_324Code.GDNoObjects6.length = 0;
gdjs.Level_324Code.GDNoObjects7.length = 0;
gdjs.Level_324Code.GDNo2Objects1.length = 0;
gdjs.Level_324Code.GDNo2Objects2.length = 0;
gdjs.Level_324Code.GDNo2Objects3.length = 0;
gdjs.Level_324Code.GDNo2Objects4.length = 0;
gdjs.Level_324Code.GDNo2Objects5.length = 0;
gdjs.Level_324Code.GDNo2Objects6.length = 0;
gdjs.Level_324Code.GDNo2Objects7.length = 0;
gdjs.Level_324Code.GDNo3Objects1.length = 0;
gdjs.Level_324Code.GDNo3Objects2.length = 0;
gdjs.Level_324Code.GDNo3Objects3.length = 0;
gdjs.Level_324Code.GDNo3Objects4.length = 0;
gdjs.Level_324Code.GDNo3Objects5.length = 0;
gdjs.Level_324Code.GDNo3Objects6.length = 0;
gdjs.Level_324Code.GDNo3Objects7.length = 0;
gdjs.Level_324Code.GDNo4Objects1.length = 0;
gdjs.Level_324Code.GDNo4Objects2.length = 0;
gdjs.Level_324Code.GDNo4Objects3.length = 0;
gdjs.Level_324Code.GDNo4Objects4.length = 0;
gdjs.Level_324Code.GDNo4Objects5.length = 0;
gdjs.Level_324Code.GDNo4Objects6.length = 0;
gdjs.Level_324Code.GDNo4Objects7.length = 0;
gdjs.Level_324Code.GDNo5Objects1.length = 0;
gdjs.Level_324Code.GDNo5Objects2.length = 0;
gdjs.Level_324Code.GDNo5Objects3.length = 0;
gdjs.Level_324Code.GDNo5Objects4.length = 0;
gdjs.Level_324Code.GDNo5Objects5.length = 0;
gdjs.Level_324Code.GDNo5Objects6.length = 0;
gdjs.Level_324Code.GDNo5Objects7.length = 0;
gdjs.Level_324Code.GDTutorial_95TextObjects1.length = 0;
gdjs.Level_324Code.GDTutorial_95TextObjects2.length = 0;
gdjs.Level_324Code.GDTutorial_95TextObjects3.length = 0;
gdjs.Level_324Code.GDTutorial_95TextObjects4.length = 0;
gdjs.Level_324Code.GDTutorial_95TextObjects5.length = 0;
gdjs.Level_324Code.GDTutorial_95TextObjects6.length = 0;
gdjs.Level_324Code.GDTutorial_95TextObjects7.length = 0;
gdjs.Level_324Code.GDP_9513_954Objects1.length = 0;
gdjs.Level_324Code.GDP_9513_954Objects2.length = 0;
gdjs.Level_324Code.GDP_9513_954Objects3.length = 0;
gdjs.Level_324Code.GDP_9513_954Objects4.length = 0;
gdjs.Level_324Code.GDP_9513_954Objects5.length = 0;
gdjs.Level_324Code.GDP_9513_954Objects6.length = 0;
gdjs.Level_324Code.GDP_9513_954Objects7.length = 0;
gdjs.Level_324Code.GDp_9527_956Objects1.length = 0;
gdjs.Level_324Code.GDp_9527_956Objects2.length = 0;
gdjs.Level_324Code.GDp_9527_956Objects3.length = 0;
gdjs.Level_324Code.GDp_9527_956Objects4.length = 0;
gdjs.Level_324Code.GDp_9527_956Objects5.length = 0;
gdjs.Level_324Code.GDp_9527_956Objects6.length = 0;
gdjs.Level_324Code.GDp_9527_956Objects7.length = 0;
gdjs.Level_324Code.GDp_954_958Objects1.length = 0;
gdjs.Level_324Code.GDp_954_958Objects2.length = 0;
gdjs.Level_324Code.GDp_954_958Objects3.length = 0;
gdjs.Level_324Code.GDp_954_958Objects4.length = 0;
gdjs.Level_324Code.GDp_954_958Objects5.length = 0;
gdjs.Level_324Code.GDp_954_958Objects6.length = 0;
gdjs.Level_324Code.GDp_954_958Objects7.length = 0;
gdjs.Level_324Code.GDp_958_955Objects1.length = 0;
gdjs.Level_324Code.GDp_958_955Objects2.length = 0;
gdjs.Level_324Code.GDp_958_955Objects3.length = 0;
gdjs.Level_324Code.GDp_958_955Objects4.length = 0;
gdjs.Level_324Code.GDp_958_955Objects5.length = 0;
gdjs.Level_324Code.GDp_958_955Objects6.length = 0;
gdjs.Level_324Code.GDp_958_955Objects7.length = 0;
gdjs.Level_324Code.GDDrag_95textObjects1.length = 0;
gdjs.Level_324Code.GDDrag_95textObjects2.length = 0;
gdjs.Level_324Code.GDDrag_95textObjects3.length = 0;
gdjs.Level_324Code.GDDrag_95textObjects4.length = 0;
gdjs.Level_324Code.GDDrag_95textObjects5.length = 0;
gdjs.Level_324Code.GDDrag_95textObjects6.length = 0;
gdjs.Level_324Code.GDDrag_95textObjects7.length = 0;

gdjs.Level_324Code.eventsList65(runtimeScene);
return;

}

gdjs['Level_324Code'] = gdjs.Level_324Code;
