gdjs.Level_3211Code = {};
gdjs.Level_3211Code.repeatCount4 = 0;

gdjs.Level_3211Code.repeatIndex4 = 0;

gdjs.Level_3211Code.GDBall_951Objects1= [];
gdjs.Level_3211Code.GDBall_951Objects2= [];
gdjs.Level_3211Code.GDBall_951Objects3= [];
gdjs.Level_3211Code.GDBall_951Objects4= [];
gdjs.Level_3211Code.GDBall_951Objects5= [];
gdjs.Level_3211Code.GDBall_951Objects6= [];
gdjs.Level_3211Code.GDBall_954Objects1= [];
gdjs.Level_3211Code.GDBall_954Objects2= [];
gdjs.Level_3211Code.GDBall_954Objects3= [];
gdjs.Level_3211Code.GDBall_954Objects4= [];
gdjs.Level_3211Code.GDBall_954Objects5= [];
gdjs.Level_3211Code.GDBall_954Objects6= [];
gdjs.Level_3211Code.GDBall_955Objects1= [];
gdjs.Level_3211Code.GDBall_955Objects2= [];
gdjs.Level_3211Code.GDBall_955Objects3= [];
gdjs.Level_3211Code.GDBall_955Objects4= [];
gdjs.Level_3211Code.GDBall_955Objects5= [];
gdjs.Level_3211Code.GDBall_955Objects6= [];
gdjs.Level_3211Code.GDBall_956Objects1= [];
gdjs.Level_3211Code.GDBall_956Objects2= [];
gdjs.Level_3211Code.GDBall_956Objects3= [];
gdjs.Level_3211Code.GDBall_956Objects4= [];
gdjs.Level_3211Code.GDBall_956Objects5= [];
gdjs.Level_3211Code.GDBall_956Objects6= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects6= [];
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects1= [];
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects2= [];
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3= [];
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects4= [];
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects5= [];
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects6= [];
gdjs.Level_3211Code.GDCloud1Objects1= [];
gdjs.Level_3211Code.GDCloud1Objects2= [];
gdjs.Level_3211Code.GDCloud1Objects3= [];
gdjs.Level_3211Code.GDCloud1Objects4= [];
gdjs.Level_3211Code.GDCloud1Objects5= [];
gdjs.Level_3211Code.GDCloud1Objects6= [];
gdjs.Level_3211Code.GDCloud2Objects1= [];
gdjs.Level_3211Code.GDCloud2Objects2= [];
gdjs.Level_3211Code.GDCloud2Objects3= [];
gdjs.Level_3211Code.GDCloud2Objects4= [];
gdjs.Level_3211Code.GDCloud2Objects5= [];
gdjs.Level_3211Code.GDCloud2Objects6= [];
gdjs.Level_3211Code.GDCloud3Objects1= [];
gdjs.Level_3211Code.GDCloud3Objects2= [];
gdjs.Level_3211Code.GDCloud3Objects3= [];
gdjs.Level_3211Code.GDCloud3Objects4= [];
gdjs.Level_3211Code.GDCloud3Objects5= [];
gdjs.Level_3211Code.GDCloud3Objects6= [];
gdjs.Level_3211Code.GDCloud4Objects1= [];
gdjs.Level_3211Code.GDCloud4Objects2= [];
gdjs.Level_3211Code.GDCloud4Objects3= [];
gdjs.Level_3211Code.GDCloud4Objects4= [];
gdjs.Level_3211Code.GDCloud4Objects5= [];
gdjs.Level_3211Code.GDCloud4Objects6= [];
gdjs.Level_3211Code.GDGreyButtonObjects1= [];
gdjs.Level_3211Code.GDGreyButtonObjects2= [];
gdjs.Level_3211Code.GDGreyButtonObjects3= [];
gdjs.Level_3211Code.GDGreyButtonObjects4= [];
gdjs.Level_3211Code.GDGreyButtonObjects5= [];
gdjs.Level_3211Code.GDGreyButtonObjects6= [];
gdjs.Level_3211Code.GDButtonCNObjects1= [];
gdjs.Level_3211Code.GDButtonCNObjects2= [];
gdjs.Level_3211Code.GDButtonCNObjects3= [];
gdjs.Level_3211Code.GDButtonCNObjects4= [];
gdjs.Level_3211Code.GDButtonCNObjects5= [];
gdjs.Level_3211Code.GDButtonCNObjects6= [];
gdjs.Level_3211Code.GDMenuObjects1= [];
gdjs.Level_3211Code.GDMenuObjects2= [];
gdjs.Level_3211Code.GDMenuObjects3= [];
gdjs.Level_3211Code.GDMenuObjects4= [];
gdjs.Level_3211Code.GDMenuObjects5= [];
gdjs.Level_3211Code.GDMenuObjects6= [];
gdjs.Level_3211Code.GDGameState_95TextObjects1= [];
gdjs.Level_3211Code.GDGameState_95TextObjects2= [];
gdjs.Level_3211Code.GDGameState_95TextObjects3= [];
gdjs.Level_3211Code.GDGameState_95TextObjects4= [];
gdjs.Level_3211Code.GDGameState_95TextObjects5= [];
gdjs.Level_3211Code.GDGameState_95TextObjects6= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects1= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects2= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects3= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects4= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects5= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects6= [];
gdjs.Level_3211Code.GDClick_95textObjects1= [];
gdjs.Level_3211Code.GDClick_95textObjects2= [];
gdjs.Level_3211Code.GDClick_95textObjects3= [];
gdjs.Level_3211Code.GDClick_95textObjects4= [];
gdjs.Level_3211Code.GDClick_95textObjects5= [];
gdjs.Level_3211Code.GDClick_95textObjects6= [];
gdjs.Level_3211Code.GDYarnObjects1= [];
gdjs.Level_3211Code.GDYarnObjects2= [];
gdjs.Level_3211Code.GDYarnObjects3= [];
gdjs.Level_3211Code.GDYarnObjects4= [];
gdjs.Level_3211Code.GDYarnObjects5= [];
gdjs.Level_3211Code.GDYarnObjects6= [];
gdjs.Level_3211Code.GDBullObjects1= [];
gdjs.Level_3211Code.GDBullObjects2= [];
gdjs.Level_3211Code.GDBullObjects3= [];
gdjs.Level_3211Code.GDBullObjects4= [];
gdjs.Level_3211Code.GDBullObjects5= [];
gdjs.Level_3211Code.GDBullObjects6= [];
gdjs.Level_3211Code.GDClick_95text2Objects1= [];
gdjs.Level_3211Code.GDClick_95text2Objects2= [];
gdjs.Level_3211Code.GDClick_95text2Objects3= [];
gdjs.Level_3211Code.GDClick_95text2Objects4= [];
gdjs.Level_3211Code.GDClick_95text2Objects5= [];
gdjs.Level_3211Code.GDClick_95text2Objects6= [];
gdjs.Level_3211Code.GDPlay_95TextObjects1= [];
gdjs.Level_3211Code.GDPlay_95TextObjects2= [];
gdjs.Level_3211Code.GDPlay_95TextObjects3= [];
gdjs.Level_3211Code.GDPlay_95TextObjects4= [];
gdjs.Level_3211Code.GDPlay_95TextObjects5= [];
gdjs.Level_3211Code.GDPlay_95TextObjects6= [];
gdjs.Level_3211Code.GDLeaderboardObjects1= [];
gdjs.Level_3211Code.GDLeaderboardObjects2= [];
gdjs.Level_3211Code.GDLeaderboardObjects3= [];
gdjs.Level_3211Code.GDLeaderboardObjects4= [];
gdjs.Level_3211Code.GDLeaderboardObjects5= [];
gdjs.Level_3211Code.GDLeaderboardObjects6= [];
gdjs.Level_3211Code.GDLeatherShoesObjects1= [];
gdjs.Level_3211Code.GDLeatherShoesObjects2= [];
gdjs.Level_3211Code.GDLeatherShoesObjects3= [];
gdjs.Level_3211Code.GDLeatherShoesObjects4= [];
gdjs.Level_3211Code.GDLeatherShoesObjects5= [];
gdjs.Level_3211Code.GDLeatherShoesObjects6= [];
gdjs.Level_3211Code.GDFurnitureObjects1= [];
gdjs.Level_3211Code.GDFurnitureObjects2= [];
gdjs.Level_3211Code.GDFurnitureObjects3= [];
gdjs.Level_3211Code.GDFurnitureObjects4= [];
gdjs.Level_3211Code.GDFurnitureObjects5= [];
gdjs.Level_3211Code.GDFurnitureObjects6= [];
gdjs.Level_3211Code.GDMagnifyingGlassObjects1= [];
gdjs.Level_3211Code.GDMagnifyingGlassObjects2= [];
gdjs.Level_3211Code.GDMagnifyingGlassObjects3= [];
gdjs.Level_3211Code.GDMagnifyingGlassObjects4= [];
gdjs.Level_3211Code.GDMagnifyingGlassObjects5= [];
gdjs.Level_3211Code.GDMagnifyingGlassObjects6= [];
gdjs.Level_3211Code.GDtoysObjects1= [];
gdjs.Level_3211Code.GDtoysObjects2= [];
gdjs.Level_3211Code.GDtoysObjects3= [];
gdjs.Level_3211Code.GDtoysObjects4= [];
gdjs.Level_3211Code.GDtoysObjects5= [];
gdjs.Level_3211Code.GDtoysObjects6= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects1= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects2= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects3= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects4= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects5= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects6= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects1= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects2= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects3= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects4= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects5= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects6= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects1= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects2= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects3= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects4= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects5= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects6= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects1= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects2= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects3= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects4= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects5= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects6= [];
gdjs.Level_3211Code.GDChina_95textObjects1= [];
gdjs.Level_3211Code.GDChina_95textObjects2= [];
gdjs.Level_3211Code.GDChina_95textObjects3= [];
gdjs.Level_3211Code.GDChina_95textObjects4= [];
gdjs.Level_3211Code.GDChina_95textObjects5= [];
gdjs.Level_3211Code.GDChina_95textObjects6= [];
gdjs.Level_3211Code.GDSection_95text1Objects1= [];
gdjs.Level_3211Code.GDSection_95text1Objects2= [];
gdjs.Level_3211Code.GDSection_95text1Objects3= [];
gdjs.Level_3211Code.GDSection_95text1Objects4= [];
gdjs.Level_3211Code.GDSection_95text1Objects5= [];
gdjs.Level_3211Code.GDSection_95text1Objects6= [];
gdjs.Level_3211Code.GDSource_95textObjects1= [];
gdjs.Level_3211Code.GDSource_95textObjects2= [];
gdjs.Level_3211Code.GDSource_95textObjects3= [];
gdjs.Level_3211Code.GDSource_95textObjects4= [];
gdjs.Level_3211Code.GDSource_95textObjects5= [];
gdjs.Level_3211Code.GDSource_95textObjects6= [];
gdjs.Level_3211Code.GDYear_95textObjects1= [];
gdjs.Level_3211Code.GDYear_95textObjects2= [];
gdjs.Level_3211Code.GDYear_95textObjects3= [];
gdjs.Level_3211Code.GDYear_95textObjects4= [];
gdjs.Level_3211Code.GDYear_95textObjects5= [];
gdjs.Level_3211Code.GDYear_95textObjects6= [];
gdjs.Level_3211Code.GDYesObjects1= [];
gdjs.Level_3211Code.GDYesObjects2= [];
gdjs.Level_3211Code.GDYesObjects3= [];
gdjs.Level_3211Code.GDYesObjects4= [];
gdjs.Level_3211Code.GDYesObjects5= [];
gdjs.Level_3211Code.GDYesObjects6= [];
gdjs.Level_3211Code.GDYes2Objects1= [];
gdjs.Level_3211Code.GDYes2Objects2= [];
gdjs.Level_3211Code.GDYes2Objects3= [];
gdjs.Level_3211Code.GDYes2Objects4= [];
gdjs.Level_3211Code.GDYes2Objects5= [];
gdjs.Level_3211Code.GDYes2Objects6= [];
gdjs.Level_3211Code.GDYes3Objects1= [];
gdjs.Level_3211Code.GDYes3Objects2= [];
gdjs.Level_3211Code.GDYes3Objects3= [];
gdjs.Level_3211Code.GDYes3Objects4= [];
gdjs.Level_3211Code.GDYes3Objects5= [];
gdjs.Level_3211Code.GDYes3Objects6= [];
gdjs.Level_3211Code.GDYes32Objects1= [];
gdjs.Level_3211Code.GDYes32Objects2= [];
gdjs.Level_3211Code.GDYes32Objects3= [];
gdjs.Level_3211Code.GDYes32Objects4= [];
gdjs.Level_3211Code.GDYes32Objects5= [];
gdjs.Level_3211Code.GDYes32Objects6= [];
gdjs.Level_3211Code.GDYes4Objects1= [];
gdjs.Level_3211Code.GDYes4Objects2= [];
gdjs.Level_3211Code.GDYes4Objects3= [];
gdjs.Level_3211Code.GDYes4Objects4= [];
gdjs.Level_3211Code.GDYes4Objects5= [];
gdjs.Level_3211Code.GDYes4Objects6= [];
gdjs.Level_3211Code.GDYes5Objects1= [];
gdjs.Level_3211Code.GDYes5Objects2= [];
gdjs.Level_3211Code.GDYes5Objects3= [];
gdjs.Level_3211Code.GDYes5Objects4= [];
gdjs.Level_3211Code.GDYes5Objects5= [];
gdjs.Level_3211Code.GDYes5Objects6= [];
gdjs.Level_3211Code.GDYes6Objects1= [];
gdjs.Level_3211Code.GDYes6Objects2= [];
gdjs.Level_3211Code.GDYes6Objects3= [];
gdjs.Level_3211Code.GDYes6Objects4= [];
gdjs.Level_3211Code.GDYes6Objects5= [];
gdjs.Level_3211Code.GDYes6Objects6= [];
gdjs.Level_3211Code.GDYes7Objects1= [];
gdjs.Level_3211Code.GDYes7Objects2= [];
gdjs.Level_3211Code.GDYes7Objects3= [];
gdjs.Level_3211Code.GDYes7Objects4= [];
gdjs.Level_3211Code.GDYes7Objects5= [];
gdjs.Level_3211Code.GDYes7Objects6= [];
gdjs.Level_3211Code.GDYes8Objects1= [];
gdjs.Level_3211Code.GDYes8Objects2= [];
gdjs.Level_3211Code.GDYes8Objects3= [];
gdjs.Level_3211Code.GDYes8Objects4= [];
gdjs.Level_3211Code.GDYes8Objects5= [];
gdjs.Level_3211Code.GDYes8Objects6= [];
gdjs.Level_3211Code.GDChinaObjects1= [];
gdjs.Level_3211Code.GDChinaObjects2= [];
gdjs.Level_3211Code.GDChinaObjects3= [];
gdjs.Level_3211Code.GDChinaObjects4= [];
gdjs.Level_3211Code.GDChinaObjects5= [];
gdjs.Level_3211Code.GDChinaObjects6= [];
gdjs.Level_3211Code.GDNoObjects1= [];
gdjs.Level_3211Code.GDNoObjects2= [];
gdjs.Level_3211Code.GDNoObjects3= [];
gdjs.Level_3211Code.GDNoObjects4= [];
gdjs.Level_3211Code.GDNoObjects5= [];
gdjs.Level_3211Code.GDNoObjects6= [];
gdjs.Level_3211Code.GDNo2Objects1= [];
gdjs.Level_3211Code.GDNo2Objects2= [];
gdjs.Level_3211Code.GDNo2Objects3= [];
gdjs.Level_3211Code.GDNo2Objects4= [];
gdjs.Level_3211Code.GDNo2Objects5= [];
gdjs.Level_3211Code.GDNo2Objects6= [];
gdjs.Level_3211Code.GDNo3Objects1= [];
gdjs.Level_3211Code.GDNo3Objects2= [];
gdjs.Level_3211Code.GDNo3Objects3= [];
gdjs.Level_3211Code.GDNo3Objects4= [];
gdjs.Level_3211Code.GDNo3Objects5= [];
gdjs.Level_3211Code.GDNo3Objects6= [];
gdjs.Level_3211Code.GDNo4Objects1= [];
gdjs.Level_3211Code.GDNo4Objects2= [];
gdjs.Level_3211Code.GDNo4Objects3= [];
gdjs.Level_3211Code.GDNo4Objects4= [];
gdjs.Level_3211Code.GDNo4Objects5= [];
gdjs.Level_3211Code.GDNo4Objects6= [];
gdjs.Level_3211Code.GDNo5Objects1= [];
gdjs.Level_3211Code.GDNo5Objects2= [];
gdjs.Level_3211Code.GDNo5Objects3= [];
gdjs.Level_3211Code.GDNo5Objects4= [];
gdjs.Level_3211Code.GDNo5Objects5= [];
gdjs.Level_3211Code.GDNo5Objects6= [];
gdjs.Level_3211Code.GDVictory_95TextObjects1= [];
gdjs.Level_3211Code.GDVictory_95TextObjects2= [];
gdjs.Level_3211Code.GDVictory_95TextObjects3= [];
gdjs.Level_3211Code.GDVictory_95TextObjects4= [];
gdjs.Level_3211Code.GDVictory_95TextObjects5= [];
gdjs.Level_3211Code.GDVictory_95TextObjects6= [];
gdjs.Level_3211Code.GDMenuObjects1= [];
gdjs.Level_3211Code.GDMenuObjects2= [];
gdjs.Level_3211Code.GDMenuObjects3= [];
gdjs.Level_3211Code.GDMenuObjects4= [];
gdjs.Level_3211Code.GDMenuObjects5= [];
gdjs.Level_3211Code.GDMenuObjects6= [];

gdjs.Level_3211Code.conditionTrue_0 = {val:false};
gdjs.Level_3211Code.condition0IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition1IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition2IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition3IsTrue_0 = {val:false};
gdjs.Level_3211Code.conditionTrue_1 = {val:false};
gdjs.Level_3211Code.condition0IsTrue_1 = {val:false};
gdjs.Level_3211Code.condition1IsTrue_1 = {val:false};
gdjs.Level_3211Code.condition2IsTrue_1 = {val:false};
gdjs.Level_3211Code.condition3IsTrue_1 = {val:false};


gdjs.Level_3211Code.eventsList0 = function(runtimeScene) {

{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Victory_Text"), gdjs.Level_3211Code.GDVictory_95TextObjects2);
{runtimeScene.getVariables().get("MaxBalls").setNumber(100);
}{runtimeScene.getVariables().get("BallsCreatedPerFrame").setNumber(1);
}{for(var i = 0, len = gdjs.Level_3211Code.GDVictory_95TextObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDVictory_95TextObjects2[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDVictory_95TextObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDVictory_95TextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "UI", 0));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "audience_cheers_13.aac", false, 50, 1);
}}

}


};gdjs.Level_3211Code.mapOfEmptyGDBall_951ObjectsEmptyGDBall_954ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_4": [], "Ball_5": [], "Ball_6": []});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95956Objects5Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_3211Code.GDBall_951Objects5, "Ball_4": gdjs.Level_3211Code.GDBall_954Objects5, "Ball_5": gdjs.Level_3211Code.GDBall_955Objects5, "Ball_6": gdjs.Level_3211Code.GDBall_956Objects5});
gdjs.Level_3211Code.eventsList1 = function(runtimeScene) {

{


{
gdjs.Level_3211Code.GDBall_951Objects5.length = 0;

gdjs.Level_3211Code.GDBall_954Objects5.length = 0;

gdjs.Level_3211Code.GDBall_955Objects5.length = 0;

gdjs.Level_3211Code.GDBall_956Objects5.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95956Objects5Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0)), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) - 32, "Balls");
}{for(var i = 0, len = gdjs.Level_3211Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_951Objects5[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_954Objects5[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_955Objects5[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_956Objects5[i].addPolarForce(270, 800, 1);
}
}}

}


};gdjs.Level_3211Code.eventsList2 = function(runtimeScene) {

{


gdjs.Level_3211Code.repeatCount4 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("BallsCreatedPerFrame"));
for(gdjs.Level_3211Code.repeatIndex4 = 0;gdjs.Level_3211Code.repeatIndex4 < gdjs.Level_3211Code.repeatCount4;++gdjs.Level_3211Code.repeatIndex4) {

if (true)
{

{ //Subevents: 
gdjs.Level_3211Code.eventsList1(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_3211Code.eventsList3 = function(runtimeScene) {

{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfEmptyGDBall_951ObjectsEmptyGDBall_954ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBalls"));
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_3211Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_3211Code.GDBall_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_3211Code.GDBall_954Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_3211Code.GDBall_955Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_3211Code.GDBall_956Objects3);
{for(var i = 0, len = gdjs.Level_3211Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_951Objects3[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_954Objects3[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_955Objects3[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_956Objects3[i].addPolarForce(90, 10, 1);
}
}}

}


};gdjs.Level_3211Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_3211Code.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_3211Code.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_3211Code.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_3211Code.GDBall_956Objects2);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_951Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_951Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_951Objects2[k] = gdjs.Level_3211Code.GDBall_951Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_951Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_954Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_954Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_954Objects2[k] = gdjs.Level_3211Code.GDBall_954Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_954Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_955Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_955Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_955Objects2[k] = gdjs.Level_3211Code.GDBall_955Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_955Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_956Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_956Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_956Objects2[k] = gdjs.Level_3211Code.GDBall_956Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_956Objects2.length = k;}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDBall_951Objects2 */
/* Reuse gdjs.Level_3211Code.GDBall_954Objects2 */
/* Reuse gdjs.Level_3211Code.GDBall_955Objects2 */
/* Reuse gdjs.Level_3211Code.GDBall_956Objects2 */
{for(var i = 0, len = gdjs.Level_3211Code.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_955Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_956Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_3211Code.eventsList6 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList3(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList4(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList5(runtimeScene);
}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "GdevelopGLogoWhite": gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPlay_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDMainMenu_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDResetProgress_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects3Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_3211Code.GDPlay_95TextObjects3, "MainMenu_Text": gdjs.Level_3211Code.GDMainMenu_95TextObjects3, "ResetProgress_Text": gdjs.Level_3211Code.GDResetProgress_95TextObjects3, "StartOver_Text": gdjs.Level_3211Code.GDStartOver_95TextObjects3, "Submit_Text": gdjs.Level_3211Code.GDSubmit_95TextObjects3});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "GdevelopGLogoWhite": gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3 */
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_3211Code.GDMainMenu_95TextObjects3);
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_3211Code.GDPlay_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_3211Code.GDResetProgress_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_3211Code.GDStartOver_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_3211Code.GDSubmit_95TextObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPlay_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDMainMenu_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDResetProgress_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects3Objects, gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, false, runtimeScene, false);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDMainMenu_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDPlay_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDResetProgress_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDStartOver_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDSubmit_95TextObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDPlay_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDPlay_95TextObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMainMenu_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMainMenu_95TextObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDResetProgress_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDResetProgress_95TextObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDStartOver_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDStartOver_95TextObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDSubmit_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDSubmit_95TextObjects3[i].setColor("255;255;255");
}
}}

}


};gdjs.Level_3211Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_3211Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_3211Code.GDMenuObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, runtimeScene, true, true);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3 */
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects3[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects3[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects3[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects3[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.Level_3211Code.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "GdevelopGLogoWhite": gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPlay_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDMainMenu_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDResetProgress_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects3Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_3211Code.GDPlay_95TextObjects3, "MainMenu_Text": gdjs.Level_3211Code.GDMainMenu_95TextObjects3, "ResetProgress_Text": gdjs.Level_3211Code.GDResetProgress_95TextObjects3, "StartOver_Text": gdjs.Level_3211Code.GDStartOver_95TextObjects3, "Submit_Text": gdjs.Level_3211Code.GDSubmit_95TextObjects3});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "GdevelopGLogoWhite": gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3 */
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_3211Code.GDMainMenu_95TextObjects3);
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_3211Code.GDPlay_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_3211Code.GDResetProgress_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_3211Code.GDStartOver_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_3211Code.GDSubmit_95TextObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPlay_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDMainMenu_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDResetProgress_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects3Objects, gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, false, runtimeScene, false);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDMainMenu_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDPlay_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDResetProgress_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDStartOver_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDSubmit_95TextObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDPlay_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDPlay_95TextObjects3[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMainMenu_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMainMenu_95TextObjects3[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_3211Code.GDResetProgress_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDResetProgress_95TextObjects3[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_3211Code.GDStartOver_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDStartOver_95TextObjects3[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_3211Code.GDSubmit_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDSubmit_95TextObjects3[i].setColor("241;91;181");
}
}}

}


};gdjs.Level_3211Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_3211Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_3211Code.GDMenuObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, runtimeScene, true, false);
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_3211Code.conditionTrue_1 = gdjs.Level_3211Code.condition1IsTrue_0;
gdjs.Level_3211Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11173756);
}
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3 */
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects3[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects3[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects3[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.Level_3211Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "GdevelopGLogoWhite": gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_3211Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_3211Code.GDMenuObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, runtimeScene, true, false);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3 */
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects3[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects3[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects3[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects2ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects2ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects2, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects2, "GdevelopGLogoWhite": gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects2, "Menu": gdjs.Level_3211Code.GDMenuObjects2});
gdjs.Level_3211Code.eventsList12 = function(runtimeScene) {

{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_3211Code.conditionTrue_1 = gdjs.Level_3211Code.condition1IsTrue_0;
gdjs.Level_3211Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11175812);
}
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_3211Code.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoWhite"), gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects2);
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_3211Code.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_3211Code.GDMenuObjects2);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects2ObjectsGDgdjs_46Level_953211Code_46GDGdevelopGLogoWhiteObjects2ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects2Objects, runtimeScene, true, false);
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects2 */
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects2 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects2 */
/* Reuse gdjs.Level_3211Code.GDMenuObjects2 */
{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects2[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.Level_3211Code.eventsList13 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList8(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList10(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList12(runtimeScene);
}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects2});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects2Objects = Hashtable.newFrom({"Submit_Text": gdjs.Level_3211Code.GDSubmit_95TextObjects2});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects2});
gdjs.Level_3211Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_3211Code.GDSubmit_95TextObjects2);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
gdjs.Level_3211Code.condition2IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Level_3211Code.condition1IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects2Objects, gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2Objects, false, runtimeScene, false);
}}
}
if (gdjs.Level_3211Code.condition2IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://d-luo.github.io/Dissertation/", runtimeScene);
}}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects1Objects = Hashtable.newFrom({"StartOver_Text": gdjs.Level_3211Code.GDStartOver_95TextObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects1});
gdjs.Level_3211Code.asyncCallback11076748 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title Screen", false);
}}
gdjs.Level_3211Code.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_3211Code.asyncCallback11076748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_3211Code.eventsList16 = function(runtimeScene) {

{


{
{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "CurrentLevel", 0);
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "PlayTimer", 0);
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "MovesMade", 0);
}
{ //Subevents
gdjs.Level_3211Code.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_3211Code.GDStartOver_95TextObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
gdjs.Level_3211Code.condition2IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Level_3211Code.condition1IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects1Objects, gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects1Objects, false, runtimeScene, false);
}}
}
if (gdjs.Level_3211Code.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Level_3211Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.eventsList18 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList17(runtimeScene);
}


};gdjs.Level_3211Code.eventsList19 = function(runtimeScene) {

{



}


{


gdjs.Level_3211Code.eventsList13(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList14(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList18(runtimeScene);
}


};gdjs.Level_3211Code.eventsList20 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList0(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList6(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList19(runtimeScene);
}


};gdjs.Level_3211Code.eventsList21 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList20(runtimeScene);
}


{


{
}

}


};

gdjs.Level_3211Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_3211Code.GDBall_951Objects1.length = 0;
gdjs.Level_3211Code.GDBall_951Objects2.length = 0;
gdjs.Level_3211Code.GDBall_951Objects3.length = 0;
gdjs.Level_3211Code.GDBall_951Objects4.length = 0;
gdjs.Level_3211Code.GDBall_951Objects5.length = 0;
gdjs.Level_3211Code.GDBall_951Objects6.length = 0;
gdjs.Level_3211Code.GDBall_954Objects1.length = 0;
gdjs.Level_3211Code.GDBall_954Objects2.length = 0;
gdjs.Level_3211Code.GDBall_954Objects3.length = 0;
gdjs.Level_3211Code.GDBall_954Objects4.length = 0;
gdjs.Level_3211Code.GDBall_954Objects5.length = 0;
gdjs.Level_3211Code.GDBall_954Objects6.length = 0;
gdjs.Level_3211Code.GDBall_955Objects1.length = 0;
gdjs.Level_3211Code.GDBall_955Objects2.length = 0;
gdjs.Level_3211Code.GDBall_955Objects3.length = 0;
gdjs.Level_3211Code.GDBall_955Objects4.length = 0;
gdjs.Level_3211Code.GDBall_955Objects5.length = 0;
gdjs.Level_3211Code.GDBall_955Objects6.length = 0;
gdjs.Level_3211Code.GDBall_956Objects1.length = 0;
gdjs.Level_3211Code.GDBall_956Objects2.length = 0;
gdjs.Level_3211Code.GDBall_956Objects3.length = 0;
gdjs.Level_3211Code.GDBall_956Objects4.length = 0;
gdjs.Level_3211Code.GDBall_956Objects5.length = 0;
gdjs.Level_3211Code.GDBall_956Objects6.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects6.length = 0;
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects1.length = 0;
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects2.length = 0;
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects3.length = 0;
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects4.length = 0;
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects5.length = 0;
gdjs.Level_3211Code.GDGdevelopGLogoWhiteObjects6.length = 0;
gdjs.Level_3211Code.GDCloud1Objects1.length = 0;
gdjs.Level_3211Code.GDCloud1Objects2.length = 0;
gdjs.Level_3211Code.GDCloud1Objects3.length = 0;
gdjs.Level_3211Code.GDCloud1Objects4.length = 0;
gdjs.Level_3211Code.GDCloud1Objects5.length = 0;
gdjs.Level_3211Code.GDCloud1Objects6.length = 0;
gdjs.Level_3211Code.GDCloud2Objects1.length = 0;
gdjs.Level_3211Code.GDCloud2Objects2.length = 0;
gdjs.Level_3211Code.GDCloud2Objects3.length = 0;
gdjs.Level_3211Code.GDCloud2Objects4.length = 0;
gdjs.Level_3211Code.GDCloud2Objects5.length = 0;
gdjs.Level_3211Code.GDCloud2Objects6.length = 0;
gdjs.Level_3211Code.GDCloud3Objects1.length = 0;
gdjs.Level_3211Code.GDCloud3Objects2.length = 0;
gdjs.Level_3211Code.GDCloud3Objects3.length = 0;
gdjs.Level_3211Code.GDCloud3Objects4.length = 0;
gdjs.Level_3211Code.GDCloud3Objects5.length = 0;
gdjs.Level_3211Code.GDCloud3Objects6.length = 0;
gdjs.Level_3211Code.GDCloud4Objects1.length = 0;
gdjs.Level_3211Code.GDCloud4Objects2.length = 0;
gdjs.Level_3211Code.GDCloud4Objects3.length = 0;
gdjs.Level_3211Code.GDCloud4Objects4.length = 0;
gdjs.Level_3211Code.GDCloud4Objects5.length = 0;
gdjs.Level_3211Code.GDCloud4Objects6.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects1.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects2.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects3.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects4.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects5.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects6.length = 0;
gdjs.Level_3211Code.GDButtonCNObjects1.length = 0;
gdjs.Level_3211Code.GDButtonCNObjects2.length = 0;
gdjs.Level_3211Code.GDButtonCNObjects3.length = 0;
gdjs.Level_3211Code.GDButtonCNObjects4.length = 0;
gdjs.Level_3211Code.GDButtonCNObjects5.length = 0;
gdjs.Level_3211Code.GDButtonCNObjects6.length = 0;
gdjs.Level_3211Code.GDMenuObjects1.length = 0;
gdjs.Level_3211Code.GDMenuObjects2.length = 0;
gdjs.Level_3211Code.GDMenuObjects3.length = 0;
gdjs.Level_3211Code.GDMenuObjects4.length = 0;
gdjs.Level_3211Code.GDMenuObjects5.length = 0;
gdjs.Level_3211Code.GDMenuObjects6.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDClick_95textObjects1.length = 0;
gdjs.Level_3211Code.GDClick_95textObjects2.length = 0;
gdjs.Level_3211Code.GDClick_95textObjects3.length = 0;
gdjs.Level_3211Code.GDClick_95textObjects4.length = 0;
gdjs.Level_3211Code.GDClick_95textObjects5.length = 0;
gdjs.Level_3211Code.GDClick_95textObjects6.length = 0;
gdjs.Level_3211Code.GDYarnObjects1.length = 0;
gdjs.Level_3211Code.GDYarnObjects2.length = 0;
gdjs.Level_3211Code.GDYarnObjects3.length = 0;
gdjs.Level_3211Code.GDYarnObjects4.length = 0;
gdjs.Level_3211Code.GDYarnObjects5.length = 0;
gdjs.Level_3211Code.GDYarnObjects6.length = 0;
gdjs.Level_3211Code.GDBullObjects1.length = 0;
gdjs.Level_3211Code.GDBullObjects2.length = 0;
gdjs.Level_3211Code.GDBullObjects3.length = 0;
gdjs.Level_3211Code.GDBullObjects4.length = 0;
gdjs.Level_3211Code.GDBullObjects5.length = 0;
gdjs.Level_3211Code.GDBullObjects6.length = 0;
gdjs.Level_3211Code.GDClick_95text2Objects1.length = 0;
gdjs.Level_3211Code.GDClick_95text2Objects2.length = 0;
gdjs.Level_3211Code.GDClick_95text2Objects3.length = 0;
gdjs.Level_3211Code.GDClick_95text2Objects4.length = 0;
gdjs.Level_3211Code.GDClick_95text2Objects5.length = 0;
gdjs.Level_3211Code.GDClick_95text2Objects6.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects1.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects2.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects3.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects4.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects5.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects6.length = 0;
gdjs.Level_3211Code.GDLeatherShoesObjects1.length = 0;
gdjs.Level_3211Code.GDLeatherShoesObjects2.length = 0;
gdjs.Level_3211Code.GDLeatherShoesObjects3.length = 0;
gdjs.Level_3211Code.GDLeatherShoesObjects4.length = 0;
gdjs.Level_3211Code.GDLeatherShoesObjects5.length = 0;
gdjs.Level_3211Code.GDLeatherShoesObjects6.length = 0;
gdjs.Level_3211Code.GDFurnitureObjects1.length = 0;
gdjs.Level_3211Code.GDFurnitureObjects2.length = 0;
gdjs.Level_3211Code.GDFurnitureObjects3.length = 0;
gdjs.Level_3211Code.GDFurnitureObjects4.length = 0;
gdjs.Level_3211Code.GDFurnitureObjects5.length = 0;
gdjs.Level_3211Code.GDFurnitureObjects6.length = 0;
gdjs.Level_3211Code.GDMagnifyingGlassObjects1.length = 0;
gdjs.Level_3211Code.GDMagnifyingGlassObjects2.length = 0;
gdjs.Level_3211Code.GDMagnifyingGlassObjects3.length = 0;
gdjs.Level_3211Code.GDMagnifyingGlassObjects4.length = 0;
gdjs.Level_3211Code.GDMagnifyingGlassObjects5.length = 0;
gdjs.Level_3211Code.GDMagnifyingGlassObjects6.length = 0;
gdjs.Level_3211Code.GDtoysObjects1.length = 0;
gdjs.Level_3211Code.GDtoysObjects2.length = 0;
gdjs.Level_3211Code.GDtoysObjects3.length = 0;
gdjs.Level_3211Code.GDtoysObjects4.length = 0;
gdjs.Level_3211Code.GDtoysObjects5.length = 0;
gdjs.Level_3211Code.GDtoysObjects6.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDChina_95textObjects1.length = 0;
gdjs.Level_3211Code.GDChina_95textObjects2.length = 0;
gdjs.Level_3211Code.GDChina_95textObjects3.length = 0;
gdjs.Level_3211Code.GDChina_95textObjects4.length = 0;
gdjs.Level_3211Code.GDChina_95textObjects5.length = 0;
gdjs.Level_3211Code.GDChina_95textObjects6.length = 0;
gdjs.Level_3211Code.GDSection_95text1Objects1.length = 0;
gdjs.Level_3211Code.GDSection_95text1Objects2.length = 0;
gdjs.Level_3211Code.GDSection_95text1Objects3.length = 0;
gdjs.Level_3211Code.GDSection_95text1Objects4.length = 0;
gdjs.Level_3211Code.GDSection_95text1Objects5.length = 0;
gdjs.Level_3211Code.GDSection_95text1Objects6.length = 0;
gdjs.Level_3211Code.GDSource_95textObjects1.length = 0;
gdjs.Level_3211Code.GDSource_95textObjects2.length = 0;
gdjs.Level_3211Code.GDSource_95textObjects3.length = 0;
gdjs.Level_3211Code.GDSource_95textObjects4.length = 0;
gdjs.Level_3211Code.GDSource_95textObjects5.length = 0;
gdjs.Level_3211Code.GDSource_95textObjects6.length = 0;
gdjs.Level_3211Code.GDYear_95textObjects1.length = 0;
gdjs.Level_3211Code.GDYear_95textObjects2.length = 0;
gdjs.Level_3211Code.GDYear_95textObjects3.length = 0;
gdjs.Level_3211Code.GDYear_95textObjects4.length = 0;
gdjs.Level_3211Code.GDYear_95textObjects5.length = 0;
gdjs.Level_3211Code.GDYear_95textObjects6.length = 0;
gdjs.Level_3211Code.GDYesObjects1.length = 0;
gdjs.Level_3211Code.GDYesObjects2.length = 0;
gdjs.Level_3211Code.GDYesObjects3.length = 0;
gdjs.Level_3211Code.GDYesObjects4.length = 0;
gdjs.Level_3211Code.GDYesObjects5.length = 0;
gdjs.Level_3211Code.GDYesObjects6.length = 0;
gdjs.Level_3211Code.GDYes2Objects1.length = 0;
gdjs.Level_3211Code.GDYes2Objects2.length = 0;
gdjs.Level_3211Code.GDYes2Objects3.length = 0;
gdjs.Level_3211Code.GDYes2Objects4.length = 0;
gdjs.Level_3211Code.GDYes2Objects5.length = 0;
gdjs.Level_3211Code.GDYes2Objects6.length = 0;
gdjs.Level_3211Code.GDYes3Objects1.length = 0;
gdjs.Level_3211Code.GDYes3Objects2.length = 0;
gdjs.Level_3211Code.GDYes3Objects3.length = 0;
gdjs.Level_3211Code.GDYes3Objects4.length = 0;
gdjs.Level_3211Code.GDYes3Objects5.length = 0;
gdjs.Level_3211Code.GDYes3Objects6.length = 0;
gdjs.Level_3211Code.GDYes32Objects1.length = 0;
gdjs.Level_3211Code.GDYes32Objects2.length = 0;
gdjs.Level_3211Code.GDYes32Objects3.length = 0;
gdjs.Level_3211Code.GDYes32Objects4.length = 0;
gdjs.Level_3211Code.GDYes32Objects5.length = 0;
gdjs.Level_3211Code.GDYes32Objects6.length = 0;
gdjs.Level_3211Code.GDYes4Objects1.length = 0;
gdjs.Level_3211Code.GDYes4Objects2.length = 0;
gdjs.Level_3211Code.GDYes4Objects3.length = 0;
gdjs.Level_3211Code.GDYes4Objects4.length = 0;
gdjs.Level_3211Code.GDYes4Objects5.length = 0;
gdjs.Level_3211Code.GDYes4Objects6.length = 0;
gdjs.Level_3211Code.GDYes5Objects1.length = 0;
gdjs.Level_3211Code.GDYes5Objects2.length = 0;
gdjs.Level_3211Code.GDYes5Objects3.length = 0;
gdjs.Level_3211Code.GDYes5Objects4.length = 0;
gdjs.Level_3211Code.GDYes5Objects5.length = 0;
gdjs.Level_3211Code.GDYes5Objects6.length = 0;
gdjs.Level_3211Code.GDYes6Objects1.length = 0;
gdjs.Level_3211Code.GDYes6Objects2.length = 0;
gdjs.Level_3211Code.GDYes6Objects3.length = 0;
gdjs.Level_3211Code.GDYes6Objects4.length = 0;
gdjs.Level_3211Code.GDYes6Objects5.length = 0;
gdjs.Level_3211Code.GDYes6Objects6.length = 0;
gdjs.Level_3211Code.GDYes7Objects1.length = 0;
gdjs.Level_3211Code.GDYes7Objects2.length = 0;
gdjs.Level_3211Code.GDYes7Objects3.length = 0;
gdjs.Level_3211Code.GDYes7Objects4.length = 0;
gdjs.Level_3211Code.GDYes7Objects5.length = 0;
gdjs.Level_3211Code.GDYes7Objects6.length = 0;
gdjs.Level_3211Code.GDYes8Objects1.length = 0;
gdjs.Level_3211Code.GDYes8Objects2.length = 0;
gdjs.Level_3211Code.GDYes8Objects3.length = 0;
gdjs.Level_3211Code.GDYes8Objects4.length = 0;
gdjs.Level_3211Code.GDYes8Objects5.length = 0;
gdjs.Level_3211Code.GDYes8Objects6.length = 0;
gdjs.Level_3211Code.GDChinaObjects1.length = 0;
gdjs.Level_3211Code.GDChinaObjects2.length = 0;
gdjs.Level_3211Code.GDChinaObjects3.length = 0;
gdjs.Level_3211Code.GDChinaObjects4.length = 0;
gdjs.Level_3211Code.GDChinaObjects5.length = 0;
gdjs.Level_3211Code.GDChinaObjects6.length = 0;
gdjs.Level_3211Code.GDNoObjects1.length = 0;
gdjs.Level_3211Code.GDNoObjects2.length = 0;
gdjs.Level_3211Code.GDNoObjects3.length = 0;
gdjs.Level_3211Code.GDNoObjects4.length = 0;
gdjs.Level_3211Code.GDNoObjects5.length = 0;
gdjs.Level_3211Code.GDNoObjects6.length = 0;
gdjs.Level_3211Code.GDNo2Objects1.length = 0;
gdjs.Level_3211Code.GDNo2Objects2.length = 0;
gdjs.Level_3211Code.GDNo2Objects3.length = 0;
gdjs.Level_3211Code.GDNo2Objects4.length = 0;
gdjs.Level_3211Code.GDNo2Objects5.length = 0;
gdjs.Level_3211Code.GDNo2Objects6.length = 0;
gdjs.Level_3211Code.GDNo3Objects1.length = 0;
gdjs.Level_3211Code.GDNo3Objects2.length = 0;
gdjs.Level_3211Code.GDNo3Objects3.length = 0;
gdjs.Level_3211Code.GDNo3Objects4.length = 0;
gdjs.Level_3211Code.GDNo3Objects5.length = 0;
gdjs.Level_3211Code.GDNo3Objects6.length = 0;
gdjs.Level_3211Code.GDNo4Objects1.length = 0;
gdjs.Level_3211Code.GDNo4Objects2.length = 0;
gdjs.Level_3211Code.GDNo4Objects3.length = 0;
gdjs.Level_3211Code.GDNo4Objects4.length = 0;
gdjs.Level_3211Code.GDNo4Objects5.length = 0;
gdjs.Level_3211Code.GDNo4Objects6.length = 0;
gdjs.Level_3211Code.GDNo5Objects1.length = 0;
gdjs.Level_3211Code.GDNo5Objects2.length = 0;
gdjs.Level_3211Code.GDNo5Objects3.length = 0;
gdjs.Level_3211Code.GDNo5Objects4.length = 0;
gdjs.Level_3211Code.GDNo5Objects5.length = 0;
gdjs.Level_3211Code.GDNo5Objects6.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDMenuObjects1.length = 0;
gdjs.Level_3211Code.GDMenuObjects2.length = 0;
gdjs.Level_3211Code.GDMenuObjects3.length = 0;
gdjs.Level_3211Code.GDMenuObjects4.length = 0;
gdjs.Level_3211Code.GDMenuObjects5.length = 0;
gdjs.Level_3211Code.GDMenuObjects6.length = 0;

gdjs.Level_3211Code.eventsList21(runtimeScene);
return;

}

gdjs['Level_3211Code'] = gdjs.Level_3211Code;
